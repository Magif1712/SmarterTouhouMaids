#include "VectorMapping.h"
#include <cuda_runtime.h>
#include <stdexcept>
#include <type_traits>

/**
 * @brief 将源位向量 A 中的每一位按照索引映射 P 分散写入目标位向量 B。
 * 每个线程处理一个输入元素 i。
 * 使用原子操作保证多个线程写入同一 32 位字时的正确性。
 */
__global__ void scatterBitsAtomicKernel(
    const uint32_t *__restrict__ A_bits,
    uint32_t *__restrict__ B_bits,
    const int *__restrict__ P,
    unsigned long long N)
{
    unsigned long long i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= N)
        return;

    // 1. 读取 A 的第 i 位
    bool val = Vector<bool>::getBit(A_bits, i);

    // 2. 计算目标位置
    int dst = P[i];
    if (dst < 0)
        return; // 负数索引视为无效或忽略

    // 3. 原子写入到 B
    Vector<bool>::setBitAtomic(B_bits, static_cast<size_t>(dst), val);
}

/**
 * @brief Host 包装函数：执行位散列操作。
 */
void scatterBits(const Vector<bool> &src, Vector<bool> &dst, const Vector<int> &P)
{
    if (src.size() == 0)
        return;

    unsigned long long N = src.size();

    // 线程块配置
    constexpr int threadsPerBlock = 256;
    int blocksPerGrid = static_cast<int>((N + threadsPerBlock - 1) / threadsPerBlock);

    scatterBitsAtomicKernel<<<blocksPerGrid, threadsPerBlock>>>(
        src.data(),
        dst.data(),
        P.data(),
        N);

    // 检查启动错误
    cudaError_t err = cudaGetLastError();
    if (err != cudaSuccess)
    {
        throw std::runtime_error(std::string("scatterBitsAtomicKernel launch failed: ") + cudaGetErrorString(err));
    }

    // 同步并检查运行错误
    err = cudaDeviceSynchronize();
    if (err != cudaSuccess)
    {
        throw std::runtime_error(std::string("scatterBitsAtomicKernel execution failed: ") + cudaGetErrorString(err));
    }
}

/**
 * @brief 对两个位压缩向量进行 Word 级别的 XOR 操作 (A ^= B)。
 * 每个线程处理一个 32 位的字，比逐位操作快 32 倍。
 */
__global__ void xorWordsKernel(uint32_t *A, const uint32_t *B, size_t wordCount)
{
    size_t idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < wordCount)
    {
        A[idx] ^= B[idx];
    }
}

/**
 * @brief Host 包装函数：执行 A ^= B 操作。
 */
void xorVectors(Vector<bool> &A, const Vector<bool> &B)
{
    if (A.size() != B.size())
    {
        throw std::invalid_argument("Vector sizes must match for XOR operation");
    }

    size_t words = A.wordCount();
    if (words == 0)
        return;

    constexpr int threadsPerBlock = 256;
    int blocksPerGrid = static_cast<int>((words + threadsPerBlock - 1) / threadsPerBlock);

    xorWordsKernel<<<blocksPerGrid, threadsPerBlock>>>(A.data(), B.data(), words);

    cudaError_t err = cudaGetLastError();
    if (err != cudaSuccess)
    {
        throw std::runtime_error(std::string("xorWordsKernel launch failed: ") + cudaGetErrorString(err));
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess)
    {
        throw std::runtime_error(std::string("xorWordsKernel execution failed: ") + cudaGetErrorString(err));
    }
}

/**
 * @brief [最优版] 从两个位压缩的布尔向量计算差值，并将结果存入一个整数向量。
 *        采用按 32 位字批量处理的方式，充分利用位压缩优势和内存合并访问，性能远超逐位处理。
 * @param result 目标整数向量，指针无别名
 * @param a      被减数布尔向量 (位压缩)，指针无别名
 * @param b      减数布尔向量 (位压缩)，指针无别名
 * @param n      元素总数 (比特数)
 */
__global__ void subtractBoolVectorsKernel( 
    const uint32_t* __restrict__ d_A, 
    const uint32_t* __restrict__ d_B, 
    int64_t                           bit_offset,    // A/B 共同起始 bit 
    int32_t* __restrict__           d_C, 
    int64_t                           c_int_offset,  // C 起始 int32 
    int64_t                           bit_length)    // 处理 bit 数 
 { 
    int64_t tid    = (int64_t)blockIdx.x * blockDim.x + threadIdx.x; 
    int64_t stride = (int64_t)gridDim.x * blockDim.x; 
 
 
    for (int64_t idx = tid; idx < bit_length; idx += stride) 
    { 
        int64_t bit = bit_offset + idx; 
 
 
        uint32_t a_word = __ldg(&d_A[bit >> 5]); 
        uint32_t b_word = __ldg(&d_B[bit >> 5]); 
 
 
        int a = (a_word >> (bit & 31)) & 1; 
        int b = (b_word >> (bit & 31)) & 1; 
 
 
        d_C[c_int_offset + idx] = a - b; 
    } 
 }

// 主机端封装 
 void subtractBoolVectors( 
     const uint32_t* d_A, 
     const uint32_t* d_B, 
     int64_t         bit_offset, 
     int32_t*        d_C, 
     int64_t         c_int_offset, 
     int64_t         bit_length, 
     cudaStream_t    stream = 0) 
 { 
     if (bit_length <= 0) return; 
 
 
     constexpr int blockSize = 256; 
     int gridSize = (int)((bit_length + blockSize - 1) / blockSize); 
 
 
     // 限制 grid 规模，避免过度 launch（可选，根据 GPU 规模调整） 
     // int smCount; 
     // cudaDeviceGetAttribute(&smCount, cudaDevAttrMultiProcessorCount, 0); 
     // gridSize = min(gridSize, smCount * 4); 
 
 
     subtractBoolVectorsKernel<<<gridSize, blockSize, 0, stream>>>( 
         d_A, d_B, bit_offset, d_C, c_int_offset, bit_length); 
 }

/**
 * @brief [高性能] 对向量的指定区间执行原地标量乘法。
 *        vector[offset + i] *= scalar;  i ∈ [0, length)
 * @tparam T 向量元素的类型 (非 bool)
 * @param vector 要修改的向量，指针无别名
 * @param scalar 要乘的标量
 * @param offset 区间起始偏移（元素个数）
 * @param length 区间长度（元素个数）
 */
template <typename T>
__global__ void multiplyVectorByScalarInPlaceRangeKernel(
    T* __restrict__ vector,
    T scalar,
    size_t offset,
    size_t length)
{
    const size_t stride = static_cast<size_t>(gridDim.x) * blockDim.x;

    for (size_t i = static_cast<size_t>(blockIdx.x) * blockDim.x + threadIdx.x;
         i < length;
         i += stride)
    {
        vector[offset + i] *= scalar;
    }
}

/**
 * @brief Host 包装函数：对 Vector<T> 的指定区间执行原地标量乘法。
 * @param vector 要修改的 Vector
 * @param scalar 要乘的标量
 * @param offset 区间起始偏移（元素个数，非字节）
 * @param length 区间长度（元素个数）
 */
template <typename T>
void multiplyVectorByScalarInPlace(
    Vector<T>& vector,
    T scalar,
    size_t offset,
    size_t length)
{
    static_assert(!std::is_same<T, bool>::value,
                  "multiplyVectorByScalarInPlace cannot be used with bool.");

    if (length == 0) return;
    if (scalar == static_cast<T>(1)) return;

    // 边界检查
    if (offset + length > vector.size())
    {
        throw std::out_of_range("Interval [offset, offset+length) exceeds vector size");
    }

    constexpr int threadsPerBlock = 256;
    int blocksPerGrid = static_cast<int>((length + threadsPerBlock - 1) / threadsPerBlock);

    multiplyVectorByScalarInPlaceRangeKernel<T><<<blocksPerGrid, threadsPerBlock>>>(
        vector.data(),
        scalar,
        offset,
        length
    );

    cudaError_t err = cudaGetLastError();
    if (err != cudaSuccess)
    {
        throw std::runtime_error(std::string("Range kernel launch failed: ") + cudaGetErrorString(err));
    }
    err = cudaDeviceSynchronize();
    if (err != cudaSuccess)
    {
        throw std::runtime_error(std::string("Range kernel execution failed: ") + cudaGetErrorString(err));
    }
}

// Explicit instantiations
template void multiplyVectorByScalarInPlace<int>(Vector<int>& vector, int scalar, size_t offset, size_t length);