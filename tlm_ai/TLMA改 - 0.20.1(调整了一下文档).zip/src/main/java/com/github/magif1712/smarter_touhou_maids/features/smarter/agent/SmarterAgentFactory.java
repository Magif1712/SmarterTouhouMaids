package com.github.magif1712.smarter_touhou_maids.features.smarter.agent;

import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.AiFactory;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.IAiSystem;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.registry.Registry;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.registry.RegistryEntry;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.registry.RegistryIds;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.registry.RegistryManager;
import net.minecraft.nbt.CompoundTag;

/**
 * Smarter agent 的 {@link AgentFactory} 实现。
 * <p>
 * <b>工厂自驱组装</b>（真善美第1条"真"）：本工厂直接使用 ai（SmarterAgent 构造注入 IAiSystem），
 * 故自行查 {@code AiRegistry} 取下层 ai factory 创建 ai，再 new SmarterAgent(ai)。
 * 外周（SmarterClientService）不感知 AiRegistry 的存在——它只调本工厂。
 * <p>
 * config 里 aiId 缺失/非法时回退 AiRegistry 默认 entry（{@link Registry#resolve} 内置 fallback）。
 * <p>
 * 附属 agent 的工厂实现不查 AiRegistry（如纯规则 agent 不需要 ai），直接造自己的 agent。
 */
public class SmarterAgentFactory implements AgentFactory {

    @Override
    public IAgent create(CompoundTag config) {
        // === 查 AiRegistry 取下层 ai factory（自驱组装）===
        Registry<?> aiRegistry = RegistryManager.INSTANCE.get(RegistryIds.AI);
        RegistryEntry<?> aiEntry = aiRegistry.resolve(config.getString(RegistryIds.AI.toString()));
        AiFactory aiFactory = (AiFactory) aiEntry.getFactory();

        // 下层 ai factory 自驱组装其内部 process/nn（config 透传，各层各取所需）
        IAiSystem ai = aiFactory.create(config);

        // 注入构造（SmarterAgent 只直接用 ai，不感知 process/nn）
        return new SmarterAgent(ai);
    }
}
