package com.github.magif1712.smarter_touhou_maids.features.smarter.agent;

import com.github.magif1712.smarter_touhou_maids.core.containers.domain.Span;
import com.github.magif1712.smarter_touhou_maids.core.containers.texture.Texture;
import com.github.magif1712.smarter_touhou_maids.core.containers.vector.BoolVector;
import com.github.magif1712.smarter_touhou_maids.core.diagnostics.MemoryDiagnostics;
import com.github.magif1712.smarter_touhou_maids.core.execution.event.Event;
import com.github.magif1712.smarter_touhou_maids.core.execution.stream.Stream;
import com.github.magif1712.smarter_touhou_maids.features.possession.core.PossessionManager;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.IAiSystem;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.debug.EffectorDebugHook;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.effector.ActionIntent;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.effector.MotorOps;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.outlet.BehaviorOutlet;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.sensor.vision.VisionOps;
import com.github.magif1712.smarter_touhou_maids.features.smarter.network.ServerboundActionIntentPacket;
import com.github.magif1712.smarter_touhou_maids.network.NetworkHandler;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Smarter 模式的默认 {@link IAgent} 实现：视觉采集 + AI 运行 + 效应器解码 + 发包的完整链路。
 * <p>
 * 本类的所有业务逻辑搬家自原 {@link SmarterClientService}（拆分 agent 抽象后，SmarterClientService
 * 变为薄容器，业务逻辑下沉到本类）。持有一整套资源：感觉缓冲区、CUDA 流、视觉纹理、
 * AI 系统、效应器、行为出口。
 * <p>
 * <b>注入模式</b>（镜像 {@link com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.process_ai.ProcessAiSystem}）：
 * 本类只直接使用 {@link IAiSystem}（思考机制），构造注入。换 ai（process_ai→别的）时本类零改动。
 * 视觉采集（VisionOps）与效应器（MotorOps）是 SmarterAgent 的内部模式，不进 {@link IAgent} 接口。
 * <p>
 * 设计原则（真善美）：
 * <ul>
 *   <li><b>第1条"真"</b>：本类直接使用 ai，故注入 IAiSystem。不直接使用 process/nn，
 *       故不持它们——换 process/nn 是 ai 内部的事。</li>
 *   <li><b>第2条</b>：C 中"smarter agent = 视觉→思考→行动"是这种 agent 的模式。
 *       视觉细节（glBlitFramebuffer/bit 平面提取）、效应器细节（张力积分/迟滞阈值）
 *       是本类内部模式，不进 IAgent 接口。</li>
 *   <li><b>第3条</b>：把"agent 可选"这个不实在的约束，实在化为 SmarterAgent 实现类。</li>
 * </ul>
 * <p>
 * <b>生命周期</b>：由 {@link SmarterClientService} 管理。SmarterClientService.init() 调
 * {@link AgentFactory#create} 创建本类（已注入 ai），再调 {@link #setDtDebugEnabled} 应用全局调试状态，
 * 最后调 {@link #awaken} 创建资源并唤醒 ai。shutdown 时 SmarterClientService 调 {@link #shutdown}。
 */
public class SmarterAgent implements IAgent {

    private static final Logger LOGGER = LoggerFactory.getLogger("ReflexArcSystem");

    private final IAiSystem ai;

    private BoolVector feelingBuffer;
    private Stream cudaStream;
    /**
     * 视觉采集完成事件。
     * <p>
     * 视觉 kernel 在 cudaStream 上写完 feelingBuffer 后 record 此 event；
     * AI 在每轮开头 waitEvent，确保读到完整视觉数据。
     */
    private Event visionEvent;

    /**
     * 池化的临时纹理，用于视觉采样时的快照隔离。
     */
    private Texture snapshotTexture;

    /**
     * 效应器：把 AI 产出的 256-bit behavior 解码为 ActionIntent。
     * 有状态（TensionIntegrator 低通滤波 + 迟滞阈值），构造一次、每客户端 tick 复用。
     */
    private MotorOps motorOps;

    /**
     * 行为产出出口（意识-外周边界对象）。
     * 持有 mapped behavior buffer + generation 计数器。由外周创建并注入 AI 系统，
     * AI 用其 producer 面（写入 buffer + declareProduced），本类用其 consumer 面
     * （getGeneration / readBehavior）零 CUDA 调用消费。
     */
    private BehaviorOutlet behaviorOutlet;

    /**
     * 池化的 behavior host 暂存（256 bit = 8 个 int）。主线程在 onClientTick 里，
     * 当 generation 变化时从 outlet 读到此缓冲，交 MotorOps 解码。
     */
    private int[] behaviorScratch;

    /**
     * 上次消费的 behavior generation 值。用于检测 AI 是否产出了新 behavior。
     * 主线程零 CUDA 调用：仅读 outlet.getGeneration()（纯 host 内存读）。
     */
    private int lastGen = -1;

    /**
     * 最近一次发包目标 maid 的实体 id。shutdown 时用它发一帧零 ActionIntent，
     * 让 maid 停止（避免客户端停发后服务端继续执行上一帧陈旧 intent）。
     */
    private int lastMaidId = 0;

    private boolean dtDebugEnabled = false;

    /**
     * 注入构造函数：直接注入本类使用的 AI 系统抽象。换 ai 时本类零改动。
     *
     * @param ai AI 系统抽象（如 ProcessAiSystem，内部已注入 process/nn）。
     */
    public SmarterAgent(IAiSystem ai) {
        this.ai = ai;
    }

    @Override
    public void awaken() {
        this.feelingBuffer = new BoolVector(this.ai.feelingSize());
        this.behaviorScratch = new int[this.ai.behaviorSize() / 32];
        this.ai.setDtDebugEnabled(this.dtDebugEnabled);
        this.cudaStream = new Stream();
        // 视觉采集完成事件：视觉写完 feelingBuffer 后在 cudaStream 上 record，
        // AI 每轮开头 waitEvent 跨流等待，替代旧的 NULL 流隐式屏障。
        this.visionEvent = new Event();

        this.snapshotTexture = new Texture(VisionOps.AI_WIDTH, VisionOps.AI_HEIGHT);

        // 效应器解码器（仿生肌肉模型，PolarLayout.defaultHumanLike）。
        this.motorOps = new MotorOps();

        // 行为产出出口：由外周创建，持有 mapped buffer + generation 计数器。
        // 注入 AI 系统供其 producer 面使用，本类用其 consumer 面零 CUDA 调用消费。
        this.behaviorOutlet = new BehaviorOutlet(this.ai.behaviorSize());

        // 唤醒意识体：启动内部工作线程持续运转，
        // 注入感觉缓冲区引用供工作线程每轮读取（AI 与 Minecraft tick 解耦）。
        this.ai.awaken(this.feelingBuffer, this.visionEvent, this.behaviorOutlet);

        // 复位 generation 消费游标，确保二次附身时首轮必读。
        this.lastGen = -1;

        LOGGER.info("[ReflexArc] 初始化完成 (feeling={} bits, behavior={} bits, snapshot={}x{})",
                this.ai.feelingSize(), this.ai.behaviorSize(), VisionOps.AI_WIDTH, VisionOps.AI_HEIGHT);
        logGpuMemory("init完成");
    }

    @Override
    public void onClientTick() {
        if (ai == null || motorOps == null) {
            return;
        }
        EntityMaid maid = PossessionManager.INSTANCE.getPossessedMaid();
        if (maid == null) {
            return;
        }
        // smarter mode 关闭时不发包（避免空发 20 包/秒；服务端 ServerboundActionIntentPacket.handle 的 isEnabled 校验也会拦截）。
        if (!PossessionManager.INSTANCE.isSmarterModeEnabled(maid)) {
            return;
        }
        lastMaidId = maid.getId();
        try {
            // 读 generation（纯 host 内存读，零 CUDA 调用，不 flush WDDM 命令缓冲）。
            // generation 变化 = AI 已产出新 behavior 且 GPU 已写完 mapped buffer（流内有序保证）。
            int gen = behaviorOutlet.getGeneration();
            if (gen != lastGen) {
                lastGen = gen;
                // 从 mapped host 内存读完整 behavior 到 scratch（纯 host memcpy，零 CUDA 调用）。
                behaviorOutlet.readBehavior(behaviorScratch);
            }
            // fresh=false（gen 未变）时 behaviorScratch 保持上次值，MotorOps 继续低通滤波（肌肉保持张力）。
            // MotorOps.tick 返回复用实例，立即序列化发包，不跨 tick 持有引用。
            ActionIntent intent = motorOps.tick(behaviorScratch);
            // 效应器调试观察点：在效应器产出 intent 后、发包前输出人话指令。
            EffectorDebugHook.INSTANCE.log(intent);
            NetworkHandler.INSTANCE.sendToServer(new ServerboundActionIntentPacket(maid.getId(), intent));
        } catch (Exception e) {
            LOGGER.error("[ReflexArc] 效应器解码/发包异常", e);
        }
    }

    @Override
    public void onPostRender(int textureId, int texWidth, int texHeight) {
        // 视觉采样在 cudaStream 上异步执行，与 AI 的专用流并发：
        // AI 重计算 kernel 与 D2D/H2D 拷贝跑在 AI 流，两者不再因 NULL 流串行而互相挂起。
        // vision→AI 的跨流数据可见性由 visionEvent 显式同步：采集完成后 record，
        // AI 每轮开头 waitEvent 等待，确保读到完整 feelingBuffer。
        try {
            VisionOps.captureScreenViaSnapshot(
                    textureId,
                    snapshotTexture,
                    feelingBuffer,
                    new Span(0, feelingBuffer.size()) {},
                    texWidth, texHeight,
                    cudaStream);
            // 视觉写完 feelingBuffer 后在 cudaStream 上 record，供 AI 流跨流等待。
            visionEvent.record(cudaStream.getHandle());
        } catch (Exception e) {
            LOGGER.error("[ReflexArc] 视觉捕获异常", e);
        }
    }

    @Override
    public void shutdown() {
        LOGGER.info("[ReflexArc] 关闭 ReflexArcSystem...");
        // 停止 AI 工作线程并释放其内部资源（join 工作线程，最多 1.5s+0.5s）。
        // shutdown 内部已调用 close()，且会先 join 工作线程，确保不再并发访问 feelingBuffer / outlet。
        if (ai != null) {
            ai.shutdown();
        }
        // behaviorOutlet 必须在 ai.shutdown() join 工作线程之后关闭：
        // 工作线程每轮写入 outlet 的 buffer + declareProduced，join 完成后无人再访问它，方可安全销毁。
        if (behaviorOutlet != null) {
            try { behaviorOutlet.close(); } catch (Exception ignored) {}
            behaviorOutlet = null;
        }
        // visionEvent 必须在 ai.shutdown() join 工作线程之后关闭：
        // 工作线程每轮开头会 waitEvent(visionEvent)，join 完成后无人再访问它，方可安全销毁。
        if (visionEvent != null) {
            try { visionEvent.close(); } catch (Exception ignored) {}
        }
        if (cudaStream != null) {
            try { cudaStream.close(); } catch (Exception ignored) {}
        }

        if (snapshotTexture != null) {
            try { snapshotTexture.close(); } catch (Exception ignored) {}
        }

        if (feelingBuffer != null) {
            try { feelingBuffer.close(); } catch (Exception ignored) {}
        }

        // 效应器清理：复位张力/迟滞状态，并发一帧零 ActionIntent 让 maid 停止——
        // 客户端停发后服务端不再收到新 intent，若不发零帧，maid 会卡在上一帧陈旧动作上。
        if (motorOps != null) {
            try { motorOps.reset(); } catch (Exception ignored) {}
        }
        if (lastMaidId != 0) {
            try {
                NetworkHandler.INSTANCE.sendToServer(
                        new ServerboundActionIntentPacket(lastMaidId, new ActionIntent()));
            } catch (Exception ignored) {}
            lastMaidId = 0;
        }
        lastGen = -1;
    }

    @Override
    public void setDtDebugEnabled(boolean enabled) {
        this.dtDebugEnabled = enabled;
        if (ai != null) {
            ai.setDtDebugEnabled(enabled);
        }
    }

    @Override
    public boolean isDtDebugEnabled() {
        return dtDebugEnabled;
    }

    /**
     * 打印当前 GPU 显存使用情况。轻量级 driver 查询，单次开销微秒级，可低频调用。
     */
    private void logGpuMemory(String tag) {
        try {
            long[] info = MemoryDiagnostics._getMemInfo();
            long free = info[0];
            long total = info[1];
            long used = total - free;
            LOGGER.info("[ReflexArc][VRAM] {} 用={} MB / 空闲={} MB / 总={} MB",
                    tag, used / (1024L * 1024L), free / (1024L * 1024L), total / (1024L * 1024L));
        } catch (Exception e) {
            LOGGER.warn("[ReflexArc][VRAM] {} 查询失败", tag, e);
        }
    }

    /**
     * debug 专用：暴露感觉缓冲区供 {@link com.github.magif1712.smarter_touhou_maids.features.smarter.agent.debug.VisionDebugHook} dump。
     * 不进 {@link IAgent} 接口——附属 agent 若有不同的视觉系统，应有自己的 debug hook。
     */
    public BoolVector getFeelingBuffer() {
        return feelingBuffer;
    }
}
