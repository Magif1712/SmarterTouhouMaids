package com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.registry;

import com.github.magif1712.smarter_touhou_maids.SmarterTouhouMaids;
import net.minecraft.resources.ResourceLocation;

/**
 * 主模组注册的三个 registry 的 id 常量（真善美第3条：把"有哪些层"实在化为常量）。
 * <p>
 * config 的 key 用 {@code registryId.toString()}（如 "smarter_touhou_maids:ai"），
 * 各层 factory 按需读对应 key。附属模组用自己的 mod id 命名空间注册新 registry。
 */
public final class RegistryIds {
    /** 顶层 agent registry：选哪个 agent 实现（smarter / 附属的别的 agent） */
    public static final ResourceLocation AGENT = new ResourceLocation(SmarterTouhouMaids.MOD_ID, "agent");
    /** ai registry：选哪个 ai 实现（流程型 / 纯规则 / ...），仅当上层 agent 需要 ai 时展开 */
    public static final ResourceLocation AI = new ResourceLocation(SmarterTouhouMaids.MOD_ID, "ai");
    /** 流程系统 registry：选哪个 process 实现（urana / ...），仅当上层 ai 需要 process 时展开 */
    public static final ResourceLocation PROCESS = new ResourceLocation(SmarterTouhouMaids.MOD_ID, "process");
    /** 神经网络 registry：选哪个 nn 实现（bnn / cnn / ...），仅当上层 process 需要 nn 时展开 */
    public static final ResourceLocation NN = new ResourceLocation(SmarterTouhouMaids.MOD_ID, "nn");

    private RegistryIds() {
    }
}
