#pragma once
#include <cuda_runtime.h>
#include <device_atomic_functions.h>
#include <stdexcept>
#include <string>
#include <vector>
#include <cstdint>
#include <fstream>

#include "core/utils/CudaBitUtils.h"

template <typename T>
class Vector
{
private:
    T *d_data;
    size_t m_size;

    static void checkCudaError(cudaError_t err, const char *msg)
    {
        if (err != cudaSuccess)
        {
            throw std::runtime_error(std::string(msg) + ": " + cudaGetErrorString(err));
        }
    }

    void release() noexcept
    {
        if (d_data != nullptr)
        {
            cudaFree(d_data);
            d_data = nullptr;
        }
        m_size = 0;
    }

public:
    Vector() : d_data(nullptr), m_size(0) {}

    explicit Vector(size_t size) : d_data(nullptr), m_size(size)
    {
        if (m_size > 0)
        {
            cudaError_t err = cudaMalloc(reinterpret_cast<void **>(&d_data), bytes());
            checkCudaError(err, "Failed to allocate device memory for Vector");
            cudaMemset(d_data, 0, bytes());
        }
    }

    ~Vector() { release(); }

    Vector(const Vector &) = delete;
    Vector &operator=(const Vector &) = delete;

    Vector(Vector &&other) noexcept : d_data(other.d_data), m_size(other.m_size)
    {
        other.d_data = nullptr;
        other.m_size = 0;
    }

    Vector &operator=(Vector &&other) noexcept
    {
        if (this != &other)
        {
            release();
            d_data = other.d_data;
            m_size = other.m_size;
            other.d_data = nullptr;
            other.m_size = 0;
        }
        return *this;
    }

    void allocate(size_t new_size)
    {
        if (m_size == new_size) return;

        release();
        m_size = new_size;
        if (m_size > 0)
        {
            cudaError_t err = cudaMalloc(reinterpret_cast<void **>(&d_data), bytes());
            checkCudaError(err, "Failed to allocate device memory in Vector::allocate()");
            cudaMemset(d_data, 0, bytes());
        }
    }

    T *data() { return d_data; }
    const T *data() const { return d_data; }
    size_t size() const { return m_size; }
    size_t bytes() const { return m_size * sizeof(T); }

    void copyFromHost(const T *h_data, size_t count)
    {
        copyRegionFromHost(0, h_data, count);
    }

    void copyToHost(T *h_data, size_t count) const
    {
        if (count > m_size)
            throw std::out_of_range("Count exceeds vector size");
        if (count == 0)
            return;
        if (h_data == nullptr)
            throw std::invalid_argument("Host data pointer must not be null when count is positive");

        cudaError_t err = cudaMemcpy(h_data, d_data, count * sizeof(T), cudaMemcpyDeviceToHost);
        checkCudaError(err, "Failed to copy device to host (Vector)");
    }

    void copyRegionFrom(size_t dest_offset, const Vector<T>& source, size_t src_offset, size_t count, cudaStream_t stream = 0)
    {
        if (count == 0) return;

        if (dest_offset + count > m_size)
        {
            throw std::out_of_range("copyRegionFrom would write out of bounds of the destination vector.");
        }
        if (src_offset + count > source.size())
        {
            throw std::out_of_range("copyRegionFrom would read out of bounds of the source vector.");
        }

        cudaError_t err = cudaMemcpyAsync(
            d_data + dest_offset,
            source.data() + src_offset,
            count * sizeof(T),
            cudaMemcpyDeviceToDevice,
            stream
        );
        checkCudaError(err, "Failed to copy region between vectors");
    }

    void setRegion(size_t dest_offset, const Vector<T>& source, cudaStream_t stream = 0)
    {
        if (source.size() == 0) return;
        copyRegionFrom(dest_offset, source, 0, source.size(), stream);
    }

    void copyRegionFromHost(size_t dest_offset, const T* h_data, size_t count, cudaStream_t stream = 0)
    {
        if (count == 0) return;

        if (dest_offset + count > m_size)
        {
            throw std::out_of_range("copyRegionFromHost would write out of bounds of the destination vector.");
        }
        if (h_data == nullptr)
        {
            throw std::invalid_argument("Host data pointer must not be null when count is positive");
        }

        cudaError_t err = cudaMemcpyAsync(
            d_data + dest_offset,
            h_data,
            count * sizeof(T),
            cudaMemcpyHostToDevice,
            stream
        );
        checkCudaError(err, "Failed to copy region from host to vector");
    }

    void save(const std::string &filename) const
    {
        std::ofstream ofs(filename, std::ios::binary);
        if (!ofs)
            throw std::runtime_error("Failed to open file for saving: " + filename);

        ofs.write(reinterpret_cast<const char *>(&m_size), sizeof(m_size));

        if (m_size > 0)
        {
            std::vector<T> h_data(m_size);
            copyToHost(h_data.data(), m_size);
            ofs.write(reinterpret_cast<const char *>(h_data.data()), bytes());
        }
    }

    void loadFromFile(const std::string &filename)
    {
        std::ifstream ifs(filename, std::ios::binary);
        if (!ifs)
            throw std::runtime_error("Failed to open file for loading: " + filename);

        size_t saved_size;
        ifs.read(reinterpret_cast<char *>(&saved_size), sizeof(saved_size));

        allocate(saved_size);

        if (saved_size > 0)
        {
            std::vector<T> h_data(saved_size);
            ifs.read(reinterpret_cast<char *>(h_data.data()), bytes());
            if (!ifs)
                throw std::runtime_error("Error reading data from file: " + filename);
            copyFromHost(h_data.data(), saved_size);
        }
    }
};

template <>
class Vector<bool>
{
private:
    uint32_t *d_data;
    size_t m_size;

    static void checkCudaError(cudaError_t err, const char *msg)
    {
        if (err != cudaSuccess)
        {
            throw std::runtime_error(std::string(msg) + ": " + cudaGetErrorString(err));
        }
    }

    void release() noexcept
    {
        if (d_data != nullptr)
        {
            cudaFree(d_data);
            d_data = nullptr;
        }
        m_size = 0;
    }

    static size_t getWordCount(size_t size)
    {
        return (size + 31) / 32;
    }

public:
    Vector() : d_data(nullptr), m_size(0) {}

    explicit Vector(size_t size) : d_data(nullptr), m_size(size)
    {
        if (m_size > 0)
        {
            cudaError_t err = cudaMalloc(reinterpret_cast<void **>(&d_data), bytes());
            checkCudaError(err, "Failed to allocate device memory for bool vector (bit-packed)");
            cudaMemset(d_data, 0, bytes());
        }
    }

    ~Vector() { release(); }

    Vector(const Vector &) = delete;
    Vector &operator=(const Vector &) = delete;

    Vector(Vector &&other) noexcept : d_data(other.d_data), m_size(other.m_size)
    {
        other.d_data = nullptr;
        other.m_size = 0;
    }

    Vector &operator=(Vector &&other) noexcept
    {
        if (this != &other)
        {
            release();
            d_data = other.d_data;
            m_size = other.m_size;
            other.d_data = nullptr;
            other.m_size = 0;
        }
        return *this;
    }

    void allocate(size_t new_size)
    {
        if (m_size == new_size) return;

        release();
        m_size = new_size;
        if (m_size > 0)
        {
            cudaError_t err = cudaMalloc(reinterpret_cast<void **>(&d_data), bytes());
            checkCudaError(err, "Failed to allocate device memory for bool vector (bit-packed) in allocate()");
            cudaMemset(d_data, 0, bytes());
        }
    }

    uint32_t *data() { return d_data; }
    const uint32_t *data() const { return d_data; }
    size_t size() const { return m_size; }
    size_t wordCount() const { return getWordCount(m_size); }
    size_t bytes() const { return wordCount() * sizeof(uint32_t); }

    void copyFromHost(const uint32_t *h_data, size_t wordCount)
    {
        if (wordCount > this->wordCount())
            throw std::out_of_range("Word count exceeds vector capacity");
        if (wordCount == 0)
            return;
        if (h_data == nullptr)
            throw std::invalid_argument("Host data pointer must not be null");

        cudaError_t err = cudaMemcpy(d_data, h_data, wordCount * sizeof(uint32_t), cudaMemcpyHostToDevice);
        checkCudaError(err, "Failed to copy raw bit-packed data from host to device (Vector<bool>)");
    }

    void copyToHost(uint32_t *h_data, size_t wordCount) const
    {
        if (wordCount > this->wordCount())
            throw std::out_of_range("Word count exceeds vector capacity");
        if (wordCount == 0)
            return;
        if (h_data == nullptr)
            throw std::invalid_argument("Host data pointer must not be null");

        cudaError_t err = cudaMemcpy(h_data, d_data, wordCount * sizeof(uint32_t), cudaMemcpyDeviceToHost);
        checkCudaError(err, "Failed to copy raw bit-packed data from device to host (Vector<bool>)");
    }

    void save(const std::string &filename) const
    {
        std::ofstream ofs(filename, std::ios::binary);
        if (!ofs)
            throw std::runtime_error("Failed to open file for saving: " + filename);

        ofs.write(reinterpret_cast<const char *>(&m_size), sizeof(m_size));

        if (m_size > 0)
        {
            std::vector<uint32_t> h_data(wordCount());
            copyToHost(h_data.data(), wordCount());
            ofs.write(reinterpret_cast<const char *>(h_data.data()), bytes());
        }
    }

    void loadFromFile(const std::string &filename)
    {
        std::ifstream ifs(filename, std::ios::binary);
        if (!ifs)
            throw std::runtime_error("Failed to open file for loading: " + filename);

        size_t saved_size;
        ifs.read(reinterpret_cast<char *>(&saved_size), sizeof(saved_size));

        allocate(saved_size);

        if (saved_size > 0)
        {
            std::vector<uint32_t> h_data(wordCount());
            ifs.read(reinterpret_cast<char *>(h_data.data()), bytes());
            if (!ifs)
                throw std::runtime_error("Error reading bit-packed data from file: " + filename);
            copyFromHost(h_data.data(), wordCount());
        }
    }

    void copyRegionFrom(size_t dest_offset_bits, const Vector<bool>& source, size_t src_offset_bits, size_t num_bits, cudaStream_t stream = 0)
    {
        if (num_bits == 0) return;

        if (dest_offset_bits + num_bits > this->m_size)
        {
            throw std::out_of_range("copyRegionFrom would write out of bounds of the destination vector.");
        }
        if (src_offset_bits + num_bits > source.size())
        {
            throw std::out_of_range("copyRegionFrom would read out of bounds of the source vector.");
        }

        stm_ai::core::utils::CudaBitCopy(
            this->d_data,
            this->size(),
            dest_offset_bits,
            source.data(),
            source.size(),
            src_offset_bits,
            num_bits,
            stream
        );
    }

    void setRegion(size_t dest_offset_bits, const Vector<bool>& source, cudaStream_t stream = 0)
    {
        if (source.size() == 0) return;

        this->copyRegionFrom(
            dest_offset_bits,
            source,
            0,
            source.size(),
            stream
        );
    }

    void copyRegionFromHost(size_t dest_offset_bits, const unsigned char* src_host_data, size_t num_bits, cudaStream_t stream = 0)
    {
        if (num_bits == 0) return;

        if (dest_offset_bits + num_bits > this->m_size)
        {
            throw std::out_of_range("copyRegionFromHost would write out of bounds of the destination vector.");
        }

        stm_ai::core::utils::CudaBitCopyFromHost(
            this->d_data,
            this->size(),
            dest_offset_bits,
            src_host_data,
            num_bits,
            stream
        );
    }

    __device__ static inline bool getBit(const uint32_t *data, size_t index)
    {
        return (data[index >> 5] >> (index & 31)) & 1u;
    }

    __device__ static inline void setBitAtomic(uint32_t *data, size_t index, bool val)
    {
        uint32_t mask = (1u << (index & 31));
        if (val)
            atomicOr(&data[index >> 5], mask);
        else
            atomicAnd(&data[index >> 5], ~mask);
    }

    __device__ static inline void setBitUnsafe(uint32_t *data, size_t index, bool val)
    {
        uint32_t mask = (1u << (index & 31));
        if (val)
            data[index >> 5] |= mask;
        else
            data[index >> 5] &= ~mask;
    }
};