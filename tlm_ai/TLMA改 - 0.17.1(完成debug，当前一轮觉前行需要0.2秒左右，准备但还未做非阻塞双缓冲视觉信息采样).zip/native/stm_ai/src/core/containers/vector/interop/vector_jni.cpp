#include <jni.h>
#include <cstdint>
#include <vector>
#include <memory>
#include <exception>
#include "../../../interop/jni_helper.h"
#include "vector_bridge.h"

// 设计说明：
// 所有 JNI 函数都使用 try-catch + JNI_CATCH_TRANSLATE 宏包裹函数体。
// 这样 bridge 层重新抛出的 C++ 异常会被捕获并转换为 Java RuntimeException，
// 避免 C++ 异常穿过 JNI 边界导致 JVM 崩溃 (EXCEPTION_UNCAUGHT_CXX_EXCEPTION)。

extern "C"
{

    JNIEXPORT jlong JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1createVectorBool)(JNIEnv *env, jclass)
    {
        try
        {
            auto *vec = VectorCreateBool();
            return reinterpret_cast<jlong>(vec);
        }
        JNI_CATCH_TRANSLATE(env, "_createVectorBool")
        return 0;
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1allocateBool)(JNIEnv *env, jclass, jlong handle, jint size)
    {
        try
        {
            auto *vec = reinterpret_cast<Vector<bool> *>(handle);
            if (vec)
                VectorAllocateBool(vec, static_cast<size_t>(size));
        }
        JNI_CATCH_TRANSLATE(env, "_allocateBool")
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1deleteVectorBool)(JNIEnv *env, jclass, jlong handle)
    {
        try
        {
            auto *vec = reinterpret_cast<Vector<bool> *>(handle);
            if (vec)
                VectorDeleteBool(vec);
        }
        JNI_CATCH_TRANSLATE(env, "_deleteVectorBool")
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1copyFromHostBool)(JNIEnv *env, jclass, jlong handle, jintArray data, jint count)
    {
        try
        {
            auto *vec = reinterpret_cast<Vector<bool> *>(handle);
            if (!vec || !data)
                return;

            jint *j_data = env->GetIntArrayElements(data, nullptr);
            VectorCopyFromHostBool(vec, reinterpret_cast<const uint32_t *>(j_data), static_cast<size_t>(count));
            env->ReleaseIntArrayElements(data, j_data, JNI_ABORT);
        }
        JNI_CATCH_TRANSLATE(env, "_copyFromHostBool")
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1copyToHostBool)(JNIEnv *env, jclass, jlong handle, jintArray data, jint count)
    {
        try
        {
            auto *vec = reinterpret_cast<Vector<bool> *>(handle);
            if (!vec || !data)
                return;

            jint *j_data = env->GetIntArrayElements(data, nullptr);
            VectorCopyToHostBool(vec, reinterpret_cast<uint32_t *>(j_data), static_cast<size_t>(count));
            env->ReleaseIntArrayElements(data, j_data, 0);
        }
        JNI_CATCH_TRANSLATE(env, "_copyToHostBool")
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1saveBool)(JNIEnv *env, jclass, jlong handle, jstring filename)
    {
        try
        {
            auto *vec = reinterpret_cast<Vector<bool> *>(handle);
            if (!vec || !filename)
                return;

            const char *c_filename = env->GetStringUTFChars(filename, nullptr);
            VectorSaveBool(vec, c_filename);
            env->ReleaseStringUTFChars(filename, c_filename);
        }
        JNI_CATCH_TRANSLATE(env, "_saveBool")
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1loadFromFileBool)(JNIEnv *env, jclass, jlong handle, jstring filename)
    {
        try
        {
            auto *vec = reinterpret_cast<Vector<bool> *>(handle);
            if (!vec || !filename)
                return;

            const char *c_filename = env->GetStringUTFChars(filename, nullptr);
            VectorLoadFromFileBool(vec, c_filename);
            env->ReleaseStringUTFChars(filename, c_filename);
        }
        JNI_CATCH_TRANSLATE(env, "_loadFromFileBool")
    }

    JNIEXPORT jint JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1getSizeBool)(JNIEnv *env, jclass, jlong handle)
    {
        try
        {
            auto *vec = reinterpret_cast<Vector<bool> *>(handle);
            return static_cast<jint>(VectorGetSizeBool(vec));
        }
        JNI_CATCH_TRANSLATE(env, "_getSizeBool")
        return 0;
    }

    JNIEXPORT jlong JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1createVectorInt)(JNIEnv *env, jclass)
    {
        try
        {
            auto *vec = VectorCreateInt();
            return reinterpret_cast<jlong>(vec);
        }
        JNI_CATCH_TRANSLATE(env, "_createVectorInt")
        return 0;
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1allocateInt)(JNIEnv *env, jclass, jlong handle, jint size)
    {
        try
        {
            auto *vec = reinterpret_cast<Vector<int> *>(handle);
            if (vec)
                VectorAllocateInt(vec, static_cast<size_t>(size));
        }
        JNI_CATCH_TRANSLATE(env, "_allocateInt")
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1deleteVectorInt)(JNIEnv *env, jclass, jlong handle)
    {
        try
        {
            auto *vec = reinterpret_cast<Vector<int> *>(handle);
            if (vec)
                VectorDeleteInt(vec);
        }
        JNI_CATCH_TRANSLATE(env, "_deleteVectorInt")
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1copyFromHostInt)(JNIEnv *env, jclass, jlong handle, jintArray data, jint count)
    {
        try
        {
            auto *vec = reinterpret_cast<Vector<int> *>(handle);
            if (!vec || !data)
                return;

            jint *j_data = env->GetIntArrayElements(data, nullptr);
            VectorCopyFromHostInt(vec, reinterpret_cast<const int *>(j_data), static_cast<size_t>(count));
            env->ReleaseIntArrayElements(data, j_data, JNI_ABORT);
        }
        JNI_CATCH_TRANSLATE(env, "_copyFromHostInt")
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1copyToHostInt)(JNIEnv *env, jclass, jlong handle, jintArray data, jint count)
    {
        try
        {
            auto *vec = reinterpret_cast<Vector<int> *>(handle);
            if (!vec || !data)
                return;

            jint *j_data = env->GetIntArrayElements(data, nullptr);
            VectorCopyToHostInt(vec, reinterpret_cast<int *>(j_data), static_cast<size_t>(count));
            env->ReleaseIntArrayElements(data, j_data, 0);
        }
        JNI_CATCH_TRANSLATE(env, "_copyToHostInt")
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1saveInt)(JNIEnv *env, jclass, jlong handle, jstring filename)
    {
        try
        {
            auto *vec = reinterpret_cast<Vector<int> *>(handle);
            if (!vec || !filename)
                return;

            const char *c_filename = env->GetStringUTFChars(filename, nullptr);
            VectorSaveInt(vec, c_filename);
            env->ReleaseStringUTFChars(filename, c_filename);
        }
        JNI_CATCH_TRANSLATE(env, "_saveInt")
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1loadFromFileInt)(JNIEnv *env, jclass, jlong handle, jstring filename)
    {
        try
        {
            auto *vec = reinterpret_cast<Vector<int> *>(handle);
            if (!vec || !filename)
                return;

            const char *c_filename = env->GetStringUTFChars(filename, nullptr);
            VectorLoadFromFileInt(vec, c_filename);
            env->ReleaseStringUTFChars(filename, c_filename);
        }
        JNI_CATCH_TRANSLATE(env, "_loadFromFileInt")
    }

    JNIEXPORT jint JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1getSizeInt)(JNIEnv *env, jclass, jlong handle)
    {
        try
        {
            auto *vec = reinterpret_cast<Vector<int> *>(handle);
            return static_cast<jint>(VectorGetSizeInt(vec));
        }
        JNI_CATCH_TRANSLATE(env, "_getSizeInt")
        return 0;
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1copyRegionFromInt)(JNIEnv *env, jclass, jlong dst_handle, jlong dst_offset, jlong src_handle, jlong src_offset, jlong count)
    {
        try
        {
            auto *dst = reinterpret_cast<Vector<int> *>(dst_handle);
            auto *src = reinterpret_cast<Vector<int> *>(src_handle);
            if (dst && src)
            {
                VectorCopyRegionFromInt(dst, static_cast<size_t>(dst_offset), src, static_cast<size_t>(src_offset), static_cast<size_t>(count));
            }
        }
        JNI_CATCH_TRANSLATE(env, "_copyRegionFromInt")
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1setRegionInt)(JNIEnv *env, jclass, jlong dst_handle, jlong dst_offset, jlong src_handle)
    {
        try
        {
            auto *dst = reinterpret_cast<Vector<int> *>(dst_handle);
            auto *src = reinterpret_cast<Vector<int> *>(src_handle);
            if (dst && src)
            {
                VectorSetRegionInt(dst, static_cast<size_t>(dst_offset), src);
            }
        }
        JNI_CATCH_TRANSLATE(env, "_setRegionInt")
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1copyRegionFromHostInt)(JNIEnv *env, jclass, jlong dst_handle, jlong dst_offset, jintArray src_array, jlong count)
    {
        try
        {
            auto *dst = reinterpret_cast<Vector<int> *>(dst_handle);
            if (!dst || !src_array)
                return;

            jint *src_ptr = env->GetIntArrayElements(src_array, nullptr);
            if (src_ptr == nullptr)
                return; // 内存不足

            VectorCopyRegionFromHostInt(dst, static_cast<size_t>(dst_offset), reinterpret_cast<const int *>(src_ptr), static_cast<size_t>(count));

            env->ReleaseIntArrayElements(src_array, src_ptr, JNI_ABORT);
        }
        JNI_CATCH_TRANSLATE(env, "_copyRegionFromHostInt")
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1scatterBits)(JNIEnv *env, jclass, jlong srcHandle, jlong dstHandle, jlong pHandle)
    {
        try
        {
            auto *src = reinterpret_cast<Vector<bool> *>(srcHandle);
            auto *dst = reinterpret_cast<Vector<bool> *>(dstHandle);
            auto *p = reinterpret_cast<Vector<int> *>(pHandle);
            if (src && dst && p)
            {
                VectorScatterBits(src, dst, p);
            }
        }
        JNI_CATCH_TRANSLATE(env, "_scatterBits")
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1xorBool)(JNIEnv *env, jclass, jlong dstHandle, jlong srcHandle)
    {
        try
        {
            auto *dst = reinterpret_cast<Vector<bool> *>(dstHandle);
            auto *src = reinterpret_cast<Vector<bool> *>(srcHandle);
            if (dst && src)
            {
                VectorXorBool(dst, src);
            }
        }
        JNI_CATCH_TRANSLATE(env, "_xorBool")
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1setRegionBool)(JNIEnv *env, jclass, jlong dstHandle, jlong destOffset, jlong srcHandle)
    {
        try
        {
            auto *dst = reinterpret_cast<Vector<bool> *>(dstHandle);
            auto *src = reinterpret_cast<Vector<bool> *>(srcHandle);
            if (dst && src)
            {
                VectorSetRegionBool(dst, static_cast<size_t>(destOffset), src);
            }
        }
        JNI_CATCH_TRANSLATE(env, "_setRegionBool")
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1copyRegionFromBool)(JNIEnv *env, jclass, jlong dstHandle, jlong dstOffset, jlong srcHandle, jlong srcOffset, jlong numBits)
    {
        try
        {
            auto *dst = reinterpret_cast<Vector<bool> *>(dstHandle);
            auto *src = reinterpret_cast<Vector<bool> *>(srcHandle);
            if (dst && src)
            {
                VectorCopyRegionFromBool(
                    dst,
                    static_cast<size_t>(dstOffset),
                    src,
                    static_cast<size_t>(srcOffset),
                    static_cast<size_t>(numBits));
            }
        }
        JNI_CATCH_TRANSLATE(env, "_copyRegionFromBool")
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1copyRegionFromHostBool)(
        JNIEnv *env, jclass, jlong handle, jlong dest_offset, jbooleanArray src_data, jint num_bits)
    {
        jboolean *src_ptr = env->GetBooleanArrayElements(src_data, nullptr);
        if (src_ptr == nullptr)
        {
            return;
        }

        try
        {
            auto *dst = reinterpret_cast<Vector<bool> *>(handle);
            VectorCopyRegionFromHostBool(dst, dest_offset, src_ptr, num_bits);
        }
        JNI_CATCH_TRANSLATE(env, "_copyRegionFromHostBool")

        env->ReleaseBooleanArrayElements(src_data, src_ptr, 0);
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1subtractBool)(
        JNIEnv *env, jclass, jlong aHandle, jlong bHandle, jlong bitOffset, jlong cHandle, jlong cIntOffset, jlong bitLength)
    {
        try
        {
            auto *a = reinterpret_cast<Vector<bool> *>(aHandle);
            auto *b = reinterpret_cast<Vector<bool> *>(bHandle);
            auto *c = reinterpret_cast<Vector<int> *>(cHandle);

            if (a && b && c)
            {
                VectorSubtractBool(a, b, bitOffset, c, cIntOffset, bitLength);
            }
        }
        JNI_CATCH_TRANSLATE(env, "_subtractBool")
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1multiplyByScalarInt)(JNIEnv *env, jclass, jlong handle, jint scalar, jlong offset, jlong length)
    {
        try
        {
            auto *vec = reinterpret_cast<Vector<int> *>(handle);
            if (vec)
            {
                VectorMultiplyByScalarInt(vec, scalar, static_cast<size_t>(offset), static_cast<size_t>(length));
            }
        }
        JNI_CATCH_TRANSLATE(env, "_multiplyByScalarInt")
    }


}
