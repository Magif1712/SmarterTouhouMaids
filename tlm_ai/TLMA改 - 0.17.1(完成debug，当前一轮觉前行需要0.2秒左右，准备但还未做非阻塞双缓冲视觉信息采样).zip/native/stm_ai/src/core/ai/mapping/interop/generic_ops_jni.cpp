#include <jni.h>
#include <exception>
#include "core/interop/jni_helper.h"
#include "generic_ops_bridge.h"

#ifdef __cplusplus
extern "C" {
#endif

JNIEXPORT void JNICALL JNI_METHOD(core_ai_mapping, GenericOpsNative, _1negateAndBinarize)(
    JNIEnv* env, jclass clazz, jlong dst_handle, jlong src_handle)
{
    auto* dst = reinterpret_cast<Vector<bool>*>(dst_handle);
    auto* src = reinterpret_cast<const Vector<int>*>(src_handle);
    
    try {
        negateAndBinarizeBridge(dst, src);
    }
    JNI_CATCH_TRANSLATE(env, "_negateAndBinarize")
}

JNIEXPORT void JNICALL JNI_METHOD(core_ai_mapping, GenericOpsNative, _1negateAndBinarizeRegion)(
    JNIEnv* env,
    jclass clazz,
    jlong dst_handle,
    jlong dst_offset,
    jlong src_handle,
    jlong src_offset,
    jlong n)
{
    auto* dst = reinterpret_cast<Vector<bool>*>(dst_handle);
    auto* src = reinterpret_cast<const Vector<int>*>(src_handle);

    try {
        negateAndBinarizeRegionBridge(
            dst,
            static_cast<size_t>(dst_offset),
            src,
            static_cast<size_t>(src_offset),
            static_cast<size_t>(n)
        );
    }
    JNI_CATCH_TRANSLATE(env, "_negateAndBinarizeRegion")
}

#ifdef __cplusplus
}
#endif