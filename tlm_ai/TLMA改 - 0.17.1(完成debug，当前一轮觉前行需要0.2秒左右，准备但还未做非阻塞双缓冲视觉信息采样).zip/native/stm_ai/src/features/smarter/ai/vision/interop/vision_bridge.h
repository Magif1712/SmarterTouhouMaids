#pragma once

// Windows 上 GL/gl.h 依赖 windows.h 定义的 APIENTRY/WINGDIAPI 等宏
// 否则 GLuint/GLEnum 不会被 typedef，cuda_gl_interop.h 会炸
#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#endif

#include <cuda_runtime.h>
#include <GL/gl.h>
#ifdef __cplusplus
template <typename T>
class Vector;
extern "C" {
#endif

cudaError_t captureScreenToBoolVectorBridge(
    GLuint textureId,
    Vector<bool>* dst_vector,
    size_t bitOffset,
    int texWidth,      // 输入纹理实际宽度
    int texHeight,     // 输入纹理实际高度
    int aiWidth,       // AI 视网膜宽度（如 1920）
    int aiHeight,      // AI 视网膜高度（如 1080）
    cudaStream_t stream
);

void cleanupVisionBridge();

#ifdef __cplusplus
}
#endif