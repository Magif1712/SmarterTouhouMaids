#include "vision_bridge.h"
#include "core/interop/jni_helper.h"
#include <cstdint>
#include <exception>

extern "C" {

JNIEXPORT void JNICALL
JNI_METHOD(features_smarter_agent_ai_vision, VisionNative, _1captureScreenToBoolVector)(
    JNIEnv* env, jclass clazz,
    jint textureId, jlong handle, jlong bitOffset,
    jint texWidth, jint texHeight,
    jint aiWidth, jint aiHeight,
    jlong stream_handle
) {
    try {
        auto* bool_vector = reinterpret_cast<Vector<bool>*>(handle);
        cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_handle);

        cudaError_t err = captureScreenToBoolVectorBridge(
            static_cast<GLuint>(textureId), bool_vector,
            static_cast<size_t>(bitOffset),
            static_cast<int>(texWidth),
            static_cast<int>(texHeight),
            static_cast<int>(aiWidth),
            static_cast<int>(aiHeight),
            stream
        );

        if (err != cudaSuccess) {
            jni_helper::throw_runtime_exception(env, cudaGetErrorString(err));
        }
    }
    JNI_CATCH_TRANSLATE(env, "_captureScreenToBoolVector")
}

JNIEXPORT void JNICALL
JNI_METHOD(features_smarter_agent_ai_vision, VisionNative, _1cleanup)(
    JNIEnv* env, jclass clazz
) {
    try {
        cleanupVisionBridge();
    }
    JNI_CATCH_TRANSLATE(env, "_cleanup")
}

} // extern "C"