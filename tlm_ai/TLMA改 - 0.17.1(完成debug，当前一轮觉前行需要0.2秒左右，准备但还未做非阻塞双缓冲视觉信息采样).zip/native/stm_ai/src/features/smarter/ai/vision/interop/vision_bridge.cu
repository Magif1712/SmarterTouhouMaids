#include "vision_bridge.h" 
#include <cuda_gl_interop.h>
#include "../cuda_gl_vision.h" 
#include "core/containers/vector/Vector.h"
#include <unordered_map> 
#include <iostream> 

struct CachedResource { 
    cudaGraphicsResource* resource = nullptr; 
}; 

static std::unordered_map<GLuint, CachedResource> g_resourceCache; 

cudaError_t captureScreenToBoolVectorBridge( 
    GLuint textureId, Vector<bool>* dst_vector, size_t bitOffset, 
    int texWidth, int texHeight, int aiWidth, int aiHeight, cudaStream_t stream) 
{ 
    if (!dst_vector) { 
        return cudaErrorInvalidValue; 
    } 
    uint32_t* dstHandle = dst_vector->data(); 

    if (bitOffset % 32 != 0) { 
        return cudaErrorInvalidValue; 
    } 
    if (aiWidth <= 0 || aiHeight <= 0) { 
        return cudaErrorInvalidValue; 
    } 

    // 1. 查找或注册资源 
    CachedResource* cached = nullptr; 
    auto it = g_resourceCache.find(textureId); 
    if (it != g_resourceCache.end()) { 
        cached = &it->second; 
    } else { 
        cudaGraphicsResource* resource = nullptr; 
        cudaError_t err = cudaGraphicsGLRegisterImage( 
            &resource, textureId, GL_TEXTURE_2D, cudaGraphicsRegisterFlagsReadOnly); 
        if (err != cudaSuccess) return err; 
        g_resourceCache[textureId] = CachedResource{resource}; 
        cached = &g_resourceCache[textureId]; 
    } 

    // 2. Map 
    cudaError_t err = cudaGraphicsMapResources(1, &cached->resource, stream); 
    if (err != cudaSuccess) return err; 

    // 3. Get Array 
    cudaArray_t cuArray; 
    err = cudaGraphicsSubResourceGetMappedArray(&cuArray, cached->resource, 0, 0); 
    if (err != cudaSuccess) { 
        cudaGraphicsUnmapResources(1, &cached->resource, stream); 
        return err; 
    } 

    // 4. Create Texture Object 
    cudaResourceDesc resDesc = {}; 
    resDesc.resType = cudaResourceTypeArray; 
    resDesc.res.array.array = cuArray; 

    cudaTextureDesc texDesc = {}; 
    texDesc.addressMode[0] = cudaAddressModeClamp; 
    texDesc.addressMode[1] = cudaAddressModeClamp; 
    texDesc.filterMode = cudaFilterModePoint; 
    texDesc.readMode = cudaReadModeElementType; 
    texDesc.normalizedCoords = 0; 

    cudaTextureObject_t texObj = 0; 
    err = cudaCreateTextureObject(&texObj, &resDesc, &texDesc, nullptr); 
    if (err != cudaSuccess) { 
        cudaGraphicsUnmapResources(1, &cached->resource, stream); 
        return err; 
    } 

    // 5. 计算指针和参数 
    uint32_t* dstPtr = dstHandle + (bitOffset / 32); 
    int wordsPerPlane = (aiWidth * aiHeight + 31) / 32; 

    // 6. 启动 Kernel 
    err = launchUnpackKernel(texObj, dstPtr, aiWidth, aiHeight, texWidth, texHeight, wordsPerPlane, stream); 
    
    cudaDestroyTextureObject(texObj); 

    if (err != cudaSuccess) { 
        cudaGraphicsUnmapResources(1, &cached->resource, stream); 
        return err; 
    } 

    // 7. 同步并清理 
    err = cudaStreamSynchronize(stream); 
    cudaError_t unmapErr = cudaGraphicsUnmapResources(1, &cached->resource, stream); 
    return (err == cudaSuccess) ? unmapErr : err; 
} 

void cleanupVisionBridge() { 
    for (auto const& [key, val] : g_resourceCache) { 
        cudaGraphicsUnregisterResource(val.resource); 
    } 
    g_resourceCache.clear(); 
}