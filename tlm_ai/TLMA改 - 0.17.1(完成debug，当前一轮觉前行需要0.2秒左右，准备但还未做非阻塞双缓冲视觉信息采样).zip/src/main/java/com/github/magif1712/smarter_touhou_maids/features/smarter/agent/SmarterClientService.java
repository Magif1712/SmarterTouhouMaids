package com.github.magif1712.smarter_touhou_maids.features.smarter.agent;

import com.github.magif1712.smarter_touhou_maids.core.containers.domain.Span;
import com.github.magif1712.smarter_touhou_maids.core.containers.vector.BoolVector;
import com.github.magif1712.smarter_touhou_maids.core.diagnostics.MemoryDiagnostics;
import com.github.magif1712.smarter_touhou_maids.core.execution.Stream;
import com.github.magif1712.smarter_touhou_maids.features.possession.core.PossessionManager;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.UranaSystem;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.semantics.containers.io.InputVectorDomain;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.semantics.containers.io.OutputVectorDomain;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.vision.VisionOps;
import com.github.magif1712.smarter_touhou_maids.features.smarter.network.ServerboundBehaviorSyncPacket;
import com.github.magif1712.smarter_touhou_maids.network.NetworkHandler;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@OnlyIn(Dist.CLIENT)
public enum SmarterClientService {
    INSTANCE;

    private static final Logger LOGGER = LoggerFactory.getLogger("SmarterAgent");

    private static final int FEELING_SIZE = InputVectorDomain.FEELING_SPAN_LENGTH;
    private static final int BEHAVIOR_SIZE = OutputVectorDomain.BEHAVIOR_SPAN_LENGTH;

    private BoolVector feelingBuffer;
    private UranaSystem urana;
    private Stream cudaStream;
    private boolean initialized = false;
    private boolean wasPossessing = false;
    private int frameCounter = 0;
    private static final int CAPTURE_INTERVAL = 3;
    /**
     * 上一轮 onClientTick 的开始时间点（nanoTime），用于计算轮间时间间隔 dt。
     * 0 表示尚未初始化（首轮 dt=0）。
     * TODO 未来 agent 持久化时，改为从磁盘读取上一轮 lastRunStartNanos。
     */
    private long lastTickNanos = 0;
    /**
     * dt 调试开关的持久状态（跨“未附身-附身”保留）。
     * urana 创建时读取此值应用到 UranaSystem。
     */
    private boolean dtDebugEnabled = false;

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        onClientTick();
    }

    public void onPostRender(int textureId, int texWidth, int texHeight) {
        if (!initialized) {
            try {
                init();
            } catch (Exception e) {
                LOGGER.error("[Agent] 初始化异常", e);
                return;
            }
        }

        frameCounter++;
        if (frameCounter < CAPTURE_INTERVAL) {
            return;
        }
        frameCounter = 0;

        try {
            VisionOps.captureScreen(
                    textureId,
                    feelingBuffer,
                    new Span(0, FEELING_SIZE) {},
                    texWidth, texHeight,
                    cudaStream);
        } catch (Exception e) {
            LOGGER.error("[Agent] 视觉捕获异常", e);
        }
    }

    public void onClientTick() {
        boolean isPossessing = PossessionManager.INSTANCE.isPossessing();

        if (wasPossessing && !isPossessing) {
            shutdown();
        }
        wasPossessing = isPossessing;

        if (!initialized) return;
        if (!isPossessing) return;

        EntityMaid maid = PossessionManager.INSTANCE.getPossessedMaid();
        if (maid == null) return;

        try {
            long now = System.nanoTime();
            long dtMillis = (lastTickNanos == 0) ? 0 : (now - lastTickNanos) / 1_000_000;
            lastTickNanos = now;

            urana.runOneTick(feelingBuffer, dtMillis);

            BoolVector behavior = urana.getProspectiveBehaviorBuffer();
            int wordCount = BEHAVIOR_SIZE / 32;
            int[] words = new int[wordCount];
            behavior.copyToHost(words, wordCount);

            long[] behaviorLongs = new long[4];
            for (int i = 0; i < 4; i++) {
                behaviorLongs[i] = ((long) words[i * 2 + 1] << 32) | (words[i * 2] & 0xFFFFFFFFL);
            }

            NetworkHandler.INSTANCE.sendToServer(
                    new ServerboundBehaviorSyncPacket(maid.getId(), behaviorLongs));
        } catch (Exception e) {
            LOGGER.error("[Agent] 推理/发包异常", e);
        }
    }

    /**
     * 打印当前 GPU 显存使用情况。轻量级 driver 查询，单次开销微秒级，可低频调用。
     */
    private void logGpuMemory(String tag) {
        try {
            long[] info = MemoryDiagnostics._getMemInfo();
            long free = info[0];
            long total = info[1];
            long used = total - free;
            LOGGER.info("[Agent][VRAM] {} 用={} MB / 空闲={} MB / 总={} MB",
                    tag, used / (1024L * 1024L), free / (1024L * 1024L), total / (1024L * 1024L));
        } catch (Exception e) {
            LOGGER.warn("[Agent][VRAM] {} 查询失败", tag, e);
        }
    }

    private void init() {
        LOGGER.info("[Agent] 初始化 SmarterClientService...");
        this.feelingBuffer = new BoolVector(FEELING_SIZE);
        this.urana = new UranaSystem();
        this.urana.setDtDebugEnabled(this.dtDebugEnabled);
        this.cudaStream = new Stream();
        this.initialized = true;
        LOGGER.info("[Agent] 初始化完成 (feeling={} bits, behavior={} bits)",
                FEELING_SIZE, BEHAVIOR_SIZE);
        logGpuMemory("init完成");
    }

    ///////////////debug/////////////
    public BoolVector getFeelingBuffer() {
        return feelingBuffer;
    }

    public boolean isDtDebugEnabled() {
        return dtDebugEnabled;
    }

    public void setDtDebugEnabled(boolean enabled) {
        this.dtDebugEnabled = enabled;
        if (urana != null) {
            urana.setDtDebugEnabled(enabled);
        }
    }
    /////////////debug end///////////

    public void shutdown() {
        if (!initialized) return;
        LOGGER.info("[Agent] 关闭 SmarterClientService...");
        try {
            if (urana != null) urana.close();
        } catch (Exception e) {
            LOGGER.error("[Agent] UranaSystem 关闭异常", e);
        }
        if (cudaStream != null) {
            try { cudaStream.close(); } catch (Exception ignored) {}
        }
        if (feelingBuffer != null) {
            try { feelingBuffer.close(); } catch (Exception ignored) {}
        }
        // 重置轮间时间基准：重新附身时首轮 dt=0，避免引入“停止期”的巨大间隔。
        lastTickNanos = 0;
        initialized = false;
    }
}