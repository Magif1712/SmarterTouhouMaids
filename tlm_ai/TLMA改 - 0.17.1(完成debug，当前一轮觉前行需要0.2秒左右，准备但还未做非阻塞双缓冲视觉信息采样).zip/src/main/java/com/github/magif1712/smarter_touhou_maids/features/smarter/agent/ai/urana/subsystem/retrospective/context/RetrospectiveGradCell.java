package com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.subsystem.retrospective.context;

import com.github.magif1712.smarter_touhou_maids.core.containers.vector.BoolVector;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.nn.containers.NetworkData;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.nn.containers.io.IOLayerGradients;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.common.UranaConstants;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.common.grad.AbstractGradCell;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.subsystem.retrospective.RetrospectiveAnchor;

/**
 * 流程六：拟合未来1刻（两阶段训练）。
 * 为 RetrospectiveAnchor 服务，用未来的实际数据来校准自己。
 * 继承 AbstractGradCell，单步链条，内部闭环跨轮次梯度。
 */
public class RetrospectiveGradCell extends AbstractGradCell {
    private static final int CHAIN_LENGTH = 1;

    public RetrospectiveGradCell(NetworkData networkData) {
        this(networkData, null);
    }

    /**
     * 注入共享工作梯度缓冲区的构造函数。
     * 多个串行执行的 GradCell 可共享同一份 IOLayerGradients，省 ~1.5 GB 显存/份。
     *
     * @param sharedGradients 外部注入的工作梯度缓冲区；null 表示本实例自建。
     */
    public RetrospectiveGradCell(NetworkData networkData, IOLayerGradients sharedGradients) {
        super(networkData, CHAIN_LENGTH, UranaConstants.G_FUTURE_1, sharedGradients);
    }

    /**
     * 全自动执行。外界不需要知道 ∇C 的存在。
     */
    public void execute(RetrospectiveAnchor anchor, BoolVector dt) {
        // 填充预分配池：目标是"现在"（悬浮物），输入是"过去"（沉淀物）
        samplePool[0].set(
                anchor.getFeeling().getSuspension(),
                anchor.getBehavior().getSuspension()
        );
        super.executeWithClosedLoop(
                anchor.getFeeling().getPrecipitate(), dt);
    }
}