package com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana;

import com.github.magif1712.smarter_touhou_maids.core.containers.domain.Span;
import com.github.magif1712.smarter_touhou_maids.core.containers.vector.BoolVector;
import com.github.magif1712.smarter_touhou_maids.core.containers.vector.IVector;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.nn.containers.NetworkData;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.nn.containers.io.IOLayerGradients;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.nn.containers.io.value.OutputVector;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.semantics.containers.io.InputVectorDomain;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.semantics.containers.io.OutputVectorDomain;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.semantics.containers.io.subspan.BehaviorSpan;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.semantics.containers.io.subspan.FeelingSpan;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.semantics.containers.io.subspan.InheritanceInfoSpan;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.subsystem.introspective.IntrospectiveAnchor;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.subsystem.introspective.context.IntrospectiveInference;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.subsystem.introspective.context.TrainingContext;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.subsystem.prospective.ProspectiveAnchor;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.subsystem.prospective.context.ProspectiveGradCell;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.subsystem.prospective.context.ProspectiveInference;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.subsystem.retrospective.RetrospectiveAnchor;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.subsystem.retrospective.context.RetrospectiveGradCell;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.subsystem.retrospective.context.RetrospectiveInference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Urana 系统的顶层协调器。
 * 负责初始化并驱动三个认知层次（行动、分析、反思）的8个核心流程。
 * 遵循“真善美”设计原则，此类作为整个 urana AI 功能的唯一入口点，
 * 其结构清晰地反映了它在概念模型中作为“大脑”或“心脏”的顶层地位。
 */
public class UranaSystem implements AutoCloseable {

    private static final OutputVectorDomain OUTPUT_DOMAIN = new OutputVectorDomain();

    // === 尺寸常量 (需要根据实际情况定义) ---
    private static final int FEELING_SIZE = InputVectorDomain.FEELING_SPAN_LENGTH;
    private static final int BEHAVIOR_SIZE = OutputVectorDomain.BEHAVIOR_SPAN_LENGTH;
    private static final int INPUT_SIZE = InputVectorDomain.TOTAL_LENGTH;
    private static final int OUTPUT_SIZE = OutputVectorDomain.TOTAL_LENGTH;
    private static final int DT_SIZE = InputVectorDomain.FEELING_BEHAVIOR_SAMPLING_DT_SPAN_LENGTH; // 假设 dt 向量的大小

    // === 共享网络（唯一实例）===
    private final NetworkData sharedNet;

    /**
     * 三个串行 GradCell 共享的工作梯度缓冲区（inputLayerGradient + outputLayerGradient）。
     * <p>
     * 设计原则（真善美）：
     * 3 个 GradCell 在 runOneTick 中严格串行执行，工作缓冲区天然可复用。
     * 由 UranaSystem 持有所有权并注入给 3 个 GradCell，省 ~3 GB 显存
     * （2 份 inputLayerGradient + 2 份 outputLayerGradient，各 759 MB）。
     * 注意：grad_C_buffer 仍每个 GradCell 独占，因为它承载跨 tick 的状态 ∇C，属于状态层。
     */
    private final IOLayerGradients sharedIOLayerGradients;

    /**
     * 池化的 dt 网络输入缓冲区（64 bit），由外部告知的轮间时间间隔编码而来。
     * 避免每轮重复分配显存。
     */
    private final BoolVector dtBuffer;
    /**
     * 池化的 dt 编码用 packed word 数组（CPU 侧，2 个 uint32 = 64 bit）。
     * dtMillis (long) 直接拆成 2 个 int，避免逐位展开的 64 次循环 + native 打包。
     */
    private final int[] dtPacked;
    /**
     * dt 调试开关：开启时每轮输出轮间时间间隔到日志。关闭时零性能损失。
     */
    private boolean dtDebugEnabled = false;

    private static final Logger LOGGER = LoggerFactory.getLogger("UranaSystem");

    // === 第一层：行动者 (Prospective) ===
    private final ProspectiveAnchor prospectiveAnchor; // 流程一
    private final ProspectiveInference prospectiveInference; // 流程二
    private final ProspectiveGradCell prospectiveGradCell; // 流程三

    // === 第二层：分析师 (Retrospective) ===
    private final RetrospectiveAnchor retrospectiveAnchor; // 流程五
    private final RetrospectiveInference retrospectiveInference; // 流程四
    private final RetrospectiveGradCell retrospectiveGradCell; // 流程六

    // === 第三层：反思者 (Introspective) ===
    private final IntrospectiveAnchor introspectiveAnchor; // 流程七 (数据容器)
    private final IntrospectiveInference introspectiveInference; // 流程七 (推理逻辑)
    private final TrainingContext introspectiveTrainingContext; // 流程八

    // === 跨时间步传递的状态 ===
    private BoolVector prospectiveInheritance;
    private BoolVector retrospectiveInheritance;
    private BoolVector introspectiveInheritance;
    private BoolVector lastRetrospectiveFeeling;

    // === 预分配临时缓冲区，避免每 tick 重复显存分配 ===
    private final BoolVector prospectiveBehaviorBuffer;
    private final OutputVector retroOutputForAnchor;

    /**
     * 构造一个全新的 Urana 系统，并初始化新的共享网络。
     */
    public UranaSystem() {
        this(createNewNetworkData());
    }

    /**
     * 从磁盘加载 Urana 系统，自动恢复核心网络权重。
     * 所有上层组件（Anchor、Inference、GradCell）会根据加载的网络重新初始化。
     * 
     * @param folderPath 保存有网络数据的文件夹路径。
     */
    public static UranaSystem loadFromFile(String folderPath) {
        NetworkData net = NetworkData.loadFromFile(folderPath);
        return new UranaSystem(net);
    }

    /**
     * 将 Urana 系统的核心网络序列化到磁盘。
     * 上层组件的运行时状态（如当前 feeling、inheritance）不持久化，
     * 因为它们属于每 tick 的动态上下文，而非需要长期保存的知识。
     * 
     * @param folderPath 目标文件夹路径。
     */
    public void save(String folderPath) {
        sharedNet.save(folderPath);
    }

    /**
     * 私有构造函数：接受一个已存在的 NetworkData，重建整个 Urana 系统。
     * 这是 loadFromFile 的入口，也是公共构造函数的复用路径。
     */
    private UranaSystem(NetworkData sharedNet) {
        this.sharedNet = sharedNet;

        // --- 创建共享工作梯度缓冲区（3 个串行 GradCell 复用，省 ~3 GB 显存）---
        this.sharedIOLayerGradients = new IOLayerGradients();

        // --- 初始化所有组件（全部注入同一个网络 + 共享工作缓冲区）---
        // 行动层
        this.prospectiveAnchor = new ProspectiveAnchor(FEELING_SIZE, BEHAVIOR_SIZE);
        this.prospectiveInference = new ProspectiveInference(this.sharedNet);
        this.prospectiveGradCell = new ProspectiveGradCell(this.sharedNet, this.sharedIOLayerGradients);

        // 分析层
        this.retrospectiveAnchor = new RetrospectiveAnchor(FEELING_SIZE, BEHAVIOR_SIZE);
        this.retrospectiveInference = new RetrospectiveInference(this.sharedNet);
        this.retrospectiveGradCell = new RetrospectiveGradCell(this.sharedNet, this.sharedIOLayerGradients);

        // 反思层
        this.introspectiveAnchor = new IntrospectiveAnchor(FEELING_SIZE, BEHAVIOR_SIZE);
        this.introspectiveInference = new IntrospectiveInference(this.sharedNet);
        this.introspectiveTrainingContext = new TrainingContext(this.sharedNet, this.sharedIOLayerGradients);

        // 初始化跨轮状态（避免首轮 NPE）
        int sizeC = new InputVectorDomain()
                .getInheritanceInfoSpan().getLength();
        this.prospectiveInheritance = new BoolVector(sizeC);
        this.retrospectiveInheritance = new BoolVector(sizeC);
        this.introspectiveInheritance = new BoolVector(sizeC);
        this.lastRetrospectiveFeeling = new BoolVector(FEELING_SIZE);

        // 预分配行为提取缓冲区（尺寸由输出向量的 BehaviorSpan 决定）
        this.prospectiveBehaviorBuffer = new BoolVector(OUTPUT_DOMAIN.getBehaviorSpan().getLength());

        // 预分配用于“分析层”的 OutputVector
        this.retroOutputForAnchor = new OutputVector(OutputVectorDomain.TOTAL_LENGTH);

        // 池化 dt 编码缓冲区（网络输入 64 bit）
        this.dtBuffer = new BoolVector(DT_SIZE);
        this.dtPacked = new int[DT_SIZE / 32];
    }

    private static NetworkData createNewNetworkData() {
        try {
            return new NetworkData(INPUT_SIZE, OUTPUT_SIZE, true);
        } catch (java.io.IOException e) {
            throw new RuntimeException("Failed to initialize shared NetworkData", e);
        }
    }

    /**
     * 主循环，在每个时间步被调用。
     *
     * @param currentFeeling 从环境中感知的当前感觉。
     * @param dtMillis  本次推理轮次与上一轮之间的墙钟时间间隔，单位毫秒。
     *                  <p>
     *                  设计原则（真善美第2点）：urana 在意识域中没有“获取时间”的模式，
     *                  时间由外部系统告知。此参数即外部测量后告知的“轮间时间间隔”，
     *                  urana 仅负责将其编码为网络输入 BoolVector（见 {@link #encodeDt}），
     *                  不自行获取时间。dtMillis=0 表示首轮（无上一轮，间隔未定义）。
     *                  TODO 未来 agent 持久化时，首轮从磁盘读取上一轮 lastRunStartNanos 算 dt。
     */
    public void runOneTick(BoolVector currentFeeling, long dtMillis) {
        encodeDt(dtMillis);

        // === 1. 行动与分析 ===

        // [流程一]
        prospectiveAnchor.tick();
        prospectiveAnchor.pushFeelingFrom(currentFeeling);

        // [流程二] N=2 链条：阶段1(F=外部感觉, C=上轮inheritance) → 阶段2(F=阶段1输出F, C=阶段1输出C)
        BoolVector feelingForInference = prospectiveAnchor.getFeeling().getSuspension();
        BoolVector prospectiveOutput = prospectiveInference.execute(
                feelingForInference, this.prospectiveInheritance, this.dtBuffer);
        extractBehaviorTo(prospectiveOutput, this.prospectiveBehaviorBuffer);
        extractInheritance(prospectiveOutput, this.prospectiveInheritance);
        prospectiveAnchor.pushBehaviorFrom(this.prospectiveBehaviorBuffer);

        // [流程四] N=1：F=上轮输出F，C=上轮输出C
        BoolVector retrospectiveOutput = retrospectiveInference.execute(
                this.lastRetrospectiveFeeling, this.retrospectiveInheritance, this.dtBuffer);
        retrospectiveAnchor.tick();
        this.retroOutputForAnchor.getVector().copyFromBoolVector(
                fullSpan(this.retroOutputForAnchor.getVector()), retrospectiveOutput, fullSpan(retrospectiveOutput));
        retrospectiveAnchor.pushFromOutput(this.retroOutputForAnchor);
        extractFeeling(retrospectiveOutput, this.lastRetrospectiveFeeling);
        extractInheritance(retrospectiveOutput, this.retrospectiveInheritance);

        // === 2. 学习与反思 ===

        // [流程三]
        prospectiveGradCell.execute(prospectiveAnchor, this.dtBuffer);

        // [流程六]
        retrospectiveGradCell.execute(retrospectiveAnchor, this.dtBuffer);

        // [流程七] N=1：F=锚点沉淀物，C=上轮inheritance
        introspectiveAnchor.pokeFrom(retrospectiveAnchor);
        BoolVector introspectiveOutput = introspectiveInference.execute(
                introspectiveAnchor.getFeeling().getPrecipitate(),
                this.introspectiveInheritance,
                this.dtBuffer);
        introspectiveAnchor.pokeInto(introspectiveOutput, introspectiveOutput);
        extractInheritance(introspectiveOutput, this.introspectiveInheritance);

        // [流程八]
        introspectiveTrainingContext.execute(introspectiveAnchor, this.dtBuffer);
    }

    /**
     * 将外部告知的轮间时间间隔（毫秒 long）编码为网络输入 BoolVector。
     * 编码方式：long 的 64 bit 直接展开为 64 个 boolean（二进制原样落地，无变换、可逆）。
     * <p>
     * 设计原则（真善美第3点）：用 dtBuffer（实在的 GPU 缓冲）把 dtMillis
     * （不实在的连续时间值）转化为实在的 64 位布尔输入。
     *
     * @param dtMillis 轮间时间间隔（毫秒）。0 表示首轮。
     */
    private void encodeDt(long dtMillis) {
        // long 的 64 bit 直接拆成 2 个 uint32 word（位结构天然对应 packed 格式）。
        // 走 copyFromHost(int[], wordCount) 的 word 级直通路径，
        // 省掉逐位展开的 64 次循环 + native boolean→uint32 打包。
        dtPacked[0] = (int)(dtMillis & 0xFFFFFFFFL);
        dtPacked[1] = (int)((dtMillis >>> 32) & 0xFFFFFFFFL);
        dtBuffer.copyFromHost(dtPacked, dtPacked.length);
        if (dtDebugEnabled) {
            LOGGER.info("[UranaTick] dt={} ms", dtMillis);
        }
    }

    /**
     * dt 调试开关：开启时每轮输出轮间时间间隔到日志，关闭时零性能损失。
     */
    public void setDtDebugEnabled(boolean enabled) {
        this.dtDebugEnabled = enabled;
    }

    /**
     * 获取“行动者”推理出的行为向量的内部缓冲区。
     * <p>
     * <b>警告:</b> 返回的是内部缓冲区的直接引用，调用方不应修改其内容，
     * 且其内容会在每个 tick 发生变化。仅供外部系统读取AI决策结果使用。
     *
     * @return 指向 prospectiveBehaviorBuffer 的直接引用。
     */
    public BoolVector getProspectiveBehaviorBuffer() {
        return this.prospectiveBehaviorBuffer;
    }

    private void extractBehaviorTo(BoolVector outputVector, BoolVector target) {
        int size = OUTPUT_DOMAIN.getBehaviorSpan().getLength();
        target.copyFromBoolVector(
                new BehaviorSpan(0, size),
                outputVector,
                OUTPUT_DOMAIN.getBehaviorSpan());
    }

    private void extractFeeling(BoolVector outputVector, BoolVector targetFeeling) {
        targetFeeling.copyFromBoolVector(
                new FeelingSpan(0, targetFeeling.size()),
                outputVector,
                OUTPUT_DOMAIN.getFeelingSpan());
    }

    private void extractInheritance(BoolVector outputVector, BoolVector targetInheritance) {
        targetInheritance.copyFromBoolVector(
                new InheritanceInfoSpan(0, targetInheritance.size()),
                outputVector,
                OUTPUT_DOMAIN.getInheritanceInfoSpan());
    }

    private Span fullSpan(IVector vector) {
        return new Span(0, vector.size()) {
        };
    }

    @Override
    public void close() throws Exception {
        // 在此释放所有 AutoCloseable 资源
        prospectiveAnchor.close();
        prospectiveInference.close();
        prospectiveGradCell.close();
        retrospectiveAnchor.close();
        retrospectiveInference.close();
        retrospectiveGradCell.close();
        introspectiveAnchor.close();
        introspectiveInference.close();
        introspectiveTrainingContext.close();

        // ✅ 释放共享工作梯度缓冲区（所有 GradCell 已关闭，无人再持有引用）
        if (sharedIOLayerGradients != null)
            sharedIOLayerGradients.close();

        // ✅ 只释放一次共享网络
        if (sharedNet != null)
            sharedNet.close();

        // 补充释放跨轮状态
        if (prospectiveInheritance != null)
            prospectiveInheritance.close();
        if (retrospectiveInheritance != null)
            retrospectiveInheritance.close();
        if (introspectiveInheritance != null)
            introspectiveInheritance.close();
        if (lastRetrospectiveFeeling != null)
            lastRetrospectiveFeeling.close();
        if (prospectiveBehaviorBuffer != null)
            prospectiveBehaviorBuffer.close();
        if (retroOutputForAnchor != null)
            retroOutputForAnchor.close();
        if (dtBuffer != null)
            dtBuffer.close();
    }
}