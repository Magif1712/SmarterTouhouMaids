package com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.vision;

import com.github.magif1712.smarter_touhou_maids.core.native_support.NativeLibLoader;

class VisionNative {
    static {
        NativeLibLoader.ensureLoaded();
    }

    /**
     * 将 OpenGL 纹理的内容（假定为 RGBA8 格式）捕获到 BoolVector 的设备内存中。
     *
     * @param textureId   OpenGL 纹理 ID。
     * @param handle      目标 BoolVector 的设备指针句柄。
     * @param bitOffset   在 BoolVector 中的起始位偏移量。
     * @param width       纹理宽度。
     * @param height      纹理高度。
     * @param stream_handle CUDA 流句柄。
     */
    static native void _captureScreenToBoolVector(
            int textureId, long handle, long bitOffset,
            int texWidth, int texHeight,
            int aiWidth, int aiHeight,
            long stream_handle
    );

    /**
     * 清理 Vision Bridge 使用的所有原生资源。
     */
    static native void _cleanup();
}