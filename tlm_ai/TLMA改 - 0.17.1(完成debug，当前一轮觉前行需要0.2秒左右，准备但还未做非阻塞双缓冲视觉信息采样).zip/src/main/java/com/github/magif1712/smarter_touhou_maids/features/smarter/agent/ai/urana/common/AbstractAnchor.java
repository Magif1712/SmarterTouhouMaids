package com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.common;

import com.github.magif1712.smarter_touhou_maids.core.containers.domain.Span;
import com.github.magif1712.smarter_touhou_maids.core.containers.vector.BoolVector;
import com.github.magif1712.smarter_touhou_maids.core.containers.vector.SlidingPair;
import java.io.Closeable;
import java.io.IOException;

/**
 * urana 系统中锚点的抽象基类。
 * 定义了 urana 锚点的通用结构：包含一个“感觉”和一个“行为”的滑动对。
 * 并提供了通用的 tick() 和 close() 实现。
 */
public abstract class AbstractAnchor implements Closeable {

    protected final SlidingPair<BoolVector> feeling;
    protected final SlidingPair<BoolVector> behavior;

    public AbstractAnchor(int feelingSize, int behaviorSize) {
        this.feeling = new SlidingPair<>(new BoolVector(feelingSize), new BoolVector(feelingSize));
        this.behavior = new SlidingPair<>(new BoolVector(behaviorSize), new BoolVector(behaviorSize));
    }

    public SlidingPair<BoolVector> getFeeling() {
        return feeling;
    }

    public SlidingPair<BoolVector> getBehavior() {
        return behavior;
    }

    /**
     * 将感觉和行为窗口同步向前滑动一个时间步。
     * 子类可以根据需要覆盖此方法以实现不同的滑动逻辑，但 urana 系统中默认为同步滑动。
     */
    public void tick() {
        feeling.slide();
        behavior.slide();
    }

    // === 路径一：区间覆盖（Prospective / Retrospective 的通用回退）===
    public void pushFeeling(BoolVector source, Span srcSpan, Span destSpan) {
        feeling.push(source, srcSpan, destSpan);
    }

    public void pushBehavior(BoolVector source, Span srcSpan, Span destSpan) {
        behavior.push(source, srcSpan, destSpan);
    }

    // === 路径二：零拷贝交换（仅当上游已产出完整独立数组时）===
    public void pushFeeling(BoolVector source) {
        feeling.push(source); // 所有权转移
    }

    public void pushBehavior(BoolVector source) {
        behavior.push(source); // 所有权转移
    }

    /**
     * 将源向量的数据拷贝到 feeling 的悬浮物中，不转移所有权。
     * 用于避免高频 tick 下的反复显存分配/释放。
     */
    public void pushFeelingFrom(BoolVector source) {
        feeling.getSuspension().copyRegionFrom(source,
            new Span(0, source.size()) {},
            new Span(0, feeling.getSuspension().size()) {});
    }

    /**
     * 将源向量的数据拷贝到 behavior 的悬浮物中，不转移所有权。
     * 用于避免高频 tick 下的反复显存分配/释放。
     */
    public void pushBehaviorFrom(BoolVector source) {
        behavior.getSuspension().copyRegionFrom(source,
            new Span(0, source.size()) {},
            new Span(0, behavior.getSuspension().size()) {});
    }

    @Override
    public void close() throws IOException {
        feeling.close();
        behavior.close();
    }
}