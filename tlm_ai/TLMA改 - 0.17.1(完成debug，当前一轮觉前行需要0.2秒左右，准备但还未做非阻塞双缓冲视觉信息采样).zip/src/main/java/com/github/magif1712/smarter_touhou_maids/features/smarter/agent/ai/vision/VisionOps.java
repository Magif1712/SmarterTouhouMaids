package com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.vision;

import com.github.magif1712.smarter_touhou_maids.core.containers.domain.Span;
import com.github.magif1712.smarter_touhou_maids.core.containers.vector.BoolVector;
import com.github.magif1712.smarter_touhou_maids.core.execution.Stream;

public class VisionOps {

    /** AI 视网膜固定分辨率 —— 与游戏窗口大小无关 */
    public static final int AI_WIDTH = 1920;
    public static final int AI_HEIGHT = 1080;

    /**
     * 将活动的 OpenGL 纹理内容捕获并缩放到固定 AI 视网膜分辨率，写入 BoolVector 的指定子区间。
     *
     * @param textureId 要捕获的 OpenGL 纹理 ID
     * @param dst       用于存储捕获数据的 BoolVector
     * @param destSpan  定义了在 dst 中用于写入的子区间。其长度必须 >= AI_WIDTH * AI_HEIGHT * 24
     * @param texWidth  纹理实际宽度（来自 RenderTarget/Window）
     * @param texHeight 纹理实际高度
     * @param stream    用于异步操作的 CUDA 流
     */
    public static void captureScreen(int textureId, BoolVector dst, Span destSpan,
                                     int texWidth, int texHeight, Stream stream) {
        if (textureId <= 0) {
            throw new IllegalArgumentException("Invalid texture ID: " + textureId);
        }
        if (!dst.isInitialized()) {
            throw new IllegalStateException("Destination BoolVector has no allocated device memory.");
        }
        if (texWidth <= 0 || texHeight <= 0) {
            throw new IllegalArgumentException(
                    "Invalid texture dimensions: " + texWidth + "x" + texHeight);
        }

        // 注意：requiredBits 现在由 AI 视网膜分辨率决定，与输入纹理无关
        long requiredBits = (long) AI_WIDTH * AI_HEIGHT * 24L;
        if (destSpan.getLength() < requiredBits) {
            throw new IllegalArgumentException(String.format(
                    "Destination span length (%d) must be >= AI retina area * 24 (%d).",
                    destSpan.getLength(), requiredBits));
        }
        if (destSpan.getOffset() + destSpan.getLength() > dst.size()) {
            throw new IllegalArgumentException("Destination span is out of bounds for the BoolVector.");
        }

        VisionNative._captureScreenToBoolVector(
                textureId,
                dst.handle(),
                destSpan.getOffset(),
                texWidth,
                texHeight,
                AI_WIDTH,
                AI_HEIGHT,
                stream.getHandle()
        );
    }

    public static void registerShutdownHook() {
        Runtime.getRuntime().addShutdownHook(new Thread(VisionNative::_cleanup));
    }
}