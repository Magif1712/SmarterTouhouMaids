package com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.common.grad;

import com.github.magif1712.smarter_touhou_maids.core.containers.domain.Span;
import com.github.magif1712.smarter_touhou_maids.core.containers.vector.BoolVector;
import com.github.magif1712.smarter_touhou_maids.core.containers.vector.IVector;
import com.github.magif1712.smarter_touhou_maids.core.containers.vector.IntVector;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.nn.containers.NetworkData;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.nn.containers.io.IO;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.nn.containers.io.IOLayerGradients;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.nn.containers.io.value.OutputVector;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.nn.containers.io.value.TargetVector;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.nn.mapping.NetworkProcessor;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.nn.mapping.training.GradientProcessor;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.semantics.containers.io.IODomain;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.semantics.containers.io.InputVectorDomain;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.semantics.containers.io.OutputVectorDomain;
import com.github.magif1712.smarter_touhou_maids.core.ai.mapping.GenericOps;

import java.util.ArrayList;
import java.util.List;

/**
 * 抽象梯度计算单元 (Abstract Gradient Cell)。
 * <p>
 * 该类为处理一个N步的链式学习任务提供了骨架实现。它将复杂的两阶段（探索-修正）链式循环逻辑完全封装在基类中，
 * 使得子类只需在构造时提供静态配置（如链条长度、每一步的时间方位向量G），即可创建一个全自动的链式处理器。
 * <p>
 * <b>核心设计模式：配置对象 (Configured Object) + 模板方法 (Template Method)</b>
 * <ul>
 *     <li><b>配置对象</b>: 每个 AbstractGradCell 的实例在构造时就被配置为一个特定任务的处理器（例如，“一个处理5步展望的单元”）。
 *         它的核心配置（链长、G向量序列）是不可变的。</li>
 *     <li><b>模板方法</b>: 定义了一个完整的、包含N步链式循环和两阶段学习的算法骨架 {@link #execute(List)}。
 *         子类通过调用父类构造函数来注入其特定配置，从而定制化整个链式处理器的行为。</li>
 * </ul>
 * <p>
 * <b>工作流程:</b>
 * <ol>
 *     <li><b>构造</b>: 子类（如 ProspectiveGradCell）在构造时，通过调用 `super()` 提供固定的链条长度 `N` 和每一步的 `G` 向量序列。</li>
 *     <li><b>执行</b>: 外部调用者通过 {@link #execute(List)} 方法，一次性提供所有 `N` 步的输入和目标数据。</li>
 *     <li><b>内部处理</b>: 基类自动执行完整的两阶段链式学习：
 *         <ol>
 *             <li><b>阶段一 (探索)</b>: 从零初始上下文 `C` 开始，顺序执行N步前向传播，然后逆序执行N步反向传播（不更新权重），以计算出链条起点的修正梯度 `∇C`。</li>
 *             <li><b>阶段二 (学习)</b>: 使用 `∇C` 计算出修正后的初始上下文 `C'`，再次执行N步前向和N步逆序反向传播，这一次会更新网络权重。</li>
 *         </ol>
 *     </li>
 * </ol>
 */
public abstract class AbstractGradCell implements AutoCloseable {

    // --- 核心数据容器 ---
    /** 神经网络的权重(W)和偏置(B)。这个对象由外部管理，本单元仅使用它。 */
    protected final NetworkData networkData;
    /** 存储反向传播过程中计算出的各层梯度。该对象在链式处理中被复用。 */
    protected final IOLayerGradients gradients;
    /**
     * 标记 gradients 所有权：true=本实例自建（close 时释放），false=外部注入共享（close 时不释放，由 UranaSystem 统一管理）。
     * <p>
     * 设计原则（真善美）：
     * 3 个 GradCell 在 UranaSystem.runOneTick 中严格串行执行，工作梯度缓冲区天然可复用。
     * UranaSystem 持有唯一一份 IOLayerGradients 并注入给 3 个 GradCell，省 ~3 GB 显存。
     */
    protected final boolean ownsGradients;
    /** 目标向量 (y)，即我们希望网络输出的“正确答案”。该对象在链式处理中被复用。 */
    protected final TargetVector target;

    // --- 语义域描述符 ---
    /** 定义了输入/输出向量中不同区段（如感觉、行为、继承信息等）的语义和位置。 */
    protected final IODomain ioDomain;

    // --- 实例配置 (构造后不变) ---
    /** 链条的长度 (组数 N)。 */
    protected final int chainLength;
    /** 存储链条中每一步的 G 向量。维度为 [步数][G向量长度]。 */
    protected final boolean[][] gPerStep;

    /** 预分配的样本池，子类通过填充此池来传入目标，无需创建临时对象。 */
    protected final ChainStepSample[] samplePool;

    // --- 状态容器 (在 execute 方法执行期间使用) ---
    /** 单个、可复用的IO对象，用于执行前向传播。 */
    protected final IO io;
    /** 存储链条中每一步的内部状态快照。 */
    protected final List<ChainStepState> stepStates;
    /**
     * 一个独立的缓冲区，用于在反向传播链中安全地传递梯度 ∇C。
     * 每次计算出新的 ∇C 后，都会深拷贝到这里，以防在下一次迭代中被覆盖。
     */
    protected final IntVector grad_C_buffer;
    /** 在第二阶段（修正）中，作为输入向量“继承信息”部分 (C_in) 的布尔向量。它的值由第一阶段的梯度计算而来。 */
    protected final BoolVector c_input_for_phase2;
    /** 一个全为零的布尔向量，用于在第一阶段（探索）中清空输入向量的“继承信息”部分。 */
    protected final BoolVector zero_vector_C;
    protected final BoolVector next_c_input;
    protected final BoolVector current_F_input;



    protected IntVector terminalGradC; // 跨轮次末端梯度，外部绑定

    /**
     * 主构造函数。
     *
     * @param networkData 共享的神经网络权重和偏置数据。
     * @param chainLength 链条的长度 (组数 N)。
     * @param gPerStep    一个二维数组，存储每一步的 G 向量。其第一维长度必须等于 chainLength。
     */
    protected AbstractGradCell(NetworkData networkData, int chainLength, boolean[][] gPerStep) {
        this(networkData, chainLength, gPerStep, null);
    }

    /**
     * 主构造函数：支持注入外部共享的 IOLayerGradients 工作缓冲区。
     * <p>
     * 设计原则（真善美）：
     * <ul>
     *     <li>真：3 个 GradCell 在 UranaSystem.runOneTick 中严格串行执行，工作缓冲区天然可复用。</li>
     *     <li>善：注入共享可省 ~3 GB 显存（inputLayerGradient + outputLayerGradient 各 759 MB × 2 份）。</li>
     *     <li>美：通过 ownsGradients 标记所有权，close() 行为清晰可预测。</li>
     * </ul>
     * 注意：grad_C_buffer 仍是每实例独占——它承载跨 tick 的末端梯度 ∇C 状态，属于"状态层"而非"工作层"，
     * 按模式分层原则（状态层在工作层之上），状态必须独立保留。
     *
     * @param sharedGradients 外部注入的工作梯度缓冲区；null 表示本实例自建（向后兼容）。
     */
    protected AbstractGradCell(NetworkData networkData, int chainLength, boolean[][] gPerStep,
                               IOLayerGradients sharedGradients) {
        if (gPerStep.length != chainLength) {
            throw new IllegalArgumentException("G向量的数量 (" + gPerStep.length + ") 必须等于链条长度 (" + chainLength + ")");
        }
        this.chainLength = chainLength;
        this.gPerStep = gPerStep;

        this.ioDomain = new IODomain();
        this.networkData = networkData;
        if (sharedGradients != null) {
            this.gradients = sharedGradients;
            this.ownsGradients = false;
        } else {
            this.gradients = new IOLayerGradients();
            this.ownsGradients = true;
        }
        this.target = new TargetVector(OutputVectorDomain.TOTAL_LENGTH);

        this.io = new IO(InputVectorDomain.TOTAL_LENGTH, OutputVectorDomain.TOTAL_LENGTH);
        this.stepStates = new ArrayList<>(chainLength);
        for (int i = 0; i < chainLength; i++) {
            this.stepStates.add(new ChainStepState(
                InputVectorDomain.TOTAL_LENGTH,
                OutputVectorDomain.TOTAL_LENGTH, // fz size is assumed to be the same as output size
                OutputVectorDomain.TOTAL_LENGTH
            ));
        }

        int sizeC = this.ioDomain.getInputDomain().getInheritanceInfoSpan().getLength();
        this.grad_C_buffer = new IntVector(sizeC);
        this.grad_C_buffer.multiplyByScalar(0); // ✅ 确保首轮起点为 0
        this.c_input_for_phase2 = new BoolVector(sizeC);
        this.next_c_input = new BoolVector(sizeC);
        this.zero_vector_C = new BoolVector(sizeC);
        this.zero_vector_C.copyRegionFromHost(fullSpan(this.zero_vector_C), new boolean[sizeC]);
        int sizeF = this.ioDomain.getInputDomain().getFeelingSpan().getLength();
        this.current_F_input = new BoolVector(sizeF);



        this.samplePool = new ChainStepSample[chainLength];
        for (int i = 0; i < chainLength; i++) {
            this.samplePool[i] = new ChainStepSample(null, null);
        }
    }

    /**
     * 便利构造函数，用于链条中每一步的 G 向量都相同的情况。
     *
     * @param networkData 共享的神经网络权重和偏置数据。
     * @param chainLength 链条的长度 (组数 N)。
     * @param g           将用于所有步骤的单个 G 向量。
     */
    protected AbstractGradCell(NetworkData networkData, int chainLength, boolean[] g) {
        this(networkData, chainLength, g, null);
    }

    /**
     * 便利构造函数：每一步的 G 向量都相同，并支持注入共享工作梯度缓冲区。
     *
     * @param sharedGradients 外部注入的工作梯度缓冲区；null 表示本实例自建（向后兼容）。
     */
    protected AbstractGradCell(NetworkData networkData, int chainLength, boolean[] g,
                               IOLayerGradients sharedGradients) {
        this(networkData, chainLength, repeatGVector(g, chainLength), sharedGradients);
    }

    private static boolean[][] repeatGVector(boolean[] g, int n) {
        boolean[][] result = new boolean[n][];
        for (int i = 0; i < n; i++) {
            result[i] = g;
        }
        return result;
    }

    public void bindTerminalGradientBuffer(IntVector externalBuffer) {
        this.terminalGradC = externalBuffer;
    }

    /**
     * 模板方法：执行完整的N步链式两阶段学习流程。
     * 这是该类的核心外部入口点。
     *
     * @param steps 一个包含N步数据的列表，其长度必须与本实例配置的 chainLength 相匹配。
     */
    public final IntVector execute(BoolVector initialInputF, BoolVector dt, List<ChainStepSample> samples) {
        if (samples.size() != this.chainLength) {
            throw new IllegalArgumentException("传入的数据样本数 (" + samples.size() + ") 必须与Cell配置的链条长度 (" + this.chainLength + ") 相匹配");
        }
        for (int i = 0; i < samples.size(); i++) {
            ChainStepSample s = samples.get(i);
            this.samplePool[i].set(s.target_F, s.target_B);
        }
        return executeWithPool(initialInputF, dt);
    }

    /**
     * 执行完整的 N 步链式训练，并自动管理跨轮次梯度闭环。
     * 子类在组装好 samples 后调用此方法即可，无需手动处理 ∇C 的绑定与回写。
     */
    protected final void executeWithClosedLoop(BoolVector initialInputF, BoolVector dt) {
        // 绑定到 grad_C_buffer 自身，实现单缓冲复用
        this.bindTerminalGradientBuffer(this.grad_C_buffer);

        // 执行两阶段，反向传播链终点直接覆盖 grad_C_buffer
        this.executeWithPool(initialInputF, dt);

        // 无需回写，grad_C_buffer 已经是本轮最终 ∇C，供下一轮直接使用
    }

    private IntVector executeWithPool(BoolVector initialInputF, BoolVector dt) {
        if (this.samplePool[0].target_F == null) {
            throw new IllegalStateException("samplePool 未填充，子类须在调用 executeWithClosedLoop 前填充 target");
        }
        // === 阶段一：探索 (不更新权重) ===
        runForwardPass(initialInputF, this.zero_vector_C, dt);
        IntVector initialGradC = runBackwardPass(this.samplePool, false);

        // === 阶段二：修正与学习 (更新权重) ===
        GenericOps.negateAndBinarize(initialGradC, this.c_input_for_phase2);
        runForwardPass(initialInputF, this.c_input_for_phase2, dt);
        return runBackwardPass(this.samplePool, true);
    }



    // ==================== 共享实现 (两阶段学习) ====================

    /**
     * 执行一次完整的前向传播链。
     *
     * @param samples     包含N步输入数据的列表。
     * @param initial_C 用于链条第一步的初始“继承信息”向量。
     */
    private void runForwardPass(BoolVector initial_F, BoolVector initial_C, BoolVector dt) {
        InputVectorDomain inputDomain = this.ioDomain.getInputDomain();
        OutputVectorDomain outputDomain = this.ioDomain.getOutputDomain();
        this.current_F_input.copyFromBoolVector(fullSpan(this.current_F_input), initial_F, fullSpan(initial_F));
        BoolVector current_c_input = initial_C;

        for (int i = 0; i < this.chainLength; i++) {
            BoolVector inputValue = this.io.getInput().getVector();

            // 1. 组装输入向量
            inputValue.setRegion(inputDomain.getFeelingSpan(), this.current_F_input);
            inputValue.copyRegionFromHost(inputDomain.getTargetTimeOrientationSpan(), this.gPerStep[i]);
            inputValue.setRegion(inputDomain.getFeelingBehaviorSamplingDtSpan(), dt);
            inputValue.setRegion(inputDomain.getInheritanceInfoSpan(), current_c_input);

            // 2. 执行单步前向传播 (复用同一个IO)
                ChainStepState state = this.stepStates.get(i);
                NetworkProcessor.forwardStoreFz(this.networkData, this.io, state.fz, 0L);

                // 3. 深拷贝必要状态到 ChainStepState
                state.input.copyFromBoolVector(fullSpan(state.input), inputValue, fullSpan(inputValue));
                state.output.copyFromBoolVector(fullSpan(state.output), this.io.getOutput().getVector(), fullSpan(this.io.getOutput().getVector()));

            // 4. 提取 C_out 和 F_out 给下一步
            BoolVector currentOutputVector = this.io.getOutput().getVector();
            // 提取 C_out -> next_c_input
            this.next_c_input.copyFromBoolVector(fullSpan(this.next_c_input), currentOutputVector, outputDomain.getInheritanceInfoSpan());
            current_c_input = this.next_c_input;
            // 提取 F_out -> current_F_input
            this.current_F_input.copyFromBoolVector(fullSpan(this.current_F_input), currentOutputVector, outputDomain.getFeelingSpan());
        }
    }

    /**
     * 执行一次完整的逆序反向传播链。
     *
     * @param samples         包含N步目标数据的列表。
     * @param updateWeights 如果为 true，则在反向传播后应用梯度下降更新权重。
     * @return 链条起点的“继承信息”梯度 (∇C_in(0))。
     */
    private IntVector runBackwardPass(ChainStepSample[] samples, boolean updateWeights) {
        InputVectorDomain inputDomain = this.ioDomain.getInputDomain();
        IntVector grad_C_from_next = this.grad_C_buffer;

        // 优化：当 terminalGradC 指向自身时，跳过无意义的自拷贝
        if (this.terminalGradC != null && this.terminalGradC != grad_C_from_next) {
            // 外部绑定了独立的 buffer，需要深拷贝
            grad_C_from_next.copyFromIntVector(
                fullSpan(grad_C_from_next), this.terminalGradC, fullSpan(this.terminalGradC));
        } else if (this.terminalGradC == null) {
            // 无外部绑定（非闭环调用），清零
            grad_C_from_next.multiplyByScalar(0);
        }
        // 如果 terminalGradC == grad_C_from_next，则无需任何操作，直接复用 buffer 中的现有值

        for (int i = this.chainLength - 1; i >= 0; i--) {
            ChainStepState state = this.stepStates.get(i);
            ChainStepSample sample = samples[i];

            // 1. 准备反向传播
            prepareBackward(state.output, sample.target_F, sample.target_B, grad_C_from_next);

            try {
                // 2. 执行反向传播
                if (updateWeights) {
                    NetworkProcessor.backwardWithGradientDescent(this.networkData, this.gradients, state.fz, state.input, 0L);
                } else {
                    NetworkProcessor.backward(this.networkData, this.gradients, state.fz, 0L);
                }
            } catch (Exception e) {
                throw new RuntimeException(
                    "Backward pass failed at step " + i + " in " + getClass().getSimpleName(), e);
            }

            // 3. 关键：深拷贝！
            this.grad_C_buffer.copyFromIntVector(
                fullSpan(this.grad_C_buffer),
                this.gradients.getInputLayerGradient().getVector(),
                inputDomain.getInheritanceInfoSpan()
            );
        }
        return grad_C_from_next;
    }


    /**
     * 准备反向传播的初始数据，即计算输出层的梯度 (∇a_L)。
     *
     * @param current_output               当前步骤的输出向量。
     * @param target_F                     目标“感觉”向量。
     * @param target_B                     目标“行为”向量。
     * @param grad_C_input_from_prev_cycle 来自下一个步骤（在反向传播链中是上一步）的“继承信息”梯度。
     */
    private void prepareBackward(BoolVector current_output, BoolVector target_F, BoolVector target_B,
                                 IntVector grad_C_input_from_prev_cycle) {
        OutputVectorDomain outputDomain = this.ioDomain.getOutputDomain();
        BoolVector targetVec = this.target.getVector();
        IntVector outputGradVec = this.gradients.getOutputLayerGradient().getVector();

        // 1. 组装目标向量 y
        targetVec.setRegion(outputDomain.getFeelingSpan(), target_F);
        targetVec.setRegion(outputDomain.getBehaviorSpan(), target_B);

        // 2. 分别计算 F 和 B 部分的梯度
        GradientProcessor.calculateOutputLayerGradient(
            new OutputVector(current_output), this.target, this.gradients.getOutputLayerGradient(),
            outputDomain.getFeelingSpan());
        GradientProcessor.calculateOutputLayerGradient(
            new OutputVector(current_output), this.target, this.gradients.getOutputLayerGradient(),
            outputDomain.getBehaviorSpan());

        // 3. 直接注入来自下一个步骤的 C 区间梯度 (∇C_in)
        outputGradVec.setRegion(outputDomain.getInheritanceInfoSpan(), grad_C_input_from_prev_cycle);
    }



    /**
     * 创建一个覆盖向量整个长度的 Span。
     *
     * @param vector 目标向量。
     * @return 一个从 0 到 vector.size() 的 Span 对象。
     */
    protected Span fullSpan(IVector vector) {
        return new Span(0, vector.size()) {};
    }

    /**
     * 释放所有由该单元管理的本地资源。
     */
    @Override
    public void close() throws Exception {
        if (io != null) io.close();
        if (stepStates != null) {
            for (ChainStepState state : stepStates) {
                if (state != null) state.close();
            }
        }
        // 仅当本实例拥有 gradients 所有权时才释放；共享模式下由 UranaSystem 在所有 GradCell 关闭后统一释放
        if (gradients != null && ownsGradients) gradients.close();
        if (target != null) target.close();
        if (grad_C_buffer != null) grad_C_buffer.close();
        if (c_input_for_phase2 != null) c_input_for_phase2.close();
        if (zero_vector_C != null) zero_vector_C.close();
        if (next_c_input != null) next_c_input.close();
        if (current_F_input != null) current_F_input.close();

    }

    // --- Getters ---
    public IOLayerGradients getGradients() { return gradients; }
    public TargetVector getTarget() { return target; }
}