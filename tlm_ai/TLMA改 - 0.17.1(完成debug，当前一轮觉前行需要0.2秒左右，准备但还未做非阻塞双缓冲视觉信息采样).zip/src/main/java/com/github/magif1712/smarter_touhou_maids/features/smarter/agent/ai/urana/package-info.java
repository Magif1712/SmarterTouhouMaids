/**
 * 觉前行的英文名就是Urana，是一个系统
 */
package com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana;