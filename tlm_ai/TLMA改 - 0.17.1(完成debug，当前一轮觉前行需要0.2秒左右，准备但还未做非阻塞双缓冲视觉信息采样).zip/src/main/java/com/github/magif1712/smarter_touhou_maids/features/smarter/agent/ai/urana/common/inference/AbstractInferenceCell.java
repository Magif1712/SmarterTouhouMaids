package com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.common.inference;

import com.github.magif1712.smarter_touhou_maids.core.containers.domain.Span;
import com.github.magif1712.smarter_touhou_maids.core.containers.vector.BoolVector;
import com.github.magif1712.smarter_touhou_maids.core.containers.vector.IVector;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.nn.containers.NetworkData;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.nn.containers.io.IO;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.nn.mapping.NetworkProcessor;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.semantics.containers.io.IODomain;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.semantics.containers.io.InputVectorDomain;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.semantics.containers.io.OutputVectorDomain;

/**
 * 抽象推理单元。与 AbstractGradCell 同构，负责执行 N 步前向推理链条。
 * 子类仅配置 chainLength 和 gPerStep，基类全自动管理 F/C 的跨步传递。
 *
 * 内存策略：预分配 resultBuffer，execute 返回内部引用（调用方须立即消费）。
 */
public abstract class AbstractInferenceCell implements AutoCloseable {

    protected final NetworkData networkData;
    protected final IODomain ioDomain;
    protected final int chainLength;
    protected final boolean[][] gPerStep;

    protected final IO io;
    protected final BoolVector next_c_input;
    protected final BoolVector current_F_input;
    /** 预分配的结果缓冲区，execute 返回此对象的引用 */
    protected final BoolVector resultBuffer;

    protected AbstractInferenceCell(NetworkData networkData, int chainLength, boolean[][] gPerStep) {
        if (gPerStep.length != chainLength) {
            throw new IllegalArgumentException("G向量数量 (" + gPerStep.length +
                    ") 必须等于链条长度 (" + chainLength + ")");
        }
        this.chainLength = chainLength;
        this.gPerStep = gPerStep;
        this.networkData = networkData;
        this.ioDomain = new IODomain();
        this.io = new IO(InputVectorDomain.TOTAL_LENGTH, OutputVectorDomain.TOTAL_LENGTH);

        int sizeC = this.ioDomain.getInputDomain().getInheritanceInfoSpan().getLength();
        this.next_c_input = new BoolVector(sizeC);
        int sizeF = this.ioDomain.getInputDomain().getFeelingSpan().getLength();
        this.current_F_input = new BoolVector(sizeF);
        this.resultBuffer = new BoolVector(OutputVectorDomain.TOTAL_LENGTH);
    }

    protected AbstractInferenceCell(NetworkData networkData, int chainLength, boolean[] g) {
        this(networkData, chainLength, repeatGVector(g, chainLength));
    }

    private static boolean[][] repeatGVector(boolean[] g, int n) {
        boolean[][] result = new boolean[n][];
        for (int i = 0; i < n; i++) {
            result[i] = g;
        }
        return result;
    }

    /**
     * 执行 N 步推理链条。
     *
     * @param initialF 链条第一步的 F（感觉输入）
     * @param initialC 链条第一步的 C（继承信息）
     * @param dt       时间间隔向量
     * @return 最终输出向量（内部 resultBuffer 的引用，调用方须立即消费，不可长期持有）
     */
    public final BoolVector execute(BoolVector initialF, BoolVector initialC, BoolVector dt) {
        InputVectorDomain inputDomain = this.ioDomain.getInputDomain();
        OutputVectorDomain outputDomain = this.ioDomain.getOutputDomain();

        this.current_F_input.copyFromBoolVector(fullSpan(this.current_F_input), initialF, fullSpan(initialF));
        BoolVector current_c_input = initialC;

        for (int i = 0; i < this.chainLength; i++) {
            BoolVector inputValue = this.io.getInput().getVector();

            // 组装输入向量
            inputValue.setRegion(inputDomain.getFeelingSpan(), this.current_F_input);
            inputValue.copyRegionFromHost(inputDomain.getTargetTimeOrientationSpan(), this.gPerStep[i]);
            inputValue.setRegion(inputDomain.getFeelingBehaviorSamplingDtSpan(), dt);
            inputValue.setRegion(inputDomain.getInheritanceInfoSpan(), current_c_input);

            // 前向传播（推理不需要 fz）
            NetworkProcessor.forwardNoFz(this.networkData, this.io, 0L);

            // 提取下一步的 F_out 和 C_out
            BoolVector output = this.io.getOutput().getVector();
            this.next_c_input.copyFromBoolVector(
                    fullSpan(this.next_c_input), output, outputDomain.getInheritanceInfoSpan());
            current_c_input = this.next_c_input;
            this.current_F_input.copyFromBoolVector(
                    fullSpan(this.current_F_input), output, outputDomain.getFeelingSpan());
        }

        // 深拷贝最终结果到预分配缓冲区（避免返回 io 内部视图，防止下一轮覆盖）
        this.resultBuffer.copyFromBoolVector(
                fullSpan(this.resultBuffer),
                this.io.getOutput().getVector(),
                fullSpan(this.io.getOutput().getVector()));
        return this.resultBuffer;
    }

    protected Span fullSpan(IVector vector) {
        return new Span(0, vector.size()) {
        };
    }

    @Override
    public void close() throws Exception {
        if (io != null)
            io.close();
        if (next_c_input != null)
            next_c_input.close();
        if (current_F_input != null)
            current_F_input.close();
        if (resultBuffer != null)
            resultBuffer.close();
    }
}