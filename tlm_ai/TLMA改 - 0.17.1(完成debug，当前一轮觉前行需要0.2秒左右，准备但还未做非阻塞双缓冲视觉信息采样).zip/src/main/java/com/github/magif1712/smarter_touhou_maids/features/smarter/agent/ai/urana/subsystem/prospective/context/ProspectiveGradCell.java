package com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.subsystem.prospective.context;

import com.github.magif1712.smarter_touhou_maids.core.containers.vector.BoolVector;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.nn.containers.NetworkData;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.nn.containers.io.IOLayerGradients;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.common.UranaConstants;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.common.grad.AbstractGradCell;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.subsystem.prospective.ProspectiveAnchor;

/**
 * 流程三：拟合过去1刻（两阶段训练）。
 * 为 ProspectiveAnchor 服务，用过去的实际数据来校准自己。
 * 继承 AbstractGradCell，单步链条，内部闭环跨轮次梯度。
 */
public class ProspectiveGradCell extends AbstractGradCell {
    private static final int CHAIN_LENGTH = 1;

    public ProspectiveGradCell(NetworkData networkData) {
        this(networkData, null);
    }

    /**
     * 注入共享工作梯度缓冲区的构造函数。
     * 多个串行执行的 GradCell 可共享同一份 IOLayerGradients，省 ~1.5 GB 显存/份。
     *
     * @param sharedGradients 外部注入的工作梯度缓冲区；null 表示本实例自建。
     */
    public ProspectiveGradCell(NetworkData networkData, IOLayerGradients sharedGradients) {
        super(networkData, CHAIN_LENGTH, UranaConstants.G_PAST_1, sharedGradients);
    }

    public void execute(ProspectiveAnchor anchor, BoolVector dt) {
        // 填充预分配池，零临时对象
        samplePool[0].set(
            anchor.getFeeling().getPrecipitate(),
            anchor.getBehavior().getPrecipitate()
        );
        super.executeWithClosedLoop(
            anchor.getFeeling().getSuspension(), dt);
    }
}