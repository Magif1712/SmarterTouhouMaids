package com.github.magif1712.smarter_touhou_maids.features.smarter.state;

import com.github.magif1712.smarter_touhou_maids.SmarterTouhouMaids;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import net.minecraft.nbt.CompoundTag;

public final class MaidSmarterState {
    private static final String KEY_SMARTER_ON_POSSESSION = "SmarterOnPossession";
    private static final String KEY_BEHAVIOR = "Behavior";

    private MaidSmarterState() {}

    public static boolean isEnabled(EntityMaid maid) {
        try {
            CompoundTag data = maid.getPersistentData();
            if (data.contains(SmarterTouhouMaids.MOD_ID, 10)) {
                CompoundTag modData = data.getCompound(SmarterTouhouMaids.MOD_ID);
                if (modData.contains(KEY_SMARTER_ON_POSSESSION, 1)) {
                    return modData.getBoolean(KEY_SMARTER_ON_POSSESSION);
                }
            }
        } catch (Exception ignored) {}
        return false;
    }

    public static void setEnabled(EntityMaid maid, boolean enabled) {
        CompoundTag data = maid.getPersistentData();
        CompoundTag modData = data.getCompound(SmarterTouhouMaids.MOD_ID);
        modData.putBoolean(KEY_SMARTER_ON_POSSESSION, enabled);
        data.put(SmarterTouhouMaids.MOD_ID, modData);
    }

    public static void setBehavior(EntityMaid maid, long[] behavior) {
        CompoundTag data = maid.getPersistentData();
        CompoundTag modData = data.getCompound(SmarterTouhouMaids.MOD_ID);
        modData.putLongArray(KEY_BEHAVIOR, behavior);
        data.put(SmarterTouhouMaids.MOD_ID, modData);
    }

    public static long[] getBehavior(EntityMaid maid) {
        try {
            CompoundTag data = maid.getPersistentData();
            if (data.contains(SmarterTouhouMaids.MOD_ID, 10)) {
                CompoundTag modData = data.getCompound(SmarterTouhouMaids.MOD_ID);
                if (modData.contains(KEY_BEHAVIOR, 12)) {
                    return modData.getLongArray(KEY_BEHAVIOR);
                }
            }
        } catch (Exception ignored) {}
        return new long[4];
    }
}