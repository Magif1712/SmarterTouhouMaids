package com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.subsystem.retrospective;

import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.nn.containers.io.value.OutputVector;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.common.AbstractAnchor;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.semantics.containers.io.OutputVectorDomain;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.semantics.containers.io.subspan.BehaviorSpan;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.semantics.containers.io.subspan.FeelingSpan;

/**
 * 流程五（回溯分析）的上下文 data 容器。
 * 代表一个向后看的、分析性的锚点。（向过去滑动）
 */
public class RetrospectiveAnchor extends AbstractAnchor {

    private static final OutputVectorDomain OUTPUT_DOMAIN = new OutputVectorDomain();

    public RetrospectiveAnchor(int feelingSize, int behaviorSize) {
        super(feelingSize, behaviorSize);
    }

    public void pushFromOutput(OutputVector source, long streamHandle) {
        // Retrospective 的数据来自同一 OutputVector，但 feeling 和 behavior 是其中不同区间
        // 这里只能用区间覆盖，因为 source 是一个统一的大向量

        // 直接内联调用，移除多余的局部变量，并创建从0开始的目标区间
        pushFeeling(source.getVector(), OUTPUT_DOMAIN.getFeelingSpan(), new FeelingSpan(0, OUTPUT_DOMAIN.getFeelingSpan().getLength()), streamHandle);
        pushBehavior(source.getVector(), OUTPUT_DOMAIN.getBehaviorSpan(), new BehaviorSpan(0, OUTPUT_DOMAIN.getBehaviorSpan().getLength()), streamHandle);
    }

    // 所有重复代码都已继承，一干二净。
}