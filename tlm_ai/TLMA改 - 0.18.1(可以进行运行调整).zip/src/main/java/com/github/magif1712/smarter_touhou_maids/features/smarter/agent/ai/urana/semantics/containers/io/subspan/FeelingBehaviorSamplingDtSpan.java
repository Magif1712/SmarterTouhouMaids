package com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.semantics.containers.io.subspan;

import com.github.magif1712.smarter_touhou_maids.core.containers.domain.Span;

public class FeelingBehaviorSamplingDtSpan extends Span {

    /**
     * 创建一个记录数组特定区域位置信息的视图。
     *
     * @param offset 视图在原始数组中的起始位置
     * @param length 视图的长度
     */
    public FeelingBehaviorSamplingDtSpan(int offset, int length) {
        super(offset, length);
    }
}