package com.github.magif1712.smarter_touhou_maids;

import com.github.magif1712.smarter_touhou_maids.features.config.ModClientConfig;
import com.github.magif1712.smarter_touhou_maids.features.maid.menu.InitMenus;
import com.github.magif1712.smarter_touhou_maids.features.possession.ServerPossessionManager;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.SmarterClientService;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.debug.VisionDebugHook;
import com.github.magif1712.smarter_touhou_maids.network.NetworkHandler;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(SmarterTouhouMaids.MOD_ID)
public class SmarterTouhouMaids {
    public static final String MOD_ID = "smarter_touhou_maids";

    public SmarterTouhouMaids(FMLJavaModLoadingContext context) {
        IEventBus modEventBus = context.getModEventBus();
        InitMenus.MENUS.register(modEventBus);

        MinecraftForge.EVENT_BUS.register(ServerPossessionManager.INSTANCE);
        MinecraftForge.EVENT_BUS.register(SmarterClientService.INSTANCE);
        ///////////////debug/////////////
        MinecraftForge.EVENT_BUS.register(VisionDebugHook.INSTANCE);
        /////////////debug end///////////
        NetworkHandler.init();

        ModClientConfig.register();
    }
}