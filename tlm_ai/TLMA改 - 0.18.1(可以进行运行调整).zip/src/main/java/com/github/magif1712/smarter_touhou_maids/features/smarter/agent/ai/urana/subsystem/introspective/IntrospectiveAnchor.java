package com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.subsystem.introspective;

import com.github.magif1712.smarter_touhou_maids.core.containers.vector.BoolVector;
import com.github.magif1712.smarter_touhou_maids.core.containers.vector.SlidingPair;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.common.AbstractAnchor;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.semantics.containers.io.OutputVectorDomain;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.semantics.containers.io.subspan.BehaviorSpan;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.semantics.containers.io.subspan.FeelingSpan;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.subsystem.retrospective.RetrospectiveAnchor;

/**
 * 流程七（内省分析）的上下文 data 容器。
 * 代表一个审视现在、规划未来的锚点。
 */
public class IntrospectiveAnchor extends AbstractAnchor {

    public IntrospectiveAnchor(int feelingSize, int behaviorSize) {
        super(feelingSize, behaviorSize);
    }

    /**
     * 从 RetrospectiveAnchor 的“悬浮物”中“戳入”数据，固化为本锚点的“沉淀物”。
     *
     * @param retrospectiveAnchor 流程五的锚点。
     * @param streamHandle        CUDA 流句柄。
     */
    public void pokeFrom(RetrospectiveAnchor retrospectiveAnchor, long streamHandle) {
        // “戳入”操作：将 retrospectiveAnchor 的悬浮物（current）固化为本锚点的沉淀物（previous）
        // 使用复制语义，因为 retrospectiveAnchor 的状态在后续可能仍需使用，不能移动。

        // 1. 复制 feeling
        BoolVector feelingSource = retrospectiveAnchor.getFeeling().getSuspension();
        FeelingSpan feelingSpan = new FeelingSpan(0, feelingSource.size());
        this.feeling.copyRegionTo(SlidingPair.Target.PRECIPITATE, feelingSource, feelingSpan, feelingSpan, streamHandle);

        // 2. 复制 behavior
        BoolVector behaviorSource = retrospectiveAnchor.getBehavior().getSuspension();
        BehaviorSpan behaviorSpan = new BehaviorSpan(0, behaviorSource.size());
        this.behavior.copyRegionTo(SlidingPair.Target.PRECIPITATE, behaviorSource, behaviorSpan, behaviorSpan, streamHandle);
    }

    /**
     * 将推理结果“戳入”本锚点的“悬浮物”中。
     *
     * @param feeling       推理产生的新的感觉状态。
     * @param behavior      推理产生的新的行为。
     * @param streamHandle  CUDA 流句柄。
     */
    public void pokeInto(BoolVector feeling, BoolVector behavior, long streamHandle) {
        // feeling 和 behavior 参数实际上是同一个完整的“输出向量”。
        // 我们需要从中提取出 feeling 和 behavior 各自对应的部分。

        // 1. 定义源向量（输出向量）的语义域
        OutputVectorDomain sourceDomain = new OutputVectorDomain();

        // 2. 处理 feeling 部分
        // 源区间：从输出向量中定义的 feeling 切片
        FeelingSpan feelingSrcSpan = sourceDomain.getFeelingSpan();
        // 目标区间：覆盖本锚点中整个 feeling 向量
        FeelingSpan feelingDestSpan = new FeelingSpan(0, this.feeling.getSuspension().size());
        this.feeling.push(feeling, feelingSrcSpan, feelingDestSpan, streamHandle);

        // 3. 处理 behavior 部分
        // 源区间：从输出向量中定义的 behavior 切片
        BehaviorSpan behaviorSrcSpan = sourceDomain.getBehaviorSpan();
        // 目标区间：覆盖本锚点中整个 behavior 向量
        BehaviorSpan behaviorDestSpan = new BehaviorSpan(0, this.behavior.getSuspension().size());
        this.behavior.push(behavior, behaviorSrcSpan, behaviorDestSpan, streamHandle);
    }
}