package com.github.magif1712.smarter_touhou_maids.features.smarter.agent;

import com.github.magif1712.smarter_touhou_maids.core.containers.domain.Span;
import com.github.magif1712.smarter_touhou_maids.core.containers.texture.Texture;
import com.github.magif1712.smarter_touhou_maids.core.containers.vector.BoolVector;
import com.github.magif1712.smarter_touhou_maids.core.diagnostics.MemoryDiagnostics;
import com.github.magif1712.smarter_touhou_maids.core.execution.event.Event;
import com.github.magif1712.smarter_touhou_maids.core.execution.stream.Stream;
import com.github.magif1712.smarter_touhou_maids.features.possession.core.PossessionManager;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.UranaSystem;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.outlet.BehaviorOutlet;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.semantics.containers.io.InputVectorDomain;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.semantics.containers.io.OutputVectorDomain;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.debug.EffectorDebugHook;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.effector.ActionIntent;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.effector.MotorOps;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.sensor.vision.VisionOps;
import com.github.magif1712.smarter_touhou_maids.features.smarter.network.ServerboundActionIntentPacket;
import com.github.magif1712.smarter_touhou_maids.network.NetworkHandler;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@OnlyIn(Dist.CLIENT)
public class SmarterClientService {

    public static final SmarterClientService INSTANCE = new SmarterClientService();

    private static final Logger LOGGER = LoggerFactory.getLogger("SmarterAgent");

    private static final int FEELING_SIZE = InputVectorDomain.FEELING_SPAN_LENGTH;
    private static final int BEHAVIOR_SIZE = OutputVectorDomain.BEHAVIOR_SPAN_LENGTH;

    private BoolVector feelingBuffer;
    private UranaSystem urana;
    private Stream cudaStream;
    /**
     * 视觉采集完成事件。
     * <p>
     * 视觉 kernel 在 cudaStream 上写完 feelingBuffer 后 record 此 event；
     * Urana 在每轮 runOneTick 开头 waitEvent，确保读到完整视觉数据。
     * 设计原则（真善美第3条）：把"视觉是否写完"这个不实在的状态用实在的 Event 固化下来，
     * 由 GPU 自行排队跨流同步，CPU 不阻塞。
     */
    private Event visionEvent;

    /**
     * 池化的临时纹理，用于视觉采样时的快照隔离。
     * <p>
     * 设计原则（对标 UranaSystem.dtBuffer）：
     * <ul>
     *   <li>在构造函数中一次性创建，避免每 tick 反复分配 OpenGL/CUDA 资源</li>
     *   <li>长期持有并复用，每次 captureScreenViaSnapshot 只做 snapshotFrom 操作</li>
     *   <li>在 shutdown() 时统一释放</li>
     * </ul>
     */
    private Texture snapshotTexture;

    private boolean initialized = false;
    private boolean wasPossessing = false;
    /**
     * dt 调试开关的持久状态（跨“未附身-附身”保留）。
     * urana 创建时读取此值应用到 UranaSystem。
     */
    private boolean dtDebugEnabled = false;

    /**
     * 效应器：把 Urana 产出的 256-bit behavior 解码为 ActionIntent。
     * <p>
     * 有状态（TensionIntegrator 低通滤波 + 迟滞阈值），构造一次、每客户端 tick 复用。
     * 20Hz 解码对 5Hz 更新的 behavior 做时间容错（肌肉保持张力）。
     */
    private MotorOps motorOps;
    /**
     * 行为产出出口（意识-外周边界对象）。
     * <p>
     * 持有 mapped behavior buffer + generation 计数器。由本服务（外周）创建并注入 UranaSystem，
     * 本服务负责其生命周期。主线程在 onClientTick 用其 consumer 面（getGeneration / readBehavior）
     * 零 CUDA 调用消费 Urana 产出的 behavior。UranaSystem 只用其 producer 面，不感知 mapped 性质。
     */
    private BehaviorOutlet behaviorOutlet;
    /**
     * 池化的 behavior host 暂存（256 bit = 8 个 int）。主线程在 onClientTick 里，
     * 当 generation 变化时从 outlet 读到此缓冲，交 MotorOps 解码。
     * generation 未变化时保持上次值继续 tick（肌肉保持张力）。
     */
    private final int[] behaviorScratch = new int[BEHAVIOR_SIZE / 32];
    /**
     * 上次消费的 behavior generation 值。用于检测 Urana 是否产出了新 behavior。
     * 主线程零 CUDA 调用：仅读 outlet.getGeneration()（纯 host 内存读）。
     */
    private int lastGen = -1;
    /**
     * 最近一次发包目标 maid 的实体 id。shutdown 时用它发一帧零 ActionIntent，
     * 让 maid 停止（避免客户端停发后服务端继续执行上一帧陈旧 intent）。
     */
    private int lastMaidId = 0;

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        onClientTick();
    }

    public void onPostRender(int textureId, int texWidth, int texHeight) {
        if (!initialized) {
            try {
                init();
            } catch (Exception e) {
                LOGGER.error("[Agent] 初始化异常", e);
                return;
            }
        }

        // 视觉采样在 cudaStream 上异步执行，与 Urana 的专用 uranaStream 并发：
        // Urana 重计算 kernel 与 D2D/H2D 拷贝跑在 uranaStream，两者不再因 NULL 流串行而互相挂起。
        // vision→Urana 的跨流数据可见性由 visionEvent 显式同步：采集完成后 record，
        // Urana 每轮开头 waitEvent 等待，确保读到完整 feelingBuffer。
        try {
            VisionOps.captureScreenViaSnapshot(
                    textureId,
                    snapshotTexture,
                    feelingBuffer,
                    new Span(0, FEELING_SIZE) {},
                    texWidth, texHeight,
                    cudaStream);
            // 视觉写完 feelingBuffer 后在 cudaStream 上 record，供 uranaStream 跨流等待。
            visionEvent.record(cudaStream.getHandle());
        } catch (Exception e) {
            LOGGER.error("[Agent] 视觉捕获异常", e);
        }
    }

    public void onClientTick() {
        boolean isPossessing = PossessionManager.INSTANCE.isPossessing();

        if (wasPossessing && !isPossessing) {
            shutdown();
        }
        wasPossessing = isPossessing;

        // Urana 已由内部工作线程自驱运行（见 UranaSystem.awaken），每轮产出 behavior 后
        // 经 behaviorOutlet.declareProduced 在 uranaStream 上递增 generation（流内有序，排在写 mapped buffer 之后）。
        // 此处零 CUDA 调用消费：读 generation（纯 host 读）→ 若变化则读 mapped buffer（纯 host memcpy）
        // → MotorOps 解码 → 发包。整条链路无 cudaStreamSynchronize / cudaEventQuery，不 flush WDDM。
        if (!isPossessing || urana == null || motorOps == null) {
            return;
        }
        EntityMaid maid = PossessionManager.INSTANCE.getPossessedMaid();
        if (maid == null) {
            return;
        }
        // smarter mode 关闭时不发包（避免空发 20 包/秒；服务端 ServerboundActionIntentPacket.handle 的 isEnabled 校验也会拦截）。
        if (!PossessionManager.INSTANCE.isSmarterModeEnabled(maid)) {
            return;
        }
        lastMaidId = maid.getId();
        try {
            // 读 generation（纯 host 内存读，零 CUDA 调用，不 flush WDDM 命令缓冲）。
            // generation 变化 = Urana 已产出新 behavior 且 GPU 已写完 mapped buffer（流内有序保证）。
            int gen = behaviorOutlet.getGeneration();
            if (gen != lastGen) {
                lastGen = gen;
                // 从 mapped host 内存读完整 behavior 到 scratch（纯 host memcpy，零 CUDA 调用）。
                behaviorOutlet.readBehavior(behaviorScratch);
            }
            // fresh=false（gen 未变）时 behaviorScratch 保持上次值，MotorOps 继续低通滤波（肌肉保持张力）。
            // MotorOps.tick 返回复用实例，立即序列化发包，不跨 tick 持有引用。
            ActionIntent intent = motorOps.tick(behaviorScratch);
            // 效应器调试观察点：在效应器产出 intent 后、发包前输出人话指令。
            // 关闭时 log 内部第一行即 return（零性能损失）；开启时每 tick 格式化输出到终端。
            EffectorDebugHook.INSTANCE.log(intent);
            NetworkHandler.INSTANCE.sendToServer(new ServerboundActionIntentPacket(maid.getId(), intent));
        } catch (Exception e) {
            LOGGER.error("[Agent] 效应器解码/发包异常", e);
        }
    }

    /**
     * 打印当前 GPU 显存使用情况。轻量级 driver 查询，单次开销微秒级，可低频调用。
     */
    private void logGpuMemory(String tag) {
        try {
            long[] info = MemoryDiagnostics._getMemInfo();
            long free = info[0];
            long total = info[1];
            long used = total - free;
            LOGGER.info("[Agent][VRAM] {} 用={} MB / 空闲={} MB / 总={} MB",
                    tag, used / (1024L * 1024L), free / (1024L * 1024L), total / (1024L * 1024L));
        } catch (Exception e) {
            LOGGER.warn("[Agent][VRAM] {} 查询失败", tag, e);
        }
    }

    private void init() {
        LOGGER.info("[Agent] 初始化 SmarterClientService...");
        this.feelingBuffer = new BoolVector(FEELING_SIZE);
        this.urana = new UranaSystem();
        this.urana.setDtDebugEnabled(this.dtDebugEnabled);
        this.cudaStream = new Stream();
        // 视觉采集完成事件：视觉写完 feelingBuffer 后在 cudaStream 上 record，
        // Urana 每轮开头 waitEvent 跨流等待，替代旧的 NULL 流隐式屏障（真善美第3条：
        // 把“视觉是否写完”这个不实在的状态用实在的 Event 固化，由 GPU 自排队同步）。
        this.visionEvent = new Event();

        this.snapshotTexture = new Texture(VisionOps.AI_WIDTH, VisionOps.AI_HEIGHT);

        // 效应器解码器（仿生肌肉模型，PolarLayout.defaultHumanLike）。
        // 构造一次、跨 tick 复用其内部张力积分/迟滞状态。
        this.motorOps = new MotorOps();

        // 行为产出出口（意识-外周边界对象）：由外周创建，持有 mapped buffer + generation 计数器。
        // 注入 UranaSystem 供其 producer 面使用（写入 buffer + declareProduced 宣告产出），
        // 本服务用其 consumer 面（getGeneration / readBehavior）零 CUDA 调用消费。
        this.behaviorOutlet = new BehaviorOutlet(BEHAVIOR_SIZE);

        // 读取当前附身女仆的 per-maid 快/慢环 minDtMillis（0=不限速），
        // 作为 Urana 工作线程各自的节流参数（启动时读一次，运行中固定）。
        long fastMinDtMillis = 0;
        long slowMinDtMillis = 0;
        EntityMaid maid = PossessionManager.INSTANCE.getPossessedMaid();
        if (maid != null) {
            fastMinDtMillis = PossessionManager.INSTANCE.getFastMinDtMillis(maid);
            slowMinDtMillis = PossessionManager.INSTANCE.getSlowMinDtMillis(maid);
        }

        this.initialized = true;
        // 唤醒 Urana 意识体：启动内部工作线程持续运转，
        // 注入感觉缓冲区引用供工作线程每轮读取（Urana 与 Minecraft tick 解耦），
        // fastMinDtMillis/slowMinDtMillis 各自限制快/慢环两轮最小间隔（0=全速）以降低 GPU 占用。
        // behaviorOutlet 注入后，UranaSystem 用其 producer 面产出 behavior（mapped memory），
        // 本服务在 onClientTick 用其 consumer 面零 CUDA 调用读取。
        this.urana.awaken(this.feelingBuffer, fastMinDtMillis, slowMinDtMillis, this.visionEvent, this.behaviorOutlet);

        // 复位 generation 消费游标，确保二次附身时首轮必读。
        this.lastGen = -1;

        LOGGER.info("[Agent] 初始化完成 (feeling={} bits, behavior={} bits, snapshot={}x{})",
                FEELING_SIZE, BEHAVIOR_SIZE, VisionOps.AI_WIDTH, VisionOps.AI_HEIGHT);
        logGpuMemory("init完成");
    }

    ///////////////debug/////////////
    public BoolVector getFeelingBuffer() {
        return feelingBuffer;
    }

    public boolean isDtDebugEnabled() {
        return dtDebugEnabled;
    }

    public void setDtDebugEnabled(boolean enabled) {
        this.dtDebugEnabled = enabled;
        if (urana != null) {
            urana.setDtDebugEnabled(enabled);
        }
    }
    /////////////debug end///////////

    public void shutdown() {
        if (!initialized) return;
        LOGGER.info("[Agent] 关闭 SmarterClientService...");
        // behavior 产出出口（behaviorOutlet）由本服务持有，在 urana.shutdown() join 后单独关闭。
        // 停止 Urana 工作线程并释放其内部资源（join 工作线程，最多 1.5s+0.5s）。
        // shutdown 内部已调用 close()，且会先 join 工作线程，确保不再并发访问 feelingBuffer / outlet。
        if (urana != null) {
            urana.shutdown();
        }
        // behaviorOutlet 必须在 urana.shutdown() join 工作线程之后关闭：
        // 工作线程每轮写入 outlet 的 buffer + declareProduced，join 完成后无人再访问它，方可安全销毁。
        if (behaviorOutlet != null) {
            try { behaviorOutlet.close(); } catch (Exception ignored) {}
            behaviorOutlet = null;
        }
        // visionEvent 必须在 urana.shutdown() join 工作线程之后关闭：
        // 工作线程每轮开头会 waitEvent(visionEvent)，join 完成后无人再访问它，方可安全销毁。
        if (visionEvent != null) {
            try { visionEvent.close(); } catch (Exception ignored) {}
        }
        if (cudaStream != null) {
            try { cudaStream.close(); } catch (Exception ignored) {}
        }

        if (snapshotTexture != null) {
            try { snapshotTexture.close(); } catch (Exception ignored) {}
        }

        if (feelingBuffer != null) {
            try { feelingBuffer.close(); } catch (Exception ignored) {}
        }

        // 效应器清理：复位张力/迟滞状态，并发一帧零 ActionIntent 让 maid 停止——
        // 客户端停发后服务端不再收到新 intent，若不发零帧，maid 会卡在上一帧陈旧动作上。
        // （smarter mode 已关时服务端会拦截；开启时零帧令其原地静止。服务端清理由
        //  ServerboundSetSmarterModePacket 关闭分支 setNoAi(false) 恢复 brain 完成。）
        if (motorOps != null) {
            try { motorOps.reset(); } catch (Exception ignored) {}
        }
        if (lastMaidId != 0) {
            try {
                NetworkHandler.INSTANCE.sendToServer(
                        new ServerboundActionIntentPacket(lastMaidId, new ActionIntent()));
            } catch (Exception ignored) {}
            lastMaidId = 0;
        }
        lastGen = -1;

        initialized = false;
    }

    private SmarterClientService() {
    }
}