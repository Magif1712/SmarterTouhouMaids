
package com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.subsystem.introspective.context;

import com.github.magif1712.smarter_touhou_maids.core.containers.vector.BoolVector;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.nn.containers.NetworkData;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.nn.containers.io.IOLayerGradients;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.common.UranaConstants;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.common.grad.AbstractGradCell;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.subsystem.introspective.IntrospectiveAnchor;

/**
 * 流程八：内省训练上下文。
 * 继承 AbstractGradCell，两步链条（展望→审视），内部闭环跨轮次梯度。
 */
public class TrainingContext extends AbstractGradCell {
    private static final boolean[][] G_PER_STEP = {
        UranaConstants.G_FUTURE_N,
        UranaConstants.G_PAST_N
    };
    private static final int CHAIN_LENGTH = 2;

    public TrainingContext(NetworkData networkData) {
        this(networkData, null);
    }

    /**
     * 注入共享工作梯度缓冲区的构造函数。
     * 多个串行执行的 GradCell 可共享同一份 IOLayerGradients，省 ~1.5 GB 显存/份。
     *
     * @param sharedGradients 外部注入的工作梯度缓冲区；null 表示本实例自建。
     */
    public TrainingContext(NetworkData networkData, IOLayerGradients sharedGradients) {
        super(networkData, CHAIN_LENGTH, G_PER_STEP, sharedGradients);
    }

    /**
     * 全自动执行。外界不需要知道 ∇C 的存在。
     */
    public void execute(IntrospectiveAnchor anchor, BoolVector dt, long stream) {
        // 填充预分配池
        samplePool[0].set(
            anchor.getFeeling().getSuspension(),
            anchor.getBehavior().getSuspension()
        );
        samplePool[1].set(
            anchor.getFeeling().getPrecipitate(),
            anchor.getBehavior().getPrecipitate()
        );

        super.executeWithClosedLoop(
            anchor.getFeeling().getPrecipitate(), dt, stream);
    }
}