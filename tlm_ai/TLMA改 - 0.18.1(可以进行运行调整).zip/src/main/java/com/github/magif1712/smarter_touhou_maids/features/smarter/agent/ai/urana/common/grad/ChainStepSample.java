package com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.common.grad;

import com.github.magif1712.smarter_touhou_maids.core.containers.vector.BoolVector;

/**
 * 封装了链式处理中单步所需的所有输入和目标数据，代表一个训练样本。
 */
public class ChainStepSample {
    public BoolVector target_F;
    public BoolVector target_B;

    public ChainStepSample(BoolVector target_F, BoolVector target_B) {
        set(target_F, target_B);
    }

    public void set(BoolVector target_F, BoolVector target_B) {
        this.target_F = target_F;
        this.target_B = target_B;
    }
}