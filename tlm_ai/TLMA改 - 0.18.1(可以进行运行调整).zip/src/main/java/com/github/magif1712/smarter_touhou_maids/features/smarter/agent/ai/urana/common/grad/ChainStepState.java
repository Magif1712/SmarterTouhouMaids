package com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.common.grad;

import com.github.magif1712.smarter_touhou_maids.core.containers.vector.BoolVector;

/**
 * 封装了链式处理中单步前向传播产生的、反向传播所必需的内部状态。
 */
public class ChainStepState implements AutoCloseable {
    public final BoolVector input;
    public final BoolVector fz; // 隐藏层预激活值
    public final BoolVector output;

    public ChainStepState(int inputSize, int fzSize, int outputSize) {
        this.input = new BoolVector(inputSize);
        this.fz = new BoolVector(fzSize);
        this.output = new BoolVector(outputSize);
    }

    @Override
    public void close() throws Exception {
        input.close();
        fz.close();
        output.close();
    }
}