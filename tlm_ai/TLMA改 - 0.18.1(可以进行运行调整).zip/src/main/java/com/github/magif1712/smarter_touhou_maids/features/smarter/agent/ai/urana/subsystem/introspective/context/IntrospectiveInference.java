package com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.subsystem.introspective.context;

import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.nn.containers.NetworkData;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.common.UranaConstants;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.common.inference.AbstractInferenceCell;

/**
 * 流程七：内省者推理。
 * N=1 单步，G=FUTURE_1。
 */
public class IntrospectiveInference extends AbstractInferenceCell {
    private static final int CHAIN_LENGTH = 1;

    public IntrospectiveInference(NetworkData networkData) {
        super(networkData, CHAIN_LENGTH, UranaConstants.G_FUTURE_1);
    }
}