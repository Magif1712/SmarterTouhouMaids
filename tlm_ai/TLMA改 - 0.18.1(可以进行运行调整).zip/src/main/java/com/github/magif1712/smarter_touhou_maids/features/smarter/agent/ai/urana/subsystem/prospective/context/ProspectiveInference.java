package com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.subsystem.prospective.context;

import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.nn.containers.NetworkData;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.common.UranaConstants;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.ai.urana.common.inference.AbstractInferenceCell;

/**
 * 流程二：行动者推理。
 * N=2 链条：阶段1 展望未来(G_FUTURE_N) → 阶段2 审视过去(G_PAST_N)。
 */
public class ProspectiveInference extends AbstractInferenceCell {
    private static final boolean[][] G_PER_STEP = {
        UranaConstants.G_FUTURE_N,
        UranaConstants.G_PAST_N
    };
    private static final int CHAIN_LENGTH = 2;

    public ProspectiveInference(NetworkData networkData) {
        super(networkData, CHAIN_LENGTH, G_PER_STEP);
    }
}