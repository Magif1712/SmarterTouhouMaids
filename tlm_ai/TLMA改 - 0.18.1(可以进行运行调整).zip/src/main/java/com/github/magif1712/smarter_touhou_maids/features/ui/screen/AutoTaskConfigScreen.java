package com.github.magif1712.smarter_touhou_maids.features.ui.screen;

import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.SmarterClientService;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.debug.EffectorDebugHook;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.debug.VisionDebugHook;
import com.github.magif1712.smarter_touhou_maids.features.smarter.config.SmarterConfig;
import com.github.magif1712.smarter_touhou_maids.features.maid.menu.AutoTaskConfigMenu;
import com.github.magif1712.smarter_touhou_maids.features.possession.client.ui.PossessionToggleWidget;
import com.github.magif1712.smarter_touhou_maids.features.possession.core.PossessionManager;
import com.github.magif1712.smarter_touhou_maids.features.smarter.state.MaidSmarterState;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Inventory;
import org.lwjgl.glfw.GLFW;

/**
 * “自动任务”的配置界面。
 * <p>
 * 该界面允许玩家配置与 AI 相关的参数，核心功能包括：
 * 1. “附身”模式开关：允许玩家“牺牲”自己的实体以换取女仆更强的 AI 性能。
 * 2. 辅助神经元数量：配置 AI 模型中的参数。
 */
public class AutoTaskConfigScreen extends AbstractContainerScreen<AutoTaskConfigMenu> {
    /**
     * GUI 背景颜色
     */
    private static final int BG_COLOR = 0xCC000000;
    /**
     * GUI 宽度
     */
    private static final int GUI_WIDTH = 380;
    /**
     * GUI 高度
     */
    private static final int GUI_HEIGHT = 280;
    /**
     * 神经元数量输入的文本框
     */
    private EditBox neuronCountBox;
    private EditBox fastMinDtBox;
    private EditBox slowMinDtBox;
    private CycleButton<Boolean> smarterModeButton;

    public AutoTaskConfigScreen(AutoTaskConfigMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = GUI_WIDTH;
        this.imageHeight = GUI_HEIGHT;
    }

    /**
     * 初始化 GUI 组件。
     * 在这里创建和布局所有按钮、文本框等。
     */
    @Override
    protected void init() {
        super.init();
        int startX = (this.width - this.imageWidth) / 2;
        int startY = (this.height - this.imageHeight) / 2;
        EntityMaid maid = this.menu.getMaid();

        if (maid != null) {
            // ========== 上层模式：允许附身（y=25） ==========
            boolean possessionCurrent = PossessionManager.INSTANCE.isPossessionEnabled(maid);
            CycleButton<Boolean> possessionButton = CycleButton.onOffBuilder(possessionCurrent)
                    .create(startX + 10, startY + 25, 150, 20,
                            Component.literal("允许附身"),
                            (btn, value) -> {
                                PossessionManager.INSTANCE.setPossessionEnabled(maid, value);
                                // 级联：附身关闭时，更聪明模式必须同步关闭且禁用
                                if (!value && this.smarterModeButton != null) {
                                    this.smarterModeButton.setValue(false);
                                    this.smarterModeButton.active = false;
                                    PossessionManager.INSTANCE.setSmarterModeEnabled(maid, false);
                                } else if (this.smarterModeButton != null) {
                                    this.smarterModeButton.active = true;
                                }
                            });
            possessionButton.setTooltip(Tooltip.create(Component.literal("是否允许玩家附身此女仆")));
            this.addRenderableWidget(possessionButton);

            // ========== 下层模式：被附身后开启更聪明模式（y=50） ==========
            boolean smarterCurrent = PossessionManager.INSTANCE.isSmarterModeEnabled(maid);
            this.smarterModeButton = CycleButton.onOffBuilder(smarterCurrent)
                    .create(startX + 10, startY + 50, 150, 20,
                            Component.literal("被附身后开启更聪明模式"),
                            (btn, value) -> PossessionManager.INSTANCE.setSmarterModeEnabled(maid, value));
            this.smarterModeButton.setTooltip(Tooltip.create(
                    Component.literal("附身时是否启用AI增强决策")));
            this.smarterModeButton.active = possessionCurrent; // 依赖关系
            this.addRenderableWidget(this.smarterModeButton);
        }

        // 神经元输入框整体下移避免重叠（y=95）
        this.neuronCountBox = new EditBox(this.font, startX + 10, startY + 95, 150, 20, Component.literal(""));
        this.neuronCountBox.setValue(String.valueOf(SmarterConfig.neuronCount.get()));
        this.neuronCountBox.setResponder(text -> {
            String trimmed = text.trim();
            if (trimmed.isEmpty()) {
                return;
            }

            try {
                // 验证并保存数值
                int value = Mth.clamp(Integer.parseInt(trimmed), 1, 1024);
                SmarterConfig.neuronCount.set(value);
            } catch (NumberFormatException ignored) {
            }
        });
        this.addRenderableWidget(this.neuronCountBox);

        // ========== 调试模式：AI 视觉调试 dump 开关（y=120）==========
        // 全局开关（非 per-maid），控制 VisionDebugHook 是否定期 dump AI 视觉到硬盘。
        // 与上方“允许附身/更聪明模式”开关同构（CycleButton 模式），但状态存于
        // VisionDebugHook 全局单例——因为调试是全局的，而非 per-maid。
        // 关闭后 VisionDebugHook.onClientTick 入口即 return，调试逻辑零执行（零性能损失）。
        boolean visionDebugCurrent = VisionDebugHook.INSTANCE.isEnabled();
        CycleButton<Boolean> visionDebugButton = CycleButton.onOffBuilder(visionDebugCurrent)
                .create(startX + 10, startY + 120, 150, 20,
                        Component.literal("AI视觉调试"),
                        (btn, value) -> VisionDebugHook.INSTANCE.setEnabled(value));
        visionDebugButton.setTooltip(Tooltip.create(
                Component.literal("开启后定期dump AI视觉到 debug/smarter_touhou_maids/vision_debug（有性能开销）")));
        this.addRenderableWidget(visionDebugButton);

        // ========== 调试模式：dt 轮间时间间隔调试开关（y=145）==========
        // 全局开关（非 per-maid），控制 UranaSystem 是否每轮输出轮间时间间隔 dt 到日志。
        // 与 AI视觉调试开关同构（CycleButton 模式），状态存于 SmarterClientService 全局单例
        // （跨“未附身-附身”保留，urana 创建时应用）。
        // 关闭后 UranaSystem.encodeDt 不输出日志（dt 编码仍执行，因它是网络输入，开销纳秒级）。
        boolean dtDebugCurrent = SmarterClientService.INSTANCE.isDtDebugEnabled();
        CycleButton<Boolean> dtDebugButton = CycleButton.onOffBuilder(dtDebugCurrent)
                .create(startX + 10, startY + 145, 150, 20,
                        Component.literal("dt轮间间隔调试"),
                        (btn, value) -> SmarterClientService.INSTANCE.setDtDebugEnabled(value));
        dtDebugButton.setTooltip(Tooltip.create(
                Component.literal("开启后每轮输出 urana 轮间时间间隔 dt（毫秒）到日志")));
        this.addRenderableWidget(dtDebugButton);

        // ========== per-maid：Urana 快环最小轮间间隔（y=170）==========
        // 与“被附身后开启更聪明模式”同属 per-maid 配置（经 PossessionManager 同步到 maid NBT）。
        // 0=不限速（全速运转，默认）；>0=快环两轮间至少间隔该毫秒数（降低 GPU 占用）。
        // 提交时机：回车 / 关闭界面（见 commitFastMinDtMillis），避免输入过程中频繁发包。
        if (maid != null) {
            this.fastMinDtBox = new EditBox(this.font, startX + 10, startY + 170, 150, 20, Component.literal(""));
            this.fastMinDtBox.setValue(String.valueOf(PossessionManager.INSTANCE.getFastMinDtMillis(maid)));
            this.fastMinDtBox.setTooltip(Tooltip.create(
                    Component.literal("觉前行快环两轮间最小时间间隔（毫秒），0=不限速")));
            this.addRenderableWidget(this.fastMinDtBox);

            // ========== per-maid：Urana 慢环最小轮间间隔（y=195）==========
            this.slowMinDtBox = new EditBox(this.font, startX + 10, startY + 195, 150, 20, Component.literal(""));
            this.slowMinDtBox.setValue(String.valueOf(PossessionManager.INSTANCE.getSlowMinDtMillis(maid)));
            this.slowMinDtBox.setTooltip(Tooltip.create(
                    Component.literal("觉前行慢环两轮间最小时间间隔（毫秒），0=不限速")));
            this.addRenderableWidget(this.slowMinDtBox);
        }

        // ========== 调试模式：效应器调试开关（y=220）==========
        // 全局开关（非 per-maid），控制 EffectorDebugHook 是否每 tick 输出效应器指令到终端。
        // 与 AI视觉调试 / dt调试开关同构（CycleButton 模式），状态存于 EffectorDebugHook 全局单例。
        // 关闭后 EffectorDebugHook.log 入口即 return，调试逻辑零执行（零性能损失）。
        boolean effectorDebugCurrent = EffectorDebugHook.INSTANCE.isEnabled();
        CycleButton<Boolean> effectorDebugButton = CycleButton.onOffBuilder(effectorDebugCurrent)
                .create(startX + 10, startY + 220, 150, 20,
                        Component.literal("效应器调试"),
                        (btn, value) -> EffectorDebugHook.INSTANCE.setEnabled(value));
        effectorDebugButton.setTooltip(Tooltip.create(
                Component.literal("开启后每 tick 输出效应器指令到终端（前进/平移/视角/跳跃/攻击等）")));
        this.addRenderableWidget(effectorDebugButton);
    }

    /**
     * 处理键盘按键事件。
     *
     * @param keyCode  按键代码
     * @param scanCode 扫描码
     * @param modifiers 功能键（如 Shift, Ctrl）
     * @return 如果事件被处理则返回 true
     */
    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        // 当神经元数量文本框被选中时，按回车键提交输入
        if (this.neuronCountBox != null && this.neuronCountBox.isFocused() && (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER)) {
            this.commitNeuronCount();
            this.setFocused(null);
            return true;
        }
        if (this.fastMinDtBox != null && this.fastMinDtBox.isFocused() && (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER)) {
            this.commitFastMinDtMillis();
            this.setFocused(null);
            return true;
        }
        if (this.slowMinDtBox != null && this.slowMinDtBox.isFocused() && (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER)) {
            this.commitSlowMinDtMillis();
            this.setFocused(null);
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    /**
     * 当界面被关闭时调用。
     * 用于确保在退出前保存所有未提交的更改。
     */
    @Override
    public void removed() {
        this.commitNeuronCount();
        this.commitFastMinDtMillis();
        this.commitSlowMinDtMillis();
        super.removed();
    }

    /**
     * 渲染 GUI 的背景。
     *
     * @param guiGraphics GUI 图形实例
     * @param partialTick 部分 tick
     * @param mouseX      鼠标 X 坐标
     * @param mouseY      鼠标 Y 坐标
     */
    @Override
    protected void renderBg(GuiGraphics guiGraphics, float partialTick, int mouseX, int mouseY) {
        int startX = (this.width - this.imageWidth) / 2;
        int startY = (this.height - this.imageHeight) / 2;
        // 绘制一个半透明的黑色背景
        guiGraphics.fill(startX, startY, startX + this.imageWidth, startY + this.imageHeight, BG_COLOR);
    }

    /**
     * 渲染 GUI 上的文本标签。
     *
     * @param guiGraphics GUI 图形实例
     * @param mouseX      鼠标 X 坐标
     * @param mouseY      鼠标 Y 坐标
     */
    @Override
    protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
        guiGraphics.drawString(this.font, this.title, this.titleLabelX, this.titleLabelY, 0x39c5bb, true);
        guiGraphics.drawString(this.font, "每层辅助神经元数量", 10, 80, 0x39c5bb, false);
        guiGraphics.drawString(this.font, "觉前行快环两轮间最小间隔(ms)", 10, 160, 0x39c5bb, false);
        guiGraphics.drawString(this.font, "觉前行慢环两轮间最小间隔(ms)", 10, 185, 0x39c5bb, false);
    }

    /**
     * 提交神经元数量的更改。
     * 该方法会读取文本框中的值，进行验证、格式化，并最终保存到配置中。
     */
    private void commitNeuronCount() {
        if (this.neuronCountBox == null) {
            return;
        }

        String trimmed = this.neuronCountBox.getValue().trim();
        if (trimmed.isEmpty()) {
            return;
        }

        try {
            int value = Mth.clamp(Integer.parseInt(trimmed), 1, 1024);
            String normalized = String.valueOf(value);
            // 如果格式化后的值与输入值不同，则更新文本框
            if (!normalized.equals(this.neuronCountBox.getValue())) {
                this.neuronCountBox.setValue(normalized);
            }
            SmarterConfig.neuronCount.set(value);
            // 下面的代码被注释掉了，但它们原本用于与原生库同步神经元数量并获取反馈
//            int capacity = NativeLibLoader.syncNeuronCount(value);
            Minecraft minecraft = Minecraft.getInstance();
//            if (minecraft.player != null) {
//                minecraft.player.sendSystemMessage(Component.literal("GPU 自动任务缓冲区容量：" + capacity));
//            }
        } catch (RuntimeException exception) {
            Minecraft minecraft = Minecraft.getInstance();
            if (minecraft.player != null) {
                minecraft.player.sendSystemMessage(Component.literal("GPU 自动任务缓冲区初始化失败：" + exception.getMessage()));
            }
        }
    }

    /**
     * 提交 Urana 快环最小轮间间隔的更改（per-maid）。
     * 读取文本框值，clamp 到 [0, 5000]，经 PossessionManager 同步到 maid NBT。
     */
    private void commitFastMinDtMillis() {
        if (this.fastMinDtBox == null) return;
        EntityMaid maid = this.menu.getMaid();
        if (maid == null) return;

        String trimmed = this.fastMinDtBox.getValue().trim();
        if (trimmed.isEmpty()) return;

        try {
            // Mth.clamp 无 long 重载（会回落到 float 重载致精度损失），故手动 clamp。
            long parsed = Long.parseLong(trimmed);
            long value = Math.max(0, Math.min(5000, parsed));
            String normalized = String.valueOf(value);
            if (!normalized.equals(this.fastMinDtBox.getValue())) {
                this.fastMinDtBox.setValue(normalized);
            }
            PossessionManager.INSTANCE.setFastMinDtMillis(maid, value);
        } catch (NumberFormatException ignored) {
        }
    }

    /**
     * 提交 Urana 慢环最小轮间间隔的更改（per-maid）。
     * 读取文本框值，clamp 到 [0, 5000]，经 PossessionManager 同步到 maid NBT。
     */
    private void commitSlowMinDtMillis() {
        if (this.slowMinDtBox == null) return;
        EntityMaid maid = this.menu.getMaid();
        if (maid == null) return;

        String trimmed = this.slowMinDtBox.getValue().trim();
        if (trimmed.isEmpty()) return;

        try {
            // Mth.clamp 无 long 重载（会回落到 float 重载致精度损失），故手动 clamp。
            long parsed = Long.parseLong(trimmed);
            long value = Math.max(0, Math.min(5000, parsed));
            String normalized = String.valueOf(value);
            if (!normalized.equals(this.slowMinDtBox.getValue())) {
                this.slowMinDtBox.setValue(normalized);
            }
            PossessionManager.INSTANCE.setSlowMinDtMillis(maid, value);
        } catch (NumberFormatException ignored) {
        }
    }
}