package com.github.magif1712.smarter_touhou_maids.core.ai.mapping;

import com.github.magif1712.smarter_touhou_maids.core.containers.domain.Span;
import com.github.magif1712.smarter_touhou_maids.core.containers.vector.BoolVector;
import com.github.magif1712.smarter_touhou_maids.core.containers.vector.IntVector;

/**
 * 一个公共的包装类，提供了对通用原生操作的访问接口。
 */
public class GenericOps {

    /**
     * 对一个整数向量进行原地取反和二值化，并将结果存入一个布尔向量。
     *
     * @param srcIntVector  源整数向量。
     * @param dstBoolVector 目标布尔向量。
     * @param streamHandle  CUDA 流句柄（kernel 在此流上执行）。
     */
    public static void negateAndBinarize(IntVector srcIntVector, BoolVector dstBoolVector, long streamHandle) {
        if (srcIntVector.size() != dstBoolVector.size()) {
            throw new IllegalArgumentException("Source and destination vectors must have the same size.");
        }
        negateAndBinarizeRegion(
                dstBoolVector, new Span(0, dstBoolVector.size()) {},
                srcIntVector, new Span(0, srcIntVector.size()) {},
                streamHandle
        );
    }

    /**
     * 对整数向量的一个子区域进行取反和二值化，并将结果存入布尔向量的对应子区域。
     *
     * @param dst          目标布尔向量。
     * @param dstSpan      目标向量中的区域。
     * @param src          源整数向量。
     * @param srcSpan      源向量中的区域。
     * @param streamHandle CUDA 流句柄。
     */
    public static void negateAndBinarizeRegion(BoolVector dst, Span dstSpan, IntVector src, Span srcSpan, long streamHandle) {
        if (dstSpan.getLength() != srcSpan.getLength()) {
            throw new IllegalArgumentException("Source and destination spans must have the same length.");
        }
        if (dstSpan.getOffset() + dstSpan.getLength() > dst.size()) {
            throw new IndexOutOfBoundsException("Destination span is out of bounds.");
        }
        if (srcSpan.getOffset() + srcSpan.getLength() > src.size()) {
            throw new IndexOutOfBoundsException("Source span is out of bounds.");
        }

        GenericOpsNative._negateAndBinarizeRegion(
                dst.requireHandle(),
                dstSpan.getOffset(),
                src.requireHandle(),
                srcSpan.getOffset(),
                srcSpan.getLength(),
                streamHandle
        );
    }
}
