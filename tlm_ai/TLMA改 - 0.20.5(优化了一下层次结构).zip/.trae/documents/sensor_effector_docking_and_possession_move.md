# 感受器/效应器可对接化 + possession 落位

## Context（为什么做这件事）

当前 `reflex_arc_system_agent` 下的 `sensor/` 与 `effector/` 是**硬编码**的：`ReflexArcSystemAgent` 直接 `new MotorOps()`、直接调 `VisionOps.captureScreenViaSnapshot(...)`，换一种感受器/效应器必须改 agent 代码。这违背设计原则第 2 条（"模式1即便换了一种模式2也可以不改代码就可以正确运行"）。

`nn` 包已经做了可对接化样板：顶层 `INeuralNetwork`（契约）+ `NnFactory`（工厂）+ `bnn/`（具体子包），urana 持 `INeuralNetwork` 引用，`NnRegistry` 让附属可注册新 nn 而零改动 urana。`ai` 包、`agent` 包同构。

本任务把 `sensor/` 与 `effector/` 也做成这套结构，并把独立的 `features/possession/` feature 落位为感受器的一个子模式（"当眼睛"），与 `vision`（"去看"）并列成为唯一的那个具体感受器 `possession_sensor` 的两个子模式。

**意识域 C（真善美第 2 条落地）**：
- 感受器 = agent 的"眼"：`possession`（当眼睛：玩家充当女仆的眼+区块加载）+ `vision`（去看：屏幕→feeling buffer 捕获）。两个子模式 → 两个子包 `vision/` + `possession/`。
- 效应器 = agent 的"肌肉"：`bionic_muscle`（拮抗肌对+极化布局+张力积分的仿生肌肉解码 behavior→ActionIntent）。`ActionIntent` 是效应器产出契约，`execution/` 是服务端固定执行（消费 ActionIntent），二者不随效应器换而变。
- agent（模式1）持 `ISensor`+`IEffector`+`IAiSystem` 引用（注入），换其中任何一个 agent 零改动。

**真善美第 3 条**：把"感受器/效应器可替换"这个不实在的约束，用实在的接口（有签名的方法）+ 工厂 + 注册表固化。

## 关键命名决策（已与用户确认）

- 具体感受器子包：`possession_sensor`（不叫 `possession`，避免与内部 `possession/` 子模式重名）
- 具体效应器子包：`bionic_muscle`
- 可对接深度：完全模仿 `ai`/`agent`/`nn` 包结构（接口+工厂+具体子包+注册表+GUI 选择）

## 目标包结构

### sensor/（可对接化）
```
sensor/
├── ISensor.java                    [新] 契约：awaken/capture/shutdown
├── SensorFactory.java              [新] 工厂（叶子，@FunctionalInterface）：create(feelingSize)
└── possession_sensor/              [新] 具体感受器子包
    ├── PossessionSensor.java       [新] ISensor 实现，编排 vision 捕获
    ├── PossessionSensorFactory.java[新] SensorFactory 实现
    ├── vision/                     [移] 去看（from sensor/vision/）
    │   ├── VisionOps.java
    │   └── VisionNative.java
    └── possession/                 [移] 当眼睛（from features/possession/，整树搬入）
        ├── ServerPossessionManager.java
        ├── core/PossessionManager.java
        ├── client/...
        ├── config/...
        └── network/...
```
> 注：possession 落位为 `possession_sensor/possession/` 子包（而非包根）。理由：用户把包名从 `possession` 改为 `possession_sensor` 正是为了与内部 `possession` 子模式区分——这隐含存在一个独立的 `possession/` 子模式，对应 `possession/` 子包。这样 `vision/`（去看）与 `possession/`（当眼睛）是 `possession_sensor` 下清晰并列的两个子模式，最贴合用户"vision负责去看，possession负责当眼睛"的表述。

### effector/（可对接化）
```
effector/
├── IEffector.java                  [新] 契约：awaken/tick/shutdown
├── EffectorFactory.java            [新] 工厂（叶子）：create(behaviorSize)
├── ActionIntent.java               [留] 产出契约（效应器产出、服务端消费，固定不变）
├── execution/                      [留] 服务端固定执行（消费 ActionIntent，不随效应器变）
│   ├── MaidActionSink.java
│   └── SmarterEffectorHandlers.java
└── bionic_muscle/                  [新] 具体效应器子包
    ├── BionicMuscleEffector.java   [改] 由 MotorOps 重命名+实现 IEffector
    ├── BionicMuscleEffectorFactory.java [新] EffectorFactory 实现
    ├── muscle/                     [移] from effector/muscle/
    └── semantics/                  [移] from effector/semantics/
```
> `MotorOps` → `BionicMuscleEffector`（对齐 `BnnNeuralNetwork` 命名：前缀+接口名）。`execution/` 留在 `effector/` 顶层，因它是 ActionIntent 契约的服务端消费者，所有效应器都产出同一 ActionIntent，故执行端固定。

## 契约设计

### ISensor（镜像 INeuralNetwork + 现有 VisionOps 用法）
```java
public interface ISensor {
    /** 接收共享引用（feelingBuffer/cudaStream/completionEvent，与 AI 共享）+ 创建捕获资源（snapshotTexture）。 */
    void awaken(BoolVector feelingBuffer, Stream cudaStream, Event completionEvent);
    /** 感知→feelingBuffer（cudaStream 上异步），完成后 record completionEvent。 */
    void capture(int textureId, int texWidth, int texHeight);
    /** 释放捕获资源。 */
    void shutdown();
}
```
`PossessionSensor` 包裹 `VisionOps`：awaken 建 `Texture(AI_WIDTH,AI_HEIGHT)`；capture 调 `VisionOps.captureScreenViaSnapshot(...)` + `completionEvent.record(stream)`；shutdown 关 texture。

### IEffector（镜像现有 MotorOps 用法）
```java
public interface IEffector {
    void awaken();                          // 初始化肌肉状态（PolarLayout+肌群+迟滞）
    ActionIntent tick(int[] packedBehavior); // behavior→ActionIntent 解码（复用实例）
    void shutdown();                        // 复位张力/迟滞（= 原 MotorOps.reset）
}
```
`BionicMuscleEffector` 由 `MotorOps` 重构：构造收 behaviorSize（校验==256），awaken 做原构造的重活，tick/shutdown 沿用 MotorOps 逻辑。

### 工厂（镜像 NnFactory：叶子，签名只含本征尺寸）
- `SensorFactory.create(int feelingSize)` — feelingSize 由 agent 层从 `ai.feelingSize()` 算出传入。
- `EffectorFactory.create(int behaviorSize)` — behaviorSize 由 `ai.behaviorSize()` 算出传入。
- `PossessionSensorFactory` 校验 feelingSize==1920*1080*24；`BionicMuscleEffectorFactory` 校验 behaviorSize==256。

## 注册表 + 工厂自驱（完全模仿 ai/nn）

### RegistryIds（加 2 个，叶子层，subRegistryId=null）
- `SENSOR = smarter_touhou_maids:sensor`
- `EFFECTOR = smarter_touhou_maids:effector`

### AiModeDefaults.registerDefaults()（加 2 个 registry，各 1 个默认 entry）
- SensorRegistry（default=`possession_sensor`）→ `PossessionSensorFactory`，subRegistryId=null
- EffectorRegistry（default=`bionic_muscle`）→ `BionicMuscleEffectorFactory`，subRegistryId=null

### ReflexArcSystemAgentFactory.create(config) 自驱三个 registry
```
ai = 查 AiRegistry → aiFactory.create(config)
sensor = 查 SensorRegistry → sensorFactory.create(ai.feelingSize())
effector = 查 EffectorRegistry → effectorFactory.create(ai.behaviorSize())
return new ReflexArcSystemAgent(ai, sensor, effector)
```
（config 透传，各工厂各取所需——真善美第 1 条"真"）

### ReflexArcSystemAgent 改为三注入
- 构造：`ReflexArcSystemAgent(IAiSystem ai, ISensor sensor, IEffector effector)`
- awaken：建 feelingBuffer/cudaStream/visionEvent/behaviorScratch/behaviorOutlet → `sensor.awaken(feelingBuffer, cudaStream, visionEvent)` → `effector.awaken()` → `ai.awaken(...)`
- onPostRender：`sensor.capture(textureId, texWidth, texHeight)`（替代 VisionOps 调用+event record）
- onClientTick：`effector.tick(behaviorScratch)`（替代 motorOps.tick）
- shutdown：`sensor.shutdown()` + `effector.shutdown()` + 释放 feelingBuffer/cudaStream/visionEvent/behaviorOutlet

## GUI（AutoTaskConfigScreen）

sensor/effector 与 ai 是**并行**关系（agent 下有 sensor+ai+effector 三个子模式），而现有 GUI 是 `subRegistryId` 线性递归（agent→ai→process→nn）。故 sensor/effector 用**独立非递归叶子按钮**（它们是叶子层），不塞进线性递归。

- 新增私有方法 `buildLeafModeSelector(maid, x, y, registryId)`：建单个 CycleButton（不递归），per-maid 经 `PossessionManager.setMode/getMode`（通用同步，复用现有 ServerboundSetAiModePacket）。
- 布局（感知→思考→行动 顺序）：`y=75` 起 → sensor 叶子按钮 → `buildModeSelectors(AGENT)` 递归 ai 链 → effector 叶子按钮。
- `GUI_HEIGHT`：360 → 410（多 2 行×25px）。`renderLabels` 用 `modeEndYGui` 自适应，无需改偏移常量。

### 语言文件（en_us.json / zh_cn.json）
- `mode.smarter_touhou_maids.sensor.possession_sensor` = "Possession Sensor" / "附身感受器"
- `mode.smarter_touhou_maids.effector.bionic_muscle` = "Bionic Muscle Effector" / "仿生肌肉效应器"

## possession 搬家（features/possession → sensor/possession_sensor/possession/）

整树搬入 `possession_sensor/possession/`，包名 `features.possession` → `features.smarter.agent.reflex_arc_system_agent.sensor.possession_sensor.possession`（子包 core/client/config/network 跟随）。

### 需更新 import 的外部引用（~14 处）
- `SmarterTouhouMaids.java`（ServerPossessionManager）
- `features/client/ClientSetup.java`（PossessionManager）
- `features/config/ModClientConfig.java`（PossessionConfig）
- `features/maid/compat/task/AutoTask.java`
- `SmarterClientService.java`（PossessionManager）
- `ReflexArcSystemAgent.java`（PossessionManager）
- `debug/VisionDebugHook.java`（PossessionManager）
- `features/ui/screen/AutoTaskConfigScreen.java`（PossessionManager + PossessionToggleWidget）
- `mixin/GameRendererMixin.java`（PossessionManager）
- `network/NetworkHandler.java`（4 个 possession 包）
- `features/smarter/network/ClientboundAiModeSyncPacket.java`、`ClientboundMinDtMillisSyncPacket.java`、`ClientboundSmarterModeSyncPacket.java`（PossessionManager）

## vision 搬家的 JNI 影响（重点，曾踩坑）

`vision/` 移到 `possession_sensor/vision/`，Java 包名变 → JNI 方法编码必变。

- **Java**：`VisionOps`/`VisionNative` 包声明 `...sensor.vision` → `...sensor.possession_sensor.vision`
- **C++ 源码搬家**：`native/stm_ai/src/.../sensor/vision/` → `.../sensor/possession_sensor/vision/`（5 文件：cuda_gl_vision.cu/.h、interop/vision_bridge.cu/.h、interop/vision_jni.cpp）
- **JNI 方法编码**：`vision_jni.cpp` 内 `features_smarter_agent_reflex_1arc_1system_1agent_sensor_vision` → `features_smarter_agent_reflex_1arc_1system_1agent_sensor_possession_1sensor_vision`（`possession_sensor` → `possession_1sensor`，下划线 JNI 编码为 `_1`）
- **CMakeLists.txt** 106-110 行：5 条源路径同步改

## 实施步骤（按依赖顺序）

1. **新建契约+工厂**：`ISensor`/`SensorFactory`/`IEffector`/`EffectorFactory`（4 文件，sensor/、effector/ 顶层）
2. **新建具体感受器**：`PossessionSensor`/`PossessionSensorFactory`（包裹 VisionOps）
3. **重命名+重构效应器**：`MotorOps` → `bionic_muscle/BionicMuscleEffector`（实现 IEffector），新建 `BionicMuscleEffectorFactory`；`muscle/`+`semantics/` 移入 `bionic_muscle/`
4. **搬 vision**：`sensor/vision/` → `sensor/possession_sensor/vision/`（Java 包声明 + JNI 编码 + CMake 路径 + C++ 目录）
5. **搬 possession**：`features/possession/` 整树 → `sensor/possession_sensor/possession/`，批量改包声明；更新 ~14 处外部 import
6. **注册表**：`RegistryIds` 加 SENSOR/EFFECTOR；`AiModeDefaults` 注册 2 个 registry
7. **agent 接线**：`ReflexArcSystemAgent` 改三注入+awaken/onPostRender/onClientTick/shutdown 委托；`ReflexArcSystemAgentFactory` 自驱三 registry
8. **GUI**：`AutoTaskConfigScreen` 加 `buildLeafModeSelector` + sensor/effector 按钮，GUI_HEIGHT→410
9. **语言文件**：加 2 条 mode 翻译
10. **Javadoc 清理**：`IAgent`/`ActionIntent`/`EffectorDebugHook` 中 VisionOps/MotorOps 引用更新

## 验证

1. `./gradlew compileJava` 通过（包声明/import/JNI 编码全对）
2. 残留扫描：`rg "features\.possession"`、`rg "sensor\.vision"`（不含 possession_sensor）、`rg "\bMotorOps\b"`、`rg "reflex_1arc_1system_1agent_sensor_vision\b"`（旧 JNI 编码）均应为空
3. 用户手动重建 native 库（删 `native/stm_ai/build/` 重跑 CMake），因为 vision JNI 路径+编码变了
4. 游戏内：附身女仆→开 smarter 模式→确认视觉采集/AI 运行/效应器动作正常（功能零回归）；AutoTaskConfigScreen 出现 sensor/effector 两个新按钮且可选
