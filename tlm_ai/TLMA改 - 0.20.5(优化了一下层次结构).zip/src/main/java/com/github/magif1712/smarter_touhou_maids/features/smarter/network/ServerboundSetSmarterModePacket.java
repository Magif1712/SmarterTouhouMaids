package com.github.magif1712.smarter_touhou_maids.features.smarter.network;

import com.github.magif1712.smarter_touhou_maids.features.smarter.state.MaidSmarterState;
import com.github.magif1712.smarter_touhou_maids.network.NetworkHandler;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.PacketDistributor;

import java.util.UUID;
import java.util.function.Supplier;

/**
 * 客户端 → 服务端：切换 smarter 模式。
 * <p>
 * smarter 开启时由 {@link com.github.magif1712.smarter_touhou_maids.mixin.MobServerAiStepSuppressMixin}
 * 在 {@code Mob.serverAiStep} HEAD cancel 抑制 TLM 整套 vanilla AI（brain + goalSelector +
 * controls = 脊髓反射），让 MaidActionSink（意识→肌肉）独占实体控制权；关闭时 mixin 守卫
 * 自然放行，原版 AI 复原。
 * <p>
 * 设计原则（真善美第 2 条）：意识域 C 中"smarter 接管 = 意识独占肌肉、脊髓反射被抑制"，
 * 代码域 D 用"cancel serverAiStep"固化该抑制。C 中没有"travel 也被关掉"的模式，故 D 中也不能有——
 * 故不采用 {@code setNoAi(true)}（方案A）：它会令 {@code isEffectiveAi()=false}，{@code LivingEntity.aiStep}
 * 跳过 {@code travel()}，maid 彻底无法移动。本方案只 cancel {@code serverAiStep}，{@code isEffectiveAi()}
 * 保持 true，{@code travel()} 正常运转，MaidActionSink 自给 {@code setSpeed/setXxa/setZza} 不依赖 moveControl。
 * <p>
 * 此 packet 仅翻转 smarter 状态标志，不再触碰 {@code NoAi}。方案A 残留的 {@code NoAi=true}
 * 由 {@link com.github.magif1712.smarter_touhou_maids.features.smarter.agent.reflex_arc_system_agent.effector.execution.SmarterEffectorHandlers}
 * 在 EntityJoinLevelEvent 统一清零。
 */
public class ServerboundSetSmarterModePacket {

    private final UUID maidUUID;
    private final boolean enabled;

    public ServerboundSetSmarterModePacket(UUID maidUUID, boolean enabled) {
        this.maidUUID = maidUUID;
        this.enabled = enabled;
    }

    public static void encode(ServerboundSetSmarterModePacket msg, FriendlyByteBuf buf) {
        buf.writeUUID(msg.maidUUID);
        buf.writeBoolean(msg.enabled);
    }

    public static ServerboundSetSmarterModePacket decode(FriendlyByteBuf buf) {
        return new ServerboundSetSmarterModePacket(buf.readUUID(), buf.readBoolean());
    }

    public static void handle(ServerboundSetSmarterModePacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sender = ctx.get().getSender();
            if (sender == null) return;

            Entity entity = ((ServerLevel) sender.level()).getEntity(msg.maidUUID);
            if (!(entity instanceof EntityMaid maid)) return;
            if (!sender.getUUID().equals(maid.getOwnerUUID())) return;

            MaidSmarterState.setEnabled(maid, msg.enabled);
            // 不再调用 maid.setNoAi(...)：脊髓反射抑制由 MobServerAiStepSuppressMixin 在
            // serverAiStep HEAD cancel 完成（方案B）。setNoAi(true) 会令 isEffectiveAi()=false，
            // 导致 LivingEntity.aiStep 跳过 travel()，maid 无法移动。mixin 守卫读取此处的
            // MaidSmarterState 标志决定是否 cancel，故仅翻转标志即可。packet handler 的
            // isEnabled 校验会拦截关闭后的残余 ActionIntent 包。
            NetworkHandler.INSTANCE.send(
                PacketDistributor.PLAYER.with(() -> sender),
                new ClientboundSmarterModeSyncPacket(msg.maidUUID, msg.enabled)
            );
        });
        ctx.get().setPacketHandled(true);
    }
}
