package com.github.magif1712.smarter_touhou_maids.mixin;

import com.github.magif1712.smarter_touhou_maids.features.smarter.state.MaidSmarterState;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import net.minecraft.world.entity.Mob;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 抑制原版 AI 的 {@code Mob.serverAiStep}（脊髓反射），让 smarter 模式下
 * {@link com.github.magif1712.smarter_touhou_maids.features.smarter.agent.reflex_arc_system_agent.effector.execution.MaidActionSink}
 * （意识→肌肉）独占实体控制权。
 * <p>
 * {@code serverAiStep} 内含 sensing / targetSelector / goalSelector / navigation /
 * {@code customServerAiStep}（TLM Brain 在此运转）/ moveControl / lookControl / jumpControl。
 * 在 smarter 开启时整体 cancel，等价于"脊髓反射被意识抑制"，但<b>不</b>动 {@code isNoAi()} 标志——
 * 这是与 {@code setNoAi(true)}（方案A）的关键区别。
 * <p>
 * 设计原则（真善美第 2 条）：意识域 C 中"smarter 接管 = 意识独占肌肉、脊髓反射被抑制"，
 * 代码域 D 用"cancel serverAiStep"固化该抑制。C 中没有"travel 也被关掉"的模式，故 D 中也不能有——
 * {@code setNoAi(true)} 会令 {@code isEffectiveAi()=false} 进而使 {@code LivingEntity.aiStep}
 * 跳过 {@code travel()}，maid 彻底无法移动（C 中无此模式，D 中须杜绝）。本 mixin 只 cancel
 * {@code serverAiStep}，{@code isEffectiveAi()} 保持 true，{@code travel()} 仍以
 * {@code xxa/zza + getSpeed()} 正常运转——而 MaidActionSink 已自给 {@code setSpeed/setXxa/setZza}
 *（不依赖被 cancel 的 moveControl.tick），故移动链路完整。
 * <p>
 * 设计原则（真善美第 3 条）：把"脊髓反射是否被抑制"这个不实在的状态，用实在的 mixin cancel 固化。
 * <p>
 * Mixin 目标是 {@code Mob.class}（{@code serverAiStep} 声明所在，且为 {@code final} 不可被子类覆盖），
 * 用 {@code instanceof EntityMaid} 守卫，避免影响其它 mob。
 */
@Mixin(Mob.class)
public abstract class MobServerAiStepSuppressMixin {

    @Inject(method = "serverAiStep", at = @At("HEAD"), cancellable = true)
    private void smarter_touhou_maids$suppressServerAiStepWhenSmarter(CallbackInfo ci) {
        Mob self = (Mob) (Object) this;
        if (self instanceof EntityMaid maid && MaidSmarterState.isEnabled(maid)) {
            // smarter 开启：cancel 整个 serverAiStep = 抑制 brain + goalSelector + controls，
            // 但 isNoAi 标志不动，isEffectiveAi() 仍为 true，travel() 正常运行。
            ci.cancel();
        }
    }
}
