package com.github.magif1712.smarter_touhou_maids.features.smarter.agent;

import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.reflex_arc_system_agent.sensor.possession_sensor.possession.core.PossessionManager;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.registry.Registry;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.registry.RegistryEntry;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.registry.RegistryIds;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.registry.RegistryManager;
import com.github.magif1712.smarter_touhou_maids.features.smarter.state.MaidSmarterState;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * smarter 模式的客户端入口与生命周期容器（薄容器，委托 {@link IAgent} 执行业务逻辑）。
 * <p>
 * 本类是 Forge 事件总线接入点（{@link #onClientTick}）与渲染钩子接入点
 * （{@link #onPostRender}），负责：
 * <ul>
 *   <li>附身状态生命周期管理（wasPossessing 检测 → init / shutdown）</li>
 *   <li>从 {@link RegistryIds#AGENT} 顶层 registry 查 factory 创建 agent（工厂自驱组装下层）</li>
 *   <li>委托 agent 执行 onClientTick / onPostRender / shutdown</li>
 * </ul>
 * <p>
 * 本类只关心"何时创建/销毁 agent、何时委托执行"。视觉采集、AI 运行、效应器解码、发包、
 * 调试开关等都是 agent 的内部模式，不属本类。附属 agent 的 debug hook 通过
 * {@link #getAgent()} 获取当前 agent 实例并自行向下转型访问。
 * <p>
 * 设计原则（真善美第2条）：C 中"smarter 接管的事件入口与生命周期"是本类的模式，
 * "感知→思考→行动的执行"是 agent 的模式。两者分离，附属可替换 agent 而不动事件入口。
 */
@OnlyIn(Dist.CLIENT)
public class SmarterClientService {

    public static final SmarterClientService INSTANCE = new SmarterClientService();

    private static final Logger LOGGER = LoggerFactory.getLogger("ReflexArcSystem");

    private IAgent agent;
    private boolean initialized = false;
    private boolean wasPossessing = false;

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        boolean isPossessing = PossessionManager.INSTANCE.isPossessing();
        if (wasPossessing && !isPossessing) {
            shutdown();
        }
        wasPossessing = isPossessing;

        if (!isPossessing || agent == null) {
            return;
        }
        agent.onClientTick();
    }

    public void onPostRender(int textureId, int texWidth, int texHeight) {
        if (!initialized) {
            try {
                init();
            } catch (Exception e) {
                LOGGER.error("[ReflexArc] 初始化异常", e);
                return;
            }
        }
        if (agent != null) {
            agent.onPostRender(textureId, texWidth, texHeight);
        }
    }

    private void init() {
        LOGGER.info("[ReflexArc] 初始化 ReflexArcSystem...");
        EntityMaid maid = PossessionManager.INSTANCE.getPossessedMaid();

        // 组装 config：复制 maid 的 AiModes（各层 mode id）+ urana 节律参数。
        // maid 为 null 时 config 为空，registry.resolve("") fallback 到各层默认 entry（旧存档兼容）。
        CompoundTag config = new CompoundTag();
        if (maid != null) {
            config.merge(MaidSmarterState.getAiModes(maid));
            config.putLong("FastMinDtMillis", PossessionManager.INSTANCE.getFastMinDtMillis(maid));
            config.putLong("SlowMinDtMillis", PossessionManager.INSTANCE.getSlowMinDtMillis(maid));
        }

        // 工厂自驱组装：外周只调顶层 agent factory，下层（ai→process→nn）组装自驱。
        // config 透传，各层 factory 各取所需（真善美第1条"真"：每层只读自己需要的 key）。
        Registry<?> agentRegistry = RegistryManager.INSTANCE.get(RegistryIds.AGENT);
        RegistryEntry<?> agentEntry = agentRegistry.resolve(config.getString(RegistryIds.AGENT.toString()));
        AgentFactory agentFactory = (AgentFactory) agentEntry.getFactory();
        this.agent = agentFactory.create(config);
        this.agent.awaken();

        this.initialized = true;
        LOGGER.info("[ReflexArc] 初始化完成");
    }

    public void shutdown() {
        if (!initialized) return;
        LOGGER.info("[ReflexArc] 关闭 ReflexArcSystem...");
        if (agent != null) {
            agent.shutdown();
            agent = null;
        }
        initialized = false;
    }

    /**
     * 获取当前 agent 实例（供 debug hook 向下转型访问 agent 内部状态）。
     * 未附身时返回 null。
     */
    public IAgent getAgent() {
        return agent;
    }

    private SmarterClientService() {
    }
}
