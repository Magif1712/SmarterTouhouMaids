package com.github.magif1712.smarter_touhou_maids.features.smarter.agent.reflex_arc_system_agent.sensor.possession_sensor.possession.client.ui;

import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.reflex_arc_system_agent.sensor.possession_sensor.possession.core.PossessionManager;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.network.chat.Component;

public class PossessionToggleWidget {
    public static CycleButton<Boolean> create(int x, int y, int width, int height, EntityMaid maid) {
        if (maid == null) {
            throw new IllegalArgumentException("Maid cannot be null when creating PossessionToggleWidget");
        }
        Tooltip tooltip = Tooltip.create(Component.literal("是否允许玩家附身此女仆"));
        boolean current = PossessionManager.INSTANCE.isPossessionEnabled(maid);

        CycleButton<Boolean> button = CycleButton.onOffBuilder(current)
                .create(x, y, width, height, Component.literal("允许附身"),
                        (btn, value) -> PossessionManager.INSTANCE.setPossessionEnabled(maid, value));

        button.setTooltip(tooltip);
        return button;
    }
}