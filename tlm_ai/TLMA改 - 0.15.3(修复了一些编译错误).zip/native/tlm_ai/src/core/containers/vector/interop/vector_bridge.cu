#include <iostream>
#include <vector>
#include <stdexcept>
#include <string>
#include "../Vector.h"
#include "../VectorMapping.h"
#include "vector_bridge.h"

extern "C"
{
    // ====================================================================
    // Vector<bool> 接口
    // ====================================================================

    Vector<bool> *VectorCreateBool()
    {
        try
        {
            return new Vector<bool>();
        }
        catch (const std::exception &e)
        {
            std::cerr << "Error in VectorCreateBool: " << e.what() << std::endl;
            return nullptr;
        }
    }

    void VectorAllocateBool(Vector<bool> *vec, size_t size)
    {
        if (vec)
        {
            try
            {
                vec->allocate(size);
            }
            catch (const std::exception &e)
            {
                std::cerr << "Error in VectorAllocateBool: " << e.what() << std::endl;
            }
        }
    }

    void VectorDeleteBool(Vector<bool> *vec)
    {
        delete vec;
    }

    void VectorCopyFromHostBool(Vector<bool> *vec, const uint32_t *h_data, size_t wordCount)
    {
        if (vec)
        {
            try
            {
                vec->copyFromHost(h_data, wordCount);
            }
            catch (const std::exception &e)
            {
                std::cerr << "Error in VectorCopyFromHostBool: " << e.what() << std::endl;
            }
        }
    }

    void VectorCopyToHostBool(Vector<bool> *vec, uint32_t *h_data, size_t wordCount)
    {
        if (vec)
        {
            try
            {
                vec->copyToHost(h_data, wordCount);
            }
            catch (const std::exception &e)
            {
                std::cerr << "Error in VectorCopyToHostBool: " << e.what() << std::endl;
            }
        }
    }

    void VectorSaveBool(Vector<bool> *vec, const char *filename)
    {
        if (vec && filename)
        {
            try
            {
                vec->save(filename);
            }
            catch (const std::exception &e)
            {
                std::cerr << "Error in VectorSaveBool: " << e.what() << std::endl;
            }
        }
    }

    void VectorLoadFromFileBool(Vector<bool> *vec, const char *filename)
    {
        if (vec && filename)
        {
            try
            {
                vec->loadFromFile(filename);
            }
            catch (const std::exception &e)
            {
                std::cerr << "Error in VectorLoadFromFileBool: " << e.what() << std::endl;
            }
        }
    }

    size_t VectorGetSizeBool(Vector<bool> *vec)
    {
        return vec ? vec->size() : 0;
    }

    void VectorSetRegionBool(Vector<bool> *dst, size_t dest_offset_bits, const Vector<bool> *src)
    {
        if (dst && src)
        {
            try
            {
                dst->setRegion(dest_offset_bits, *src);
            }
            catch (const std::exception &e)
            {
                std::cerr << "Error in VectorSetRegionBool: " << e.what() << std::endl;
            }
        }
    }

    void VectorCopyRegionFromBool(Vector<bool> *dst, size_t dest_offset_bits, const Vector<bool> *src, size_t src_offset_bits, size_t num_bits)
    {
        if (dst && src)
        {
            try
            {
                dst->copyRegionFrom(dest_offset_bits, *src, src_offset_bits, num_bits);
            }
            catch (const std::exception &e)
            {
                std::cerr << "Error in VectorCopyRegionFromBool: " << e.what() << std::endl;
            }
        }
    }

    void VectorCopyRegionFromHostBool(Vector<bool> *dst, size_t dest_offset, const unsigned char* src_data, size_t num_bits)
    {
        if (dst)
        {
            try
            {
                dst->copyRegionFromHost(dest_offset, src_data, num_bits);
            }
            catch (const std::exception &e)
            {
                std::cerr << "Error in VectorCopyRegionFromHostBool: " << e.what() << std::endl;
                // 重新抛出，以便 JNI 层可以捕获它
                throw;
            }
        }
    }

    // ===================================================================
    // Vector<int> 接口
    // ===================================================================

    Vector<int> *VectorCreateInt()
    {
        try
        {
            return new Vector<int>();
        }
        catch (const std::exception &e)
        {
            std::cerr << "Error in VectorCreateInt: " << e.what() << std::endl;
            return nullptr;
        }
    }

    void VectorAllocateInt(Vector<int> *vec, size_t size)
    {
        if (vec)
        {
            try
            {
                vec->allocate(size);
            }
            catch (const std::exception &e)
            {
                std::cerr << "Error in VectorAllocateInt: " << e.what() << std::endl;
            }
        }
    }

    void VectorDeleteInt(Vector<int> *vec)
    {
        delete vec;
    }

    void VectorCopyFromHostInt(Vector<int> *vec, const int *h_data, size_t count)
    {
        if (vec)
        {
            try
            {
                vec->copyFromHost(h_data, count);
            }
            catch (const std::exception &e)
            {
                std::cerr << "Error in VectorCopyFromHostInt: " << e.what() << std::endl;
            }
        }
    }

    void VectorCopyToHostInt(Vector<int> *vec, int *h_data, size_t count)
    {
        if (vec)
        {
            try
            {
                vec->copyToHost(h_data, count);
            }
            catch (const std::exception &e)
            {
                std::cerr << "Error in VectorCopyToHostInt: " << e.what() << std::endl;
            }
        }
    }

    void VectorSaveInt(Vector<int> *vec, const char *filename)
    {
        if (vec && filename)
        {
            try
            {
                vec->save(filename);
            }
            catch (const std::exception &e)
            {
                std::cerr << "Error in VectorSaveInt: " << e.what() << std::endl;
            }
        }
    }

    void VectorLoadFromFileInt(Vector<int> *vec, const char *filename)
    {
        if (vec && filename)
        {
            try
            {
                vec->loadFromFile(filename);
            }
            catch (const std::exception &e)
            {
                std::cerr << "Error in VectorLoadFromFileInt: " << e.what() << std::endl;
            }
        }
    }

    size_t VectorGetSizeInt(Vector<int> *vec)
    {
        return vec ? vec->size() : 0;
    }

    void VectorCopyRegionFromInt(Vector<int>* dst, size_t dst_offset, const Vector<int>* src, size_t src_offset, size_t num_elements)
    {
        if (dst && src)
        {
            try
            {
                dst->copyRegionFrom(dst_offset, *src, src_offset, num_elements);
            }
            catch (const std::exception &e)
            {
                std::cerr << "Error in VectorCopyRegionFromInt: " << e.what() << std::endl;
            }
        }
    }

    void VectorSetRegionInt(Vector<int>* dst, size_t dest_offset, const Vector<int>* src)
    {
        if (dst && src)
        {
            try
            {
                dst->setRegion(dest_offset, *src);
            }
            catch (const std::exception &e)
            {
                std::cerr << "Error in VectorSetRegionInt: " << e.what() << std::endl;
            }
        }
    }

    void VectorCopyRegionFromHostInt(Vector<int>* dst, size_t dest_offset, const int* src_host_data, size_t num_elements)
    {
        if (dst && src_host_data)
        {
            try
            {
                dst->copyRegionFromHost(dest_offset, src_host_data, num_elements);
            }
            catch (const std::exception &e)
            {
                std::cerr << "Error in VectorCopyRegionFromHostInt: " << e.what() << std::endl;
            }
        }
    }

    // ===================================================================
    // 算法接口
    // ===================================================================

    void VectorScatterBits(Vector<bool> *src, Vector<bool> *dst, Vector<int> *P)
    {
        if (src && dst && P)
        {
            try
            {
                scatterBits(*src, *dst, *P);
            }
            catch (const std::exception &e)
            {
                std::cerr << "Error in VectorScatterBits: " << e.what() << std::endl;
            }
        }
    }

    void VectorXorBool(Vector<bool> *dst, Vector<bool> *src)
    {
        if (dst && src)
        {
            try
            {
                xorVectors(*dst, *src);  
            }
            catch (const std::exception &e)
            {
                std::cerr << "Error in VectorXorBool: " << e.what() << std::endl;
            }
        }
    }

    void VectorSubtractBool(
        const Vector<bool>* a,
        const Vector<bool>* b,
        long long bit_offset,
        Vector<int>* c,
        long long c_int_offset,
        long long bit_length)
    {
        if (a && b && c)
        {
            try
            {
                subtractBoolVectors(a->data(), b->data(), bit_offset, c->data(), c_int_offset, bit_length);
            }
            catch (const std::exception &e)
            {
                std::cerr << "Error in VectorSubtractBool: " << e.what() << std::endl;
            }
        }
    }



    void VectorMultiplyByScalarInt(Vector<int> *vector, int scalar, size_t offset, size_t length)
    {
        if (vector)
        {
            try
            {
                multiplyVectorByScalarInPlace(*vector, scalar, offset, length);
            }
            catch (const std::exception &e)
            {
                std::cerr << "Error in VectorMultiplyByScalarInt: " << e.what() << std::endl;
            }
        }
    }
}