#pragma once
#include "Vector.h"
#include <cuda_runtime.h>

/**
 * @brief 将源位向量 A 中的每一位按照索引映射 P 分散写入目标位向量 B。
 */
void scatterBits(const Vector<bool> &src, Vector<bool> &dst, const Vector<int> &P);

/**
 * @brief 执行 A ^= B 操作。
 */
void xorVectors(Vector<bool> &A, const Vector<bool> &B);

/**
 * @brief [区间操作] 从两个位压缩的布尔向量计算差值，并将结果存入一个整数向量的指定区间。
 * @param d_A           被减数布尔向量的设备指针
 * @param d_B           减数布尔向量的设备指针
 * @param bit_offset    d_A 和 d_B 中开始计算的比特偏移量
 * @param d_C           目标整数向量的设备指针
 * @param c_int_offset  d_C 中开始写入的整数偏移量
 * @param bit_length    要处理的比特数
 * @param stream        CUDA 流
 */
void subtractBoolVectors(
    const uint32_t* d_A,
    const uint32_t* d_B,
    int64_t         bit_offset,
    int32_t*        d_C,
    int64_t         c_int_offset,
    int64_t         bit_length,
    cudaStream_t    stream = 0);

/**
 * @brief 对 Vector<T> 执行原地标量乘法 (vector *= scalar)。
 */
template <typename T>
void multiplyVectorByScalarInPlace(
    Vector<T>& vector,
    T scalar,
    size_t offset,
    size_t length);