#pragma once
#include <cstddef>
#include <cstdint>

// 前向声明，避免包含完整的 CUDA 头文件
template <typename T>
class Vector;

extern "C"
{
    // Vector<bool> 接口
    Vector<bool> *VectorCreateBool();
    void VectorAllocateBool(Vector<bool> *vec, size_t size);
    void VectorDeleteBool(Vector<bool> *vec);
    void VectorCopyFromHostBool(Vector<bool> *vec, const uint32_t *h_data, size_t wordCount);
    void VectorCopyToHostBool(Vector<bool> *vec, uint32_t *h_data, size_t wordCount);
    void VectorSaveBool(Vector<bool> *vec, const char *filename);
    void VectorLoadFromFileBool(Vector<bool> *vec, const char *filename);
    size_t VectorGetSizeBool(Vector<bool> *vec);
    void VectorSetRegionBool(Vector<bool> *dst, size_t dest_offset_bits, const Vector<bool> *src);
    void VectorCopyRegionFromBool(Vector<bool> *dst, size_t dest_offset_bits, const Vector<bool> *src, size_t src_offset_bits, size_t num_bits);
    void VectorCopyRegionFromHostBool(Vector<bool> *dst, size_t dest_offset, const unsigned char* src_data, size_t num_bits);

    // Vector<int> 接口
    Vector<int> *VectorCreateInt();
    void VectorAllocateInt(Vector<int> *vec, size_t size);
    void VectorDeleteInt(Vector<int> *vec);
    void VectorCopyFromHostInt(Vector<int> *vec, const int *h_data, size_t count);
    void VectorCopyToHostInt(Vector<int> *vec, int *h_data, size_t count);
    void VectorSaveInt(Vector<int> *vec, const char *filename);
    void VectorLoadFromFileInt(Vector<int> *vec, const char *filename);
    size_t VectorGetSizeInt(Vector<int> *vec);
    void VectorCopyRegionFromInt(Vector<int>* dst, size_t dst_offset, const Vector<int>* src, size_t src_offset, size_t num_elements);
    void VectorSetRegionInt(Vector<int>* dst, size_t dest_offset, const Vector<int>* src);
    void VectorCopyRegionFromHostInt(Vector<int>* dst, size_t dest_offset, const int* src_host_data, size_t num_elements);

    // 算法接口
    void VectorScatterBits(Vector<bool> *src, Vector<bool> *dst, Vector<int> *P);
    void VectorXorBool(Vector<bool> *dst, Vector<bool> *src);
    void VectorSubtractBool(
        const Vector<bool>* a,
        const Vector<bool>* b,
        long long bit_offset,
        Vector<int>* c,
        long long c_int_offset,
        long long bit_length);

    void VectorMultiplyByScalarInt(Vector<int> *vector, int scalar, size_t offset, size_t length);
}