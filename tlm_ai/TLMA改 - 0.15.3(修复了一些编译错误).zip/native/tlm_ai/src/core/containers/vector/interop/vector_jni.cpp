#include <jni.h>
#include <cstdint>
#include <vector>
#include <memory>
#include <exception>
#include "../../../interop/jni_helper.h"
#include "vector_bridge.h"

extern "C"
{

    JNIEXPORT jlong JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1createVectorBool)(JNIEnv *, jclass)
    {
        auto *vec = VectorCreateBool();
        return reinterpret_cast<jlong>(vec);
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1allocateBool)(JNIEnv *, jclass, jlong handle, jint size)
    {
        auto *vec = reinterpret_cast<Vector<bool> *>(handle);
        if (vec)
            VectorAllocateBool(vec, static_cast<size_t>(size));
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1deleteVectorBool)(JNIEnv *, jclass, jlong handle)
    {
        auto *vec = reinterpret_cast<Vector<bool> *>(handle);
        if (vec)
            VectorDeleteBool(vec);
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1copyFromHostBool)(JNIEnv *env, jclass, jlong handle, jintArray data, jint count)
    {
        auto *vec = reinterpret_cast<Vector<bool> *>(handle);
        if (!vec || !data)
            return;

        jint *j_data = env->GetIntArrayElements(data, nullptr);
        VectorCopyFromHostBool(vec, reinterpret_cast<const uint32_t *>(j_data), static_cast<size_t>(count));
        env->ReleaseIntArrayElements(data, j_data, JNI_ABORT);
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1copyToHostBool)(JNIEnv *env, jclass, jlong handle, jintArray data, jint count)
    {
        auto *vec = reinterpret_cast<Vector<bool> *>(handle);
        if (!vec || !data)
            return;

        jint *j_data = env->GetIntArrayElements(data, nullptr);
        VectorCopyToHostBool(vec, reinterpret_cast<uint32_t *>(j_data), static_cast<size_t>(count));
        env->ReleaseIntArrayElements(data, j_data, 0);
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1saveBool)(JNIEnv *env, jclass, jlong handle, jstring filename)
    {
        auto *vec = reinterpret_cast<Vector<bool> *>(handle);
        if (!vec || !filename)
            return;

        const char *c_filename = env->GetStringUTFChars(filename, nullptr);
        VectorSaveBool(vec, c_filename);
        env->ReleaseStringUTFChars(filename, c_filename);
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1loadFromFileBool)(JNIEnv *env, jclass, jlong handle, jstring filename)
    {
        auto *vec = reinterpret_cast<Vector<bool> *>(handle);
        if (!vec || !filename)
            return;

        const char *c_filename = env->GetStringUTFChars(filename, nullptr);
        VectorLoadFromFileBool(vec, c_filename);
        env->ReleaseStringUTFChars(filename, c_filename);
    }

    JNIEXPORT jint JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1getSizeBool)(JNIEnv *, jclass, jlong handle)
    {
        auto *vec = reinterpret_cast<Vector<bool> *>(handle);
        return static_cast<jint>(VectorGetSizeBool(vec));
    }

    JNIEXPORT jlong JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1createVectorInt)(JNIEnv *, jclass)
    {
        auto *vec = VectorCreateInt();
        return reinterpret_cast<jlong>(vec);
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1allocateInt)(JNIEnv *, jclass, jlong handle, jint size)
    {
        auto *vec = reinterpret_cast<Vector<int> *>(handle);
        if (vec)
            VectorAllocateInt(vec, static_cast<size_t>(size));
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1deleteVectorInt)(JNIEnv *, jclass, jlong handle)
    {
        auto *vec = reinterpret_cast<Vector<int> *>(handle);
        if (vec)
            VectorDeleteInt(vec);
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1copyFromHostInt)(JNIEnv *env, jclass, jlong handle, jintArray data, jint count)
    {
        auto *vec = reinterpret_cast<Vector<int> *>(handle);
        if (!vec || !data)
            return;

        jint *j_data = env->GetIntArrayElements(data, nullptr);
        VectorCopyFromHostInt(vec, reinterpret_cast<const int *>(j_data), static_cast<size_t>(count));
        env->ReleaseIntArrayElements(data, j_data, JNI_ABORT);
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1copyToHostInt)(JNIEnv *env, jclass, jlong handle, jintArray data, jint count)
    {
        auto *vec = reinterpret_cast<Vector<int> *>(handle);
        if (!vec || !data)
            return;

        jint *j_data = env->GetIntArrayElements(data, nullptr);
        VectorCopyToHostInt(vec, reinterpret_cast<int *>(j_data), static_cast<size_t>(count));
        env->ReleaseIntArrayElements(data, j_data, 0);
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1saveInt)(JNIEnv *env, jclass, jlong handle, jstring filename)
    {
        auto *vec = reinterpret_cast<Vector<int> *>(handle);
        if (!vec || !filename)
            return;

        const char *c_filename = env->GetStringUTFChars(filename, nullptr);
        VectorSaveInt(vec, c_filename);
        env->ReleaseStringUTFChars(filename, c_filename);
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1loadFromFileInt)(JNIEnv *env, jclass, jlong handle, jstring filename)
    {
        auto *vec = reinterpret_cast<Vector<int> *>(handle);
        if (!vec || !filename)
            return;

        const char *c_filename = env->GetStringUTFChars(filename, nullptr);
        VectorLoadFromFileInt(vec, c_filename);
        env->ReleaseStringUTFChars(filename, c_filename);
    }

    JNIEXPORT jint JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1getSizeInt)(JNIEnv *, jclass, jlong handle)
    {
        auto *vec = reinterpret_cast<Vector<int> *>(handle);
        return static_cast<jint>(VectorGetSizeInt(vec));
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1copyRegionFromInt)(JNIEnv *env, jclass, jlong dst_handle, jlong dst_offset, jlong src_handle, jlong src_offset, jlong count)
    {
        auto *dst = reinterpret_cast<Vector<int> *>(dst_handle);
        auto *src = reinterpret_cast<Vector<int> *>(src_handle);
        if (dst && src)
        {
            VectorCopyRegionFromInt(dst, static_cast<size_t>(dst_offset), src, static_cast<size_t>(src_offset), static_cast<size_t>(count));
        }
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1setRegionInt)(JNIEnv *env, jclass, jlong dst_handle, jlong dst_offset, jlong src_handle)
    {
        auto *dst = reinterpret_cast<Vector<int> *>(dst_handle);
        auto *src = reinterpret_cast<Vector<int> *>(src_handle);
        if (dst && src)
        {
            VectorSetRegionInt(dst, static_cast<size_t>(dst_offset), src);
        }
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1copyRegionFromHostInt)(JNIEnv *env, jclass, jlong dst_handle, jlong dst_offset, jintArray src_array, jlong count)
    {
        auto *dst = reinterpret_cast<Vector<int> *>(dst_handle);
        if (!dst || !src_array)
            return;

        jint *src_ptr = env->GetIntArrayElements(src_array, nullptr);
        if (src_ptr == nullptr)
            return; // 内存不足

        VectorCopyRegionFromHostInt(dst, static_cast<size_t>(dst_offset), src_ptr, static_cast<size_t>(count));

        env->ReleaseIntArrayElements(src_array, src_ptr, JNI_ABORT);
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1scatterBits)(JNIEnv *, jclass, jlong srcHandle, jlong dstHandle, jlong pHandle)
    {
        auto *src = reinterpret_cast<Vector<bool> *>(srcHandle);
        auto *dst = reinterpret_cast<Vector<bool> *>(dstHandle);
        auto *p = reinterpret_cast<Vector<int> *>(pHandle);
        if (src && dst && p)
        {
            VectorScatterBits(src, dst, p);
        }
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1xorBool)(JNIEnv *, jclass, jlong dstHandle, jlong srcHandle)
    {
        auto *dst = reinterpret_cast<Vector<bool> *>(dstHandle);
        auto *src = reinterpret_cast<Vector<bool> *>(srcHandle);
        if (dst && src)
        {
            VectorXorBool(dst, src);
        }
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1setRegionBool)(JNIEnv *, jclass, jlong dstHandle, jlong destOffset, jlong srcHandle)
    {
        auto *dst = reinterpret_cast<Vector<bool> *>(dstHandle);
        auto *src = reinterpret_cast<Vector<bool> *>(srcHandle);
        if (dst && src)
        {
            VectorSetRegionBool(dst, static_cast<size_t>(destOffset), src);
        }
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1copyRegionFromBool)(JNIEnv *, jclass, jlong dstHandle, jlong dstOffset, jlong srcHandle, jlong srcOffset, jlong numBits)
    {
        auto *dst = reinterpret_cast<Vector<bool> *>(dstHandle);
        auto *src = reinterpret_cast<Vector<bool> *>(srcHandle);
        if (dst && src)
        {
            VectorCopyRegionFromBool(
                dst,
                static_cast<size_t>(dstOffset),
                src,
                static_cast<size_t>(srcOffset),
                static_cast<size_t>(numBits));
        }
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1copyRegionFromHostBool)(
        JNIEnv *env, jclass, jlong handle, jlong dest_offset, jbooleanArray src_data, jint num_bits)
    {

        jboolean *src_ptr = env->GetBooleanArrayElements(src_data, nullptr);
        if (src_ptr == nullptr)
        {
            return;
        }

        try
        {
            auto *dst = reinterpret_cast<Vector<bool> *>(handle);
            VectorCopyRegionFromHostBool(dst, dest_offset, src_ptr, num_bits);
        }
        catch (const std::exception &e)
        {
            jni_helper::throw_runtime_exception(env, e.what());
        }

        env->ReleaseBooleanArrayElements(src_data, src_ptr, 0);
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1subtractBool)(
        JNIEnv *env, jclass, jlong aHandle, jlong bHandle, jlong bitOffset, jlong cHandle, jlong cIntOffset, jlong bitLength)
    {
        try
        {
            auto *a = reinterpret_cast<Vector<bool> *>(aHandle);
            auto *b = reinterpret_cast<Vector<bool> *>(bHandle);
            auto *c = reinterpret_cast<Vector<int> *>(cHandle);

            if (a && b && c)
            {
                VectorSubtractBool(a, b, bitOffset, c, cIntOffset, bitLength);
            }
        }
        catch (const std::exception &e)
        {
            jni_helper::throw_runtime_exception(env, e.what());
        }
    }

    JNIEXPORT void JNICALL JNI_METHOD(core_containers_vector, VectorNative, _1multiplyByScalarInt)(JNIEnv *env, jclass, jlong handle, jint scalar, jlong offset, jlong length)
    {
        auto *vec = reinterpret_cast<Vector<int> *>(handle);
        if (vec)
        {
            try
            {
                VectorMultiplyByScalarInt(vec, scalar, static_cast<size_t>(offset), static_cast<size_t>(length));
            }
            catch (const std::exception &e)
            {
                jni_helper::throw_runtime_exception(env, e.what());
            }
        }
    }


}