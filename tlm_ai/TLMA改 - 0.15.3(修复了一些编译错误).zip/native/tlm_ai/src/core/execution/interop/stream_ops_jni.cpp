#include <jni.h>
#include "core/interop/jni_helper.h"
#include "stream_ops_bridge.h"

JNIEXPORT jlong JNICALL JNI_METHOD(core_execution, StreamNative, _1createStream)(
    JNIEnv* env,
    jclass clazz)
{
    return reinterpret_cast<jlong>(createStreamBridge());
}

JNIEXPORT void JNICALL JNI_METHOD(core_execution, StreamNative, _1destroyStream)(
    JNIEnv* env,
    jclass clazz,
    jlong stream_handle)
{
    destroyStreamBridge(reinterpret_cast<cudaStream_t>(stream_handle));
}

JNIEXPORT void JNICALL JNI_METHOD(core_execution, StreamNative, _1synchronize)(
    JNIEnv* env,
    jclass clazz,
    jlong stream_handle)
{
    synchronizeStreamBridge(reinterpret_cast<cudaStream_t>(stream_handle));
}