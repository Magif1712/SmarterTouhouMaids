#pragma once

#include <cuda_runtime.h>

#ifdef __cplusplus
extern "C" {
#endif

cudaStream_t createStreamBridge();
void destroyStreamBridge(cudaStream_t stream);
void synchronizeStreamBridge(cudaStream_t stream);

#ifdef __cplusplus
}
#endif