#pragma once
#include <jni.h>

/**
 * JNI 命名助手宏
 * 
 * 假定 Java 包路径前缀为: com.github.magif1712.smarter_touhou_maids
 * 对应 JNI 前缀: Java_com_github_magif1712_smarter_1touhou_1maids
 */

#define JNI_PKG_PREFIX Java_com_github_magif1712_smarter_1touhou_1maids

// 定义 JNI 方法名的宏
// pkg: core_containers_vector
// cls: VectorNative
// method: _createVectorBool
// 展开后: Java_com_github_magif1712_smarter_1touhou_1maids_core_1containers_1vector_VectorNative_1createVectorBool
#define JNI_METHOD(pkg, cls, method) JNI_PKG_PREFIX##_##pkg##_##cls##_##method

namespace jni_helper {
    inline void throw_runtime_exception(JNIEnv* env, const char* message) {
        jclass exClass = env->FindClass("java/lang/RuntimeException");
        if (exClass != nullptr) {
            env->ThrowNew(exClass, message);
        }
    }
}