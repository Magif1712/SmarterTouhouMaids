#pragma once
#include <cuda_runtime.h>
#include <stdint.h>

void bnn_forward_layer_bridge_storefz(
    long a_prev_pad, long q, long P,
    long l, long r, long b,
    long a_curr, long fz, long n, long n_words,
    long stream
);

void bnn_forward_layer_bridge_nofz(
    long a_prev_pad, long q, long P,
    long l, long r, long b,
    long a_curr, long n, long n_words,
    long stream
);