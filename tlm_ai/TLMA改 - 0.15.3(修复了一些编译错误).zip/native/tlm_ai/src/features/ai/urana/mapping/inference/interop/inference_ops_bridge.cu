#include "inference_ops_bridge.h"
#include "../inference_ops.h"

void bnn_forward_layer_bridge_storefz(
    long a_prev_pad, long q, long P,
    long l, long r, long b,
    long a_curr, long fz, long n, long n_words,
    long stream)
{
    bnn_forward_layer_storefz(
        (const uint32_t*)a_prev_pad, (const uint32_t*)q, (const int32_t*)P,
        (const uint32_t*)l, (const uint32_t*)r, (const uint32_t*)b,
        (uint32_t*)a_curr, (uint32_t*)fz, (size_t)n, (size_t)n_words,
        (cudaStream_t)stream
    );
}

void bnn_forward_layer_bridge_nofz(
    long a_prev_pad, long q, long P,
    long l, long r, long b,
    long a_curr, long n, long n_words,
    long stream)
{
    bnn_forward_layer_nofz(
        (const uint32_t*)a_prev_pad, (const uint32_t*)q, (const int32_t*)P,
        (const uint32_t*)l, (const uint32_t*)r, (const uint32_t*)b,
        (uint32_t*)a_curr, (size_t)n, (size_t)n_words,
        (cudaStream_t)stream
    );
}