#include <jni.h>
#include "core/interop/jni_helper.h"
#include "gradient_ops_bridge.h"

JNIEXPORT void JNICALL JNI_METHOD(features_ai_urana_nn_mapping_training, GradientOpsNative, _1backwardLayer)(
    JNIEnv* env,
    jclass clazz,
    jlong da0_handle,
    jlong da1_handle,
    jlong fz_handle,
    jlong b_handle,
    jlong p_handle,
    jlong q_handle,
    jlong l_handle,
    jlong r_handle,
    jint batch_size,
    jint n_curr,
    jint n_prev,
    jlong stream_handle)
{
    auto* da0 = reinterpret_cast<Vector<int>*>(da0_handle);
    auto* da1 = reinterpret_cast<const Vector<int>*>(da1_handle);
    auto* fz = reinterpret_cast<const Vector<bool>*>(fz_handle);
    auto* b = reinterpret_cast<const Vector<bool>*>(b_handle);
    auto* p = reinterpret_cast<const Vector<int>*>(p_handle);
    auto* q = reinterpret_cast<const Vector<bool>*>(q_handle);
    auto* l = reinterpret_cast<const Vector<bool>*>(l_handle);
    auto* r = reinterpret_cast<const Vector<bool>*>(r_handle);
    backwardLayerBridge(da0, da1, fz, b, p, q, l, r, batch_size, n_curr, n_prev, reinterpret_cast<cudaStream_t>(stream_handle));
}

JNIEXPORT void JNICALL JNI_METHOD(features_ai_urana_nn_mapping_training, GradientOpsNative, _1backwardGradientDescentLayer)(
    JNIEnv* env,
    jclass clazz,
    jlong da0_handle,
    jlong da1_handle,
    jlong a_prev_handle,
    jlong fz_handle,
    jlong b_handle,
    jlong p_handle,
    jlong q_handle,
    jlong l_handle,
    jlong r_handle,
    jint n_curr,
    jint n_prev,
    jlong stream_handle)
{
    auto* da0 = reinterpret_cast<Vector<int>*>(da0_handle);
    auto* da1 = reinterpret_cast<const Vector<int>*>(da1_handle);
    auto* a_prev = reinterpret_cast<const Vector<bool>*>(a_prev_handle);
    auto* fz = reinterpret_cast<const Vector<bool>*>(fz_handle);
    auto* b = reinterpret_cast<Vector<bool>*>(b_handle);
    auto* p = reinterpret_cast<Vector<int>*>(p_handle);
    auto* q = reinterpret_cast<Vector<bool>*>(q_handle);
    auto* l = reinterpret_cast<Vector<bool>*>(l_handle);
    auto* r = reinterpret_cast<Vector<bool>*>(r_handle);
    backwardGradientDescentLayerBridge(da0, da1, a_prev, fz, b, p, q, l, r, n_curr, n_prev, reinterpret_cast<cudaStream_t>(stream_handle));
}