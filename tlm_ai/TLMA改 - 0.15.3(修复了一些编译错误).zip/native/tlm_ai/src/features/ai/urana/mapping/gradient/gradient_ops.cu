#include "gradient_ops.h"
#include <cstdio>


__global__ void gradientSignFlipKernel(
    int *__restrict__ dz,
    const int *__restrict__ da,
    const uint32_t *__restrict__ fz_packed,
    const uint32_t *__restrict__ b_packed,
    size_t n)
{
    // 网格跨步循环：每个线程处理多个元素，提升ILP
    const size_t stride = blockDim.x * gridDim.x;
    for (size_t i = blockIdx.x * blockDim.x + threadIdx.x; i < n; i += stride)
    {
        // 1. 位包索引与偏移计算
        const size_t pack_idx = i >> 5;
        const int bit_offset = i & 31;

        // 2. 只读缓存加载位压缩数据
        const uint32_t fz_word = __ldg(&fz_packed[pack_idx]);
        const uint32_t b_word = __ldg(&b_packed[pack_idx]);

        // 3. 批量计算32位翻转掩码
        const uint32_t flip_mask_word = (~fz_word) & b_word;

        // 4. 核心优化：直接移位生成全0/全1掩码，省去按位与
        int mask = (int)(flip_mask_word << (31 - bit_offset)) >> 31;

        // 5. 只读加载梯度，补码位运算实现条件取反
        const int da_val = __ldg(&da[i]);
        dz[i] = (da_val ^ mask) - mask;
    }
}

/**
 * @brief 梯度符号翻转算子主机端调用入口
 * @param[out] dz        输出梯度，设备端int指针，长度为n
 * @param[in]  da        输入梯度，设备端const int指针，长度为n
 * @param[in]  fz_packed 位压缩的前向符号掩码，设备端const uint32_t指针
 *                       有效长度至少为 ceil(n / 32) 个uint32_t
 * @param[in]  b_packed  位压缩的反向符号掩码，设备端const uint32_t指针
 *                       有效长度至少为 ceil(n / 32) 个uint32_t
 * @param[in]  n         梯度元素总数
 * @param[in]  stream    CUDA流，用于异步执行，默认为空流
 * @return cudaError_t   核函数启动阶段的错误码，执行期错误需同步后检查
 */
cudaError_t gradientSignFlip(
    int *__restrict__ dz,
    const int *__restrict__ da,
    const uint32_t *__restrict__ fz_packed,
    const uint32_t *__restrict__ b_packed,
    size_t n,
    cudaStream_t stream)
{
    // 1. 边界与参数合法性检查
    if (n == 0)
    {
        return cudaSuccess;
    }
    if (dz == nullptr || da == nullptr ||
        fz_packed == nullptr || b_packed == nullptr)
    {
        return cudaErrorInvalidValue;
    }

    // 2. 线程配置：256线程/块为通用最优解
    // 为32的整数倍，匹配warp大小，兼顾占用率与指令级并行(ILP)
    constexpr int block_size = 256;
    const dim3 block_dim(block_size);
    // 向上取整计算网格大小，配合核内网格跨步循环覆盖任意n
    const dim3 grid_dim(static_cast<size_t>(n + block_size - 1) / block_size);

    // 3. 启动核函数，绑定指定CUDA流
    gradientSignFlipKernel<<<grid_dim, block_dim, 0, stream>>>(
        dz, da, fz_packed, b_packed, n);

    // 4. 返回核函数启动阶段的错误（如配置非法、参数不匹配等）
    return cudaGetLastError();
}

// --- Backward Activation ---

__device__ __forceinline__ int32_t get_bit(const uint32_t *__restrict__ bit_array, int index)
{
    return static_cast<int32_t>((bit_array[index >> 5] >> (index & 31)) & 1U);
}

template <int ELEMS_PER_THREAD = 8>
__global__ void backward_activation_final_kernel(
    const int32_t *__restrict__ dz,
    const int32_t *__restrict__ p,
    const uint32_t *__restrict__ q,
    const uint32_t *__restrict__ l,
    const uint32_t *__restrict__ r,
    int32_t *__restrict__ da,
    int batch_size,
    int n_curr,
    int n_prev)
{
    const int tid = blockIdx.x * blockDim.x + threadIdx.x;
    const int total_threads = gridDim.x * blockDim.x;
    const int stride = total_threads * ELEMS_PER_THREAD;
    const int total_out = batch_size * n_prev;
    const int dz_row_stride = n_curr;

    for (int base = tid * ELEMS_PER_THREAD; base < total_out; base += stride)
    {
        const int batch_idx = base / n_prev;
        const int i_start = base % n_prev;
        const int32_t *dz_row = dz + batch_idx * dz_row_stride;

#pragma unroll
        for (int k = 0; k < ELEMS_PER_THREAD; ++k)
        {
            const int i = i_start + k;
            if (i >= n_prev)
                break;

            const int32_t qi = get_bit(q, i);
            const int32_t pi = __ldg(&p[i]);

            const int32_t term1 = qi * __ldg(&dz_row[pi]);

            const int ip1 = i + 1;
            const int32_t valid_p1 = (ip1 >= 0 && ip1 < n_curr) ? 1 : 0;
            const int safe_ip1 = min(max(ip1, 0), n_curr - 1);
            const int32_t li = get_bit(l, safe_ip1);
            const int32_t val_p1 = __ldg(&dz_row[safe_ip1]);
            const int32_t mask2 = (1 - qi) & (pi == ip1) & valid_p1 & li;
            const int32_t term2 = mask2 * val_p1;

            const int im1 = i - 1;
            const int32_t valid_m1 = (im1 >= 0 && im1 < n_curr) ? 1 : 0;
            const int safe_im1 = min(max(im1, 0), n_curr - 1);
            const int32_t ri = get_bit(r, safe_im1);
            const int32_t val_m1 = __ldg(&dz_row[safe_im1]);
            const int32_t mask3 = (1 - qi) & (pi == im1) & valid_m1 & ri;
            const int32_t term3 = mask3 * val_m1;

            da[base + k] = term1 + term2 + term3;
        }
    }
}

/**
 * @brief 激活反向传播核函数的主机调用入口
 * @tparam ELEMS_PER_THREAD 每个线程处理的输出元素数，与核函数保持一致，默认8
 * @param dz    设备指针，上层回传的梯度，形状 [batch_size, n_curr]，行优先存储
 * @param p     设备指针，前层到当前层的索引映射，长度 n_prev
 * @param q     设备指针，直接连接标记比特数组，长度 n_prev
 * @param l     设备指针，左连接标记比特数组，长度 n_curr
 * @param r     设备指针，右连接标记比特数组，长度 n_curr
 * @param da    设备指针，输出的前层梯度，形状 [batch_size, n_prev]，行优先存储
 * @param batch_size 批大小
 * @param n_curr 当前层神经元数量
 * @param n_prev 前层神经元数量
 * @param stream CUDA流，用于异步执行，默认使用默认流
 */
__host__ void backwardActivation(
    const int32_t *__restrict__ dz,
    const int32_t *__restrict__ p,
    const uint32_t *__restrict__ q,
    const uint32_t *__restrict__ l,
    const uint32_t *__restrict__ r,
    int32_t *__restrict__ da,
    int batch_size,
    int n_curr,
    int n_prev,
    cudaStream_t stream)
{
    // 非法输入直接返回，避免无效核函数启动
    if (batch_size <= 0 || n_prev <= 0 || n_curr <= 0)
    {
        return;
    }

    // 线程块大小：256是CUDA全架构通用最优值（8个warp，保证warp对齐与SM资源利用率）
    constexpr int block_size = 256;
    // 总输出元素数量 = 批大小 × 前层神经元数
    const int total_out = batch_size * n_prev;

    // 计算所需总线程数：每个线程处理 ELEMS_PER_THREAD 个元素，向上取整
    constexpr int ELEMS_PER_THREAD = 8;
    const int total_threads_needed = (total_out + ELEMS_PER_THREAD - 1) / ELEMS_PER_THREAD;
    // 计算网格大小：向上取整保证覆盖所有线程
    const int grid_size = (total_threads_needed + block_size - 1) / block_size;

    // 启动模板核函数
    // <<<网格大小, 线程块大小, 共享内存大小, CUDA流>>>
    backward_activation_final_kernel<ELEMS_PER_THREAD>
        <<<grid_size, block_size, 0, stream>>>(
            dz, p, q, l, r, da,
            batch_size, n_curr, n_prev);

    // 检查核函数启动阶段的错误（配置错误、参数非法、资源不足等）
    cudaError_t launch_err = cudaGetLastError();
    if (launch_err != cudaSuccess)
    {
        fprintf(stderr, "[backwardActivation] Kernel launch failed: %s\n",
                cudaGetErrorString(launch_err));
    }
}

cudaError_t backwardLayer(
    int* da0,
    const int* da1,
    const uint32_t* fz_packed,
    const uint32_t* b_packed,
    const int* p,
    const uint32_t* q_packed,
    const uint32_t* l_packed,
    const uint32_t* r_packed,
    int batch_size,
    int n_curr,
    int n_prev,
    cudaStream_t stream
)
{
    // 1. 为中间梯度 dz1 分配临时设备内存
    int* dz1;
    size_t dz1_size = static_cast<size_t>(n_curr) * batch_size * sizeof(int);
    cudaError_t err = cudaMallocAsync(&dz1, dz1_size, stream);
    if (err != cudaSuccess) {
        fprintf(stderr, "[backwardLayer] Failed to allocate memory for dz1: %s\n", cudaGetErrorString(err));
        return err;
    }

    // 2. 调用第一步：计算 dz1
    err = gradientSignFlip(dz1, da1, 
                         fz_packed, 
                         b_packed, 
                         static_cast<size_t>(n_curr) * batch_size, stream);
    if (err != cudaSuccess) {
        fprintf(stderr, "[backwardLayer] gradientSignFlip failed: %s\n", cudaGetErrorString(err));
        cudaFreeAsync(dz1, stream); // 确保在出错时也能释放内存
        return err;
    }

    // 3. 调用第二步：计算 da0
    backwardActivation(dz1,
                       p,
                       q_packed,
                       l_packed,
                       r_packed,
                       da0,
                       batch_size, n_curr, n_prev, stream);

    // 检查 backwardActivation 内部的异步错误
    err = cudaGetLastError();
    if (err != cudaSuccess) {
        fprintf(stderr, "[backwardLayer] backwardActivation failed: %s\n", cudaGetErrorString(err));
        cudaFreeAsync(dz1, stream);
        return err;
    }
    
    // 4. 释放临时内存
    cudaFreeAsync(dz1, stream);

    return cudaSuccess;
}

// --- In-place Gradient Descent ---

namespace detail {

__device__ __forceinline__ int get_bit_val(const uint32_t *__restrict__ data, int index)
{
    return (data[index >> 5] >> (index & 31)) & 1;
}

__device__ __forceinline__ void set_bit_val(uint32_t *__restrict__ data, int index, int val)
{
    uint32_t mask = 1U << (index & 31);
    if (val)
        atomicOr(&data[index >> 5], mask);
    else
        atomicAnd(&data[index >> 5], ~mask);
}

template <int ELEMS_PER_THREAD>
__global__ void backward_activation_and_gradient_descent_kernel(
    const int32_t *__restrict__ dz,
    const uint32_t *__restrict__ a_prev,
    int32_t *__restrict__ p,
    uint32_t *__restrict__ q_packed,
    uint32_t *__restrict__ l_packed,
    uint32_t *__restrict__ r_packed,
    uint32_t *__restrict__ b_packed,
    int32_t *__restrict__ da,
    int n_curr,
    int n_prev)
{
    const int tid = blockIdx.x * blockDim.x + threadIdx.x;
    const int total_threads = gridDim.x * blockDim.x;
    const int stride = total_threads * ELEMS_PER_THREAD;
    const int total = max(n_curr, n_prev);

    for (int base = tid * ELEMS_PER_THREAD; base < total; base += stride)
    {
#pragma unroll
        for (int k = 0; k < ELEMS_PER_THREAD; ++k)
        {
            const int idx = base + k;
            if (idx >= total)
                break;

            if (idx < n_curr)
            {
                int b_val = get_bit_val(b_packed, idx);
                int new_b = b_val + dz[idx];
                if (new_b < 0) new_b = 0;
                else if (new_b > 1) new_b = 1;
                set_bit_val(b_packed, idx, new_b);
            }

            if (idx < n_prev)
            {
                const int i = idx;
                const int32_t ai = get_bit_val(a_prev, i);
                const int32_t pi = p[i];
                const int32_t qi = get_bit_val(q_packed, i);
                const int safe_pi = min(max(pi, 0), n_curr - 1);
                const int32_t dz_pi = dz[safe_pi];
                int32_t da_i = 0;

                if (qi != 0)
                {
                    da_i += dz_pi;
                }
                else
                {
                    const int ip1 = i + 1;
                    if (ip1 < n_curr && pi == ip1)
                    {
                        const int32_t li = get_bit_val(l_packed, ip1);
                        const int32_t dz_ip1 = dz[ip1];
                        da_i += dz_ip1 * li;
                        int new_l = li - dz_ip1 * ai;
                        if (new_l < 0) new_l = 0; else if (new_l > 1) new_l = 1;
                        set_bit_val(l_packed, ip1, new_l);
                    }
                    const int im1 = i - 1;
                    if (im1 >= 0 && pi == im1)
                    {
                        const int32_t ri = get_bit_val(r_packed, im1);
                        const int32_t dz_im1 = dz[im1];
                        da_i += dz_im1 * ri;
                        int new_r = ri - dz_im1 * ai;
                        if (new_r < 0) new_r = 0; else if (new_r > 1) new_r = 1;
                        set_bit_val(r_packed, im1, new_r);
                    }
                }
                da[i] = da_i;
                int new_q = qi - dz_pi * ai;
                if (new_q < 0) new_q = 0; else if (new_q > 1) new_q = 1;
                set_bit_val(q_packed, i, new_q);
                int new_p = pi + dz_pi * ai * qi;
                if (new_p < 0) new_p = 0; else if (new_p >= n_curr) new_p = n_curr - 1;
                p[i] = new_p;
            }
        }
    }
}

} // namespace detail

__host__ cudaError_t backwardActivationAndGradientDescent(
    int32_t *__restrict__ dz,
    const uint32_t *__restrict__ a_prev,
    int32_t *__restrict__ p,
    uint32_t *__restrict__ q_packed,
    uint32_t *__restrict__ l_packed,
    uint32_t *__restrict__ r_packed,
    uint32_t *__restrict__ b_packed,
    int32_t *__restrict__ da,
    int n_curr,
    int n_prev,
    cudaStream_t stream)
{
    constexpr int ELEMS_PER_THREAD = 8;
    constexpr int block_size = 256;
    const int total = std::max(n_curr, n_prev);
    const int total_threads_needed = (total + ELEMS_PER_THREAD - 1) / ELEMS_PER_THREAD;
    const int grid_size = (total_threads_needed + block_size - 1) / block_size;

    detail::backward_activation_and_gradient_descent_kernel<ELEMS_PER_THREAD>
        <<<grid_size, block_size, 0, stream>>>(
            dz, a_prev, p, q_packed, l_packed, r_packed, b_packed, da,
            n_curr, n_prev);

    cudaError_t err = cudaGetLastError();
    if (err != cudaSuccess) {
        fprintf(stderr, "[GD-Activation] Kernel launch failed: %s\n", cudaGetErrorString(err));
    }
    return err;
}

__host__ cudaError_t backwardGradientDescentLayer(
    int32_t *__restrict__ da0,
    const int32_t *__restrict__ da1,
    const uint32_t *__restrict__ a_prev,
    const uint32_t *__restrict__ fz_packed,
    uint32_t *__restrict__ b_packed,
    int32_t *__restrict__ p,
    uint32_t *__restrict__ q_packed,
    uint32_t *__restrict__ l_packed,
    uint32_t *__restrict__ r_packed,
    int n_curr,
    int n_prev,
    cudaStream_t stream)
{
    if (n_curr <= 0 || n_prev <= 0) return cudaSuccess;

    int32_t *dz;
    size_t dz_size = static_cast<size_t>(n_curr) * sizeof(int32_t);
    cudaError_t err = cudaMallocAsync(&dz, dz_size, stream);
    if (err != cudaSuccess) {
        fprintf(stderr, "[GDLayer] Failed to allocate memory for dz: %s\n", cudaGetErrorString(err));
        return err;
    }

    err = gradientSignFlip(dz, da1, fz_packed, b_packed, static_cast<size_t>(n_curr), stream);
    if (err != cudaSuccess) {
        fprintf(stderr, "[GDLayer] gradientSignFlip failed: %s\n", cudaGetErrorString(err));
        cudaFreeAsync(dz, stream);
        return err;
    }
    
    err = backwardActivationAndGradientDescent(
        dz, a_prev, p, q_packed, l_packed, r_packed, b_packed, da0,
        n_curr, n_prev, stream
    );

    cudaFreeAsync(dz, stream);
    return err;
}