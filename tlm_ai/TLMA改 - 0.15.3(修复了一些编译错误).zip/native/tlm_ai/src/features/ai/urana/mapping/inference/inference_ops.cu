#include <cuda_runtime.h>
#include <cstdio>  // 提供 fprintf, stderr
#include <cstdlib> // 提供 abort
#include <stdint.h>

constexpr uint32_t BITS = 32;
constexpr uint32_t LOG_BITS = 5;
constexpr int BLOCK = 256;

__global__ void __launch_bounds__(BLOCK, 2)
    bnn_push_p(
        const uint32_t *__restrict__ a_prev,
        const uint32_t *__restrict__ q,
        uint32_t *__restrict__ a_curr,
        const int32_t *__restrict__ P,
        size_t n)
{
    size_t i = (size_t)blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n)
        return;

    size_t wi = i >> LOG_BITS;
    uint32_t bit = 1u << (i & (BITS - 1));

    if ((__ldg(&a_prev[wi]) & __ldg(&q[wi]) & bit) == 0)
        return;

    int32_t j = __ldg(&P[i]);
    if (j < 0)
        return;

    atomicOr(&a_curr[j >> LOG_BITS], 1u << (j & (BITS - 1)));
}

// 模板 bool 特化（推荐）
template <bool StoreFZ>
__global__ void __launch_bounds__(BLOCK, 2)
    bnn_pull_lr(
        const uint32_t *__restrict__ a_prev_pad,
        uint32_t *__restrict__ a_curr,
        uint32_t *__restrict__ fz,
        const uint32_t *__restrict__ l,
        const uint32_t *__restrict__ r,
        const uint32_t *__restrict__ b,
        size_t n_words)
{
    int64_t w = (int64_t)blockIdx.x * blockDim.x + threadIdx.x;
    if (w < 0 || w >= (int64_t)n_words)
        return;

    uint32_t prev = __ldg(&a_prev_pad[w]);
    uint32_t left = __ldg(&a_prev_pad[w - 1]);
    uint32_t right = __ldg(&a_prev_pad[w + 1]);
    uint32_t out = a_curr[w];

    out |= __funnelshift_r(left, prev, 31) & __ldg(&l[w]);
    out |= __funnelshift_r(prev, right, 1) & __ldg(&r[w]);

    // 不要删掉constexpr，constexpr是编译时常量，允许编译器在编译阶段优化代码路径，删了就要在运行时分支了，对挺大地降低性能的
    if constexpr (StoreFZ)
    {
        __stcg(&fz[w], out);
    }

    out ^= __ldg(&b[w]);
    a_curr[w] = out;
}

extern "C" void bnn_forward_layer_storefz(
    const uint32_t *a_prev_pad, const uint32_t *q, const int32_t *P,
    const uint32_t *l, const uint32_t *r, const uint32_t *b,
    uint32_t *a_curr, uint32_t *fz, size_t n, size_t n_words,
    cudaStream_t stream)
{
    // 强制崩溃，防止空指针传入
    if (fz == nullptr)
    {
        fprintf(stderr, "ERROR: fz is null in bnn_forward_layer_store_fz\n");
        abort(); // 立即崩溃
    }

    cudaMemsetAsync(a_curr, 0, n_words * sizeof(uint32_t), stream);

    dim3 block(BLOCK);
    dim3 grid_push((unsigned int)((n + BLOCK - 1) / BLOCK));
    dim3 grid_pull((unsigned int)((n_words + BLOCK - 1) / BLOCK));

    bnn_push_p<<<grid_push, block, 0, stream>>>(a_prev_pad, q, a_curr, P, n);
    bnn_pull_lr<true><<<grid_pull, block, 0, stream>>>(a_prev_pad, a_curr, fz, l, r, b, n_words);
}

extern "C" void bnn_forward_layer_nofz(
    const uint32_t *a_prev_pad, const uint32_t *q, const int32_t *P,
    const uint32_t *l, const uint32_t *r, const uint32_t *b,
    uint32_t *a_curr, size_t n, size_t n_words,
    cudaStream_t stream)
{
    cudaMemsetAsync(a_curr, 0, n_words * sizeof(uint32_t), stream);

    dim3 block(BLOCK);
    dim3 grid_push((unsigned int)((n + BLOCK - 1) / BLOCK));
    dim3 grid_pull((unsigned int)((n_words + BLOCK - 1) / BLOCK));

    bnn_push_p<<<grid_push, block, 0, stream>>>(a_prev_pad, q, a_curr, P, n);
    bnn_pull_lr<false><<<grid_pull, block, 0, stream>>>(a_prev_pad, a_curr, nullptr, l, r, b, n_words);
}