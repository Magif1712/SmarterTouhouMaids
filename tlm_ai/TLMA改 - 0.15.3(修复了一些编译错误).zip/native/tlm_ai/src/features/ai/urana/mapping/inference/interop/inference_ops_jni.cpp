#include <jni.h>
#include "core/interop/jni_helper.h"
#include "inference_ops_bridge.h"

#ifdef __cplusplus
extern "C" {
#endif

JNIEXPORT void JNICALL JNI_METHOD(features_ai_urana_mapping_inference, InferenceOpsNative, _1bnnForwardLayerStoreFz)(
    JNIEnv *env,
    jobject thiz,
    jlong a_prev_pad, jlong q, jlong P,
    jlong l, jlong r, jlong b,
    jlong a_curr, jlong fz, jlong n, jlong n_words,
    jlong stream)
{
    bnn_forward_layer_bridge_storefz(
        a_prev_pad, q, P,
        l, r, b,
        a_curr, fz, n, n_words,
        stream
    );
}

JNIEXPORT void JNICALL JNI_METHOD(features_ai_urana_mapping_inference, InferenceOpsNative, _1bnnForwardLayerNoFz)(
    JNIEnv *env,
    jobject thiz,
    jlong a_prev_pad, jlong q, jlong P,
    jlong l, jlong r, jlong b,
    jlong a_curr, jlong n, jlong n_words,
    jlong stream)
{
    bnn_forward_layer_bridge_nofz(
        a_prev_pad, q, P,
        l, r, b,
        a_curr, n, n_words,
        stream
    );
}

#ifdef __cplusplus
}
#endif