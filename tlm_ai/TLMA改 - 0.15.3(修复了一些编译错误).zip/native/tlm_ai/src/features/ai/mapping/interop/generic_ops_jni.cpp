#include <jni.h>
#include <exception>
#include "../../../../core/interop/jni_helper.h"
#include "generic_ops_bridge.h"

#ifdef __cplusplus
extern "C" {
#endif

JNIEXPORT void JNICALL JNI_METHOD(features_ai_mapping, GenericOpsNative, _1negateAndBinarize)(
    JNIEnv* env,
    jclass clazz,
    jlong dst_handle,
    jlong src_handle)
{
    auto* dst = reinterpret_cast<Vector<bool>*>(dst_handle);
    auto* src = reinterpret_cast<const Vector<int>*>(src_handle);
    
    try {
        negateAndBinarizeBridge(dst, src);
    } catch (const std::exception& e) {
        jni_helper::throw_runtime_exception(env, e.what());
    }
}

JNIEXPORT void JNICALL JNI_METHOD(features_ai_mapping, GenericOpsNative, _1negateAndBinarizeRegion)(
    JNIEnv* env,
    jclass clazz,
    jlong dst_handle,
    jlong dst_offset,
    jlong src_handle,
    jlong src_offset,
    jlong n)
{
    auto* dst = reinterpret_cast<Vector<bool>*>(dst_handle);
    auto* src = reinterpret_cast<const Vector<int>*>(src_handle);
    
    try {
        negateAndBinarizeRegionBridge(
            dst, 
            static_cast<size_t>(dst_offset), 
            src, 
            static_cast<size_t>(src_offset), 
            static_cast<size_t>(n)
        );
    } catch (const std::exception& e) {
        jni_helper::throw_runtime_exception(env, e.what());
    }
}

#ifdef __cplusplus
}
#endif