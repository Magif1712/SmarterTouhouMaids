package com.github.magif1712.smarter_touhou_maids.features.ai.urana.process.introspective.context;

import com.github.magif1712.smarter_touhou_maids.features.ai.urana.nn.containers.NetworkData;
import com.github.magif1712.smarter_touhou_maids.features.ai.urana.process.common.UranaConstants;
import com.github.magif1712.smarter_touhou_maids.features.ai.urana.process.common.inference.AbstractInferenceCell;

/**
 * 流程七：内省者推理。
 * N=1 单步，G=FUTURE_1。
 */
public class IntrospectiveInference extends AbstractInferenceCell {
    private static final int CHAIN_LENGTH = 1;

    public IntrospectiveInference(NetworkData networkData) {
        super(networkData, CHAIN_LENGTH, UranaConstants.G_FUTURE_1);
    }
}