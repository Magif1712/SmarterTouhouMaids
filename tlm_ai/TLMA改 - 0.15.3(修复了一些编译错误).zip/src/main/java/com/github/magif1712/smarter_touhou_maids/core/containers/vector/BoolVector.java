package com.github.magif1712.smarter_touhou_maids.core.containers.vector;

import com.github.magif1712.smarter_touhou_maids.core.containers.domain.Span;
import java.util.Objects;

/**
 * 布尔向量 (BoolVector)，底层使用位压缩存储。
 */
public final class BoolVector extends VectorBase {
    public BoolVector() {
        super();
    }

    public BoolVector(int size) {
        super();
        allocate(size);
    }

    private BoolVector(long handle, int size) {
        super(handle, size);
    }

    @Override
    public void allocate(int size) {
        validateSize(size);
        long newHandle = VectorNative._createVectorBool();
        VectorNative._allocateBool(newHandle, size);
        setHandleAndSize(newHandle, size);
    }



    public void copyFromHost(int[] bitPackedData, int wordCount) {
        Objects.requireNonNull(bitPackedData);
        validateCount(wordCount, bitPackedData.length);
        VectorNative._copyFromHostBool(requireHandle(), bitPackedData, wordCount);
    }

    public void copyToHost(int[] bitPackedData) {
        copyToHost(bitPackedData, bitPackedData.length);
    }

    public void copyToHost(int[] bitPackedData, int wordCount) {
        Objects.requireNonNull(bitPackedData);
        validateCount(wordCount, bitPackedData.length);
        VectorNative._copyToHostBool(requireHandle(), bitPackedData, wordCount);
    }

    @Override
    public void save(String path) {
        VectorNative._saveBool(requireHandle(), Objects.requireNonNull(path));
    }

    public static BoolVector loadFromFile(String path) {
        Objects.requireNonNull(path);
        long h = VectorNative._createVectorBool();
        if (h == 0) throw new RuntimeException("Failed to create native handle for loading.");

        VectorNative._loadFromFileBool(h, path);
        int size = VectorNative._getSizeBool(h);
        return new BoolVector(h, size);
    }

    public void copyFromBoolVector(Span destSpan, BoolVector source, Span srcSpan) {
        Objects.requireNonNull(destSpan);
        Objects.requireNonNull(source);
        Objects.requireNonNull(srcSpan);
        long destOffset = destSpan.getOffset();
        long srcOffset = srcSpan.getOffset();
        long count = srcSpan.getLength();

        if (count == 0) return;
        if (destOffset + count > this.size()) throw new IllegalArgumentException("Destination out of bounds.");
        if (srcOffset + count > source.size()) throw new IllegalArgumentException("Source out of bounds.");

        VectorNative._copyRegionFromBool(requireHandle(), destOffset, source.requireHandle(), srcOffset, count);
    }

    @Override
    public void copyRegionFrom(VectorBase source, Span srcSpan, Span destSpan) {
        if (!(source instanceof BoolVector)) {
            throw new IllegalArgumentException("Source must be a BoolVector.");
        }
        this.copyFromBoolVector(destSpan, (BoolVector) source, srcSpan);
    }

    public void setRegion(Span destSpan, BoolVector source) {
        Objects.requireNonNull(destSpan);
        Objects.requireNonNull(source);
        if (source.size() == 0) return;

        long destOffset = destSpan.getOffset();
        long count = source.size();

        if (destSpan.getLength() != count) {
            throw new IllegalArgumentException(String.format(
                "Destination span length (%d) must match source vector size (%d).",
                destSpan.getLength(), count));
        }
        if (destOffset + count > this.size()) throw new IllegalArgumentException("Destination out of bounds.");

        VectorNative._setRegionBool(requireHandle(), destOffset, source.requireHandle());
    }

    public void copyRegionFromHost(Span destSpan, boolean[] src_data) {
        Objects.requireNonNull(destSpan);
        Objects.requireNonNull(src_data);

        int num_bits = destSpan.getLength();
        if (num_bits == 0) return;

        long destOffset = destSpan.getOffset();
        if (destOffset + num_bits > this.size()) {
            throw new IllegalArgumentException("Destination span is out of bounds for this vector.");
        }
        if (num_bits > src_data.length) {
            throw new IllegalArgumentException("Source data array is too small for the destination span.");
        }

        VectorNative._copyRegionFromHostBool(requireHandle(), destOffset, src_data, num_bits);
    }

    @Override
    protected void releaseResource() {
        VectorNative._deleteVectorBool(handle);
    }
}