package com.github.magif1712.smarter_touhou_maids.features.ai.urana.process.prospective.context;

import com.github.magif1712.smarter_touhou_maids.core.containers.vector.BoolVector;
import com.github.magif1712.smarter_touhou_maids.core.containers.vector.IntVector;
import com.github.magif1712.smarter_touhou_maids.features.ai.urana.nn.containers.NetworkData;
import com.github.magif1712.smarter_touhou_maids.features.ai.urana.process.common.UranaConstants;
import com.github.magif1712.smarter_touhou_maids.features.ai.urana.process.common.grad.AbstractGradCell;
import com.github.magif1712.smarter_touhou_maids.features.ai.urana.process.common.grad.ChainStepSample;
import com.github.magif1712.smarter_touhou_maids.features.ai.urana.process.prospective.ProspectiveAnchor;

import java.util.ArrayList;
import java.util.List;

/**
 * 流程三：拟合过去1刻（两阶段训练）。
 * 为 ProspectiveAnchor 服务，用过去的实际数据来校准自己。
 * 继承 AbstractGradCell，单步链条，内部闭环跨轮次梯度。
 */
public class ProspectiveGradCell extends AbstractGradCell {
    private static final int CHAIN_LENGTH = 1;

    public ProspectiveGradCell(NetworkData networkData) {
        super(networkData, CHAIN_LENGTH, UranaConstants.G_PAST_1);
    }

    public void execute(ProspectiveAnchor anchor, BoolVector dt) {
        // 填充预分配池，零临时对象
        samplePool[0].set(
            anchor.getFeeling().getPrecipitate(),
            anchor.getBehavior().getPrecipitate()
        );
        super.executeWithClosedLoop(
            anchor.getFeeling().getSuspension(), dt);
    }
}