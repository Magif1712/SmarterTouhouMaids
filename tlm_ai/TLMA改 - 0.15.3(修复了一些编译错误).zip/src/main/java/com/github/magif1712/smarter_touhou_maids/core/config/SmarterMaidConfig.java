package com.github.magif1712.smarter_touhou_maids.core.config;

import net.minecraftforge.common.ForgeConfigSpec;
import org.apache.commons.lang3.tuple.Pair;

public class SmarterMaidConfig {
    public static final ForgeConfigSpec CLIENT_SPEC;
    public static final Client CLIENT;

    static {
        final Pair<Client, ForgeConfigSpec> specPair = new ForgeConfigSpec.Builder().configure(Client::new);
        CLIENT_SPEC = specPair.getRight();
        CLIENT = specPair.getLeft();
    }

    public static class Client {
        public final ForgeConfigSpec.BooleanValue possessEnabled;
        public final ForgeConfigSpec.IntValue neuronCount;

        Client(ForgeConfigSpec.Builder builder) {
            builder.push("general");

            possessEnabled = builder
                    .comment("Enable 'Possess and become smarter' feature.")
                    .define("possessEnabled", true);

            neuronCount = builder
                    .comment("Number of auxiliary neurons per layer.")
                    .defineInRange("neuronCount", 128, 1, 1024);

            builder.pop();
        }
    }
}