package com.github.magif1712.smarter_touhou_maids.features.ai.urana.nn.containers.io;

import com.github.magif1712.smarter_touhou_maids.core.containers.vector.IntVector;
import com.github.magif1712.smarter_touhou_maids.features.ai.urana.nn.containers.io.gradient.InputLayerGradient;
import com.github.magif1712.smarter_touhou_maids.features.ai.urana.nn.containers.io.gradient.OutputLayerGradient;
import com.github.magif1712.smarter_touhou_maids.features.ai.urana.semantics.containers.io.InputVectorDomain;
import com.github.magif1712.smarter_touhou_maids.features.ai.urana.semantics.containers.io.OutputVectorDomain;

/**
 * 一个容器类，用于封装和管理输入层与输出层的梯度。
 * <p>
 * 这个类的设计模式与 {@link IO} 类似，旨在将反向传播中概念上关联的数据（输入层梯度和输出层梯度）
 * 捆绑成一个逻辑单元，以简化接口和统一生命周期管理。
 */
public class IOLayerGradients implements AutoCloseable {

    private final InputLayerGradient inputLayerGradient;
    private final OutputLayerGradient outputLayerGradient;

    /**
     * 构造一个新的 IOLayerGradients 实例。
     * 它会自动根据 InputVectorView 和 OutputVectorView 的总长度来初始化内部的梯度向量。
     */
    public IOLayerGradients() {
        this.inputLayerGradient = new InputLayerGradient(new IntVector(InputVectorDomain.TOTAL_LENGTH));
        this.outputLayerGradient = new OutputLayerGradient(new IntVector(OutputVectorDomain.TOTAL_LENGTH));
    }

    public InputLayerGradient getInputLayerGradient() {
        return inputLayerGradient;
    }

    public OutputLayerGradient getOutputLayerGradient() {
        return outputLayerGradient;
    }

    @Override
    public void close() throws Exception {
        if (inputLayerGradient != null) {
            inputLayerGradient.close();
        }
        if (outputLayerGradient != null) {
            outputLayerGradient.close();
        }
    }
}