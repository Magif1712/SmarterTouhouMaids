package com.github.magif1712.smarter_touhou_maids.features.client.screen;

import com.github.magif1712.smarter_touhou_maids.features.client.NativeLibLoader;
import com.github.magif1712.smarter_touhou_maids.core.config.SmarterMaidConfig;
import com.github.magif1712.smarter_touhou_maids.features.maid.menu.AutoTaskConfigMenu;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Inventory;
import org.lwjgl.glfw.GLFW;

public class AutoTaskConfigScreen extends AbstractContainerScreen<AutoTaskConfigMenu> {
    private static final int BG_COLOR = 0xCC000000;
    private static final int GUI_WIDTH = 380;
    private static final int GUI_HEIGHT = 280;
    private EditBox neuronCountBox;

    public AutoTaskConfigScreen(AutoTaskConfigMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = GUI_WIDTH;
        this.imageHeight = GUI_HEIGHT;
    }

    @Override
    protected void init() {
        super.init();
        int startX = (this.width - this.imageWidth) / 2;
        int startY = (this.height - this.imageHeight) / 2;

        Tooltip autoTooltip = Tooltip.create(Component.literal("是否牺牲自己的玩家实体让女仆变聪明"));
        CycleButton autoButton = CycleButton.onOffBuilder(SmarterMaidConfig.CLIENT.possessEnabled.get())
                .create(startX + 10, startY + 25, 150, 20, Component.literal("附身并变聪明"),
                        (button, value) -> {
                            SmarterMaidConfig.CLIENT.possessEnabled.set(value);
                            if (value) {
                                Minecraft.getInstance().player.sendSystemMessage(Component.literal("状态：开启附身"));
                            } else {
                                Minecraft.getInstance().player.sendSystemMessage(Component.literal("状态：关闭附身"));
                            }
                        });
        autoButton.setTooltip(autoTooltip);
        this.addRenderableWidget(autoButton);

        this.neuronCountBox = new EditBox(this.font, startX + 10, startY + 70, 150, 20, Component.literal(""));
        this.neuronCountBox.setValue(String.valueOf(SmarterMaidConfig.CLIENT.neuronCount.get()));
        this.neuronCountBox.setResponder(text -> {
            String trimmed = text.trim();
            if (trimmed.isEmpty()) {
                return;
            }

            try {
                int value = Mth.clamp(Integer.parseInt(trimmed), 1, 1024);
                SmarterMaidConfig.CLIENT.neuronCount.set(value);
            } catch (NumberFormatException ignored) {
            }
        });
        this.addRenderableWidget(this.neuronCountBox);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (this.neuronCountBox != null && this.neuronCountBox.isFocused() && (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER)) {
            this.commitNeuronCount();
            this.setFocused(null);
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void removed() {
        this.commitNeuronCount();
        super.removed();
    }

    @Override
    protected void renderBg(GuiGraphics guiGraphics, float partialTick, int mouseX, int mouseY) {
        int startX = (this.width - this.imageWidth) / 2;
        int startY = (this.height - this.imageHeight) / 2;
        guiGraphics.fill(startX, startY, startX + this.imageWidth, startY + this.imageHeight, BG_COLOR);
    }

    @Override
    protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
        guiGraphics.drawString(this.font, this.title, this.titleLabelX, this.titleLabelY, 0x39c5bb, true);
        guiGraphics.drawString(this.font, "每层辅助神经元数量", 10, 55, 0x39c5bb, false);
    }

    private void commitNeuronCount() {
        if (this.neuronCountBox == null) {
            return;
        }

        String trimmed = this.neuronCountBox.getValue().trim();
        if (trimmed.isEmpty()) {
            return;
        }

        try {
            int value = Mth.clamp(Integer.parseInt(trimmed), 1, 1024);
            String normalized = String.valueOf(value);
            if (!normalized.equals(this.neuronCountBox.getValue())) {
                this.neuronCountBox.setValue(normalized);
            }
            SmarterMaidConfig.CLIENT.neuronCount.set(value);
//            int capacity = NativeLibLoader.syncNeuronCount(value);
            Minecraft minecraft = Minecraft.getInstance();
//            if (minecraft.player != null) {
//                minecraft.player.sendSystemMessage(Component.literal("GPU 自动任务缓冲区容量：" + capacity));
//            }
        } catch (RuntimeException exception) {
            Minecraft minecraft = Minecraft.getInstance();
            if (minecraft.player != null) {
                minecraft.player.sendSystemMessage(Component.literal("GPU 自动任务缓冲区初始化失败：" + exception.getMessage()));
            }
        }
    }
}