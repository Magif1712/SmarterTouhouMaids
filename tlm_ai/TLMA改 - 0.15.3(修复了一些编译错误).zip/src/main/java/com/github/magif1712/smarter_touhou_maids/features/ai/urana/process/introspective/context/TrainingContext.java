
package com.github.magif1712.smarter_touhou_maids.features.ai.urana.process.introspective.context;

import com.github.magif1712.smarter_touhou_maids.core.containers.vector.BoolVector;
import com.github.magif1712.smarter_touhou_maids.core.containers.vector.IntVector;
import com.github.magif1712.smarter_touhou_maids.features.ai.urana.nn.containers.NetworkData;
import com.github.magif1712.smarter_touhou_maids.features.ai.urana.process.common.UranaConstants;
import com.github.magif1712.smarter_touhou_maids.features.ai.urana.process.common.grad.AbstractGradCell;
import com.github.magif1712.smarter_touhou_maids.features.ai.urana.process.common.grad.ChainStepSample;
import com.github.magif1712.smarter_touhou_maids.features.ai.urana.process.introspective.IntrospectiveAnchor;

import java.util.ArrayList;
import java.util.List;

/**
 * 流程八：内省训练上下文。
 * 继承 AbstractGradCell，两步链条（展望→审视），内部闭环跨轮次梯度。
 */
public class TrainingContext extends AbstractGradCell {
    private static final boolean[][] G_PER_STEP = {
        UranaConstants.G_FUTURE_N,
        UranaConstants.G_PAST_N
    };
    private static final int CHAIN_LENGTH = 2;

    public TrainingContext(NetworkData networkData) {
        super(networkData, CHAIN_LENGTH, G_PER_STEP);
    }

    /**
     * 全自动执行。外界不需要知道 ∇C 的存在。
     */
    public void execute(IntrospectiveAnchor anchor, BoolVector dt) {
        // 填充预分配池
        samplePool[0].set(
            anchor.getFeeling().getSuspension(),
            anchor.getBehavior().getSuspension()
        );
        samplePool[1].set(
            anchor.getFeeling().getPrecipitate(),
            anchor.getBehavior().getPrecipitate()
        );

        super.executeWithClosedLoop(
            anchor.getFeeling().getPrecipitate(), dt);
    }
}