package com.github.magif1712.smarter_touhou_maids.features.ai.mapping;

import com.github.magif1712.smarter_touhou_maids.features.client.NativeLibLoader;

class GenericOpsNative {
    static {
        NativeLibLoader.ensureLoaded();
    }

    /**
     * Native method to perform negate and binarize operation on vectors.
     * It takes the handles (pointers) to the native vectors.
     *
     * @param dstVectorBoolHandle The handle to the destination BoolVector.
     * @param srcVectorIntHandle  The handle to the source IntVector.
     */
    public static native void _negateAndBinarize(long dstVectorBoolHandle, long srcVectorIntHandle);

    /**
     * Native method to perform negate and binarize operation on a region of vectors.
     *
     * @param dst_handle   The handle to the destination BoolVector.
     * @param dst_offset   The starting bit offset in the destination vector.
     * @param src_handle   The handle to the source IntVector.
     * @param src_offset   The starting element offset in the source vector.
     * @param n            The number of elements to process.
     */
    public static native void _negateAndBinarizeRegion(long dst_handle, long dst_offset, long src_handle, long src_offset, long n);
}