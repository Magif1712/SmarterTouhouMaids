package com.github.magif1712.smarter_touhou_maids.core.containers.vector;

/**
 * JNI 桥接类的 Java 声明，用于 Vector (向量) 的原生操作。
 */
public class VectorNative {
    static {
        System.loadLibrary("tlm_ai");
    }

    // ====================================================================
    // Vector<bool> (位压缩) 原生方法
    // ====================================================================
    public static native long _createVectorBool();
    public static native void _allocateBool(long handle, int size);
    public static native void _deleteVectorBool(long handle);
    public static native void _copyFromHostBool(long handle, int[] data, int wordCount);
    public static native void _copyToHostBool(long handle, int[] data, int wordCount);
    public static native void _saveBool(long handle, String filename);
    public static native void _loadFromFileBool(long handle, String filename);
    public static native int _getSizeBool(long handle);
    public static native void _setRegionBool(long dstHandle, long destOffset, long srcHandle);
    public static native void _copyRegionFromBool(long dstHandle, long dstOffset, long srcHandle, long srcOffset, long numBits);
    public static native void _copyRegionFromHostBool(long handle, long destOffset, boolean[] srcData, int numBits);

    // ====================================================================
    // Vector<int> 原生方法
    // ====================================================================
    public static native long _createVectorInt();
    public static native void _allocateInt(long handle, int size);
    public static native void _deleteVectorInt(long handle);
    public static native void _copyFromHostInt(long handle, int[] data, int count);
    public static native void _copyToHostInt(long handle, int[] data, int count);
    public static native void _saveInt(long handle, String filename);
    public static native void _loadFromFileInt(long handle, String filename);
    public static native int _getSizeInt(long handle);
    public static native void _copyRegionFromInt(long dstHandle, long dstOffset, long srcHandle, long srcOffset, long count);
    public static native void _setRegionInt(long dstHandle, long destOffset, long srcHandle);
    public static native void _copyRegionFromHostInt(long dstHandle, long dstOffset, int[] srcHostData, long count);

    // ====================================================================
    // 向量算法原生方法
    // ====================================================================
    public static native void _scatterBits(long srcHandle, long dstHandle, long pHandle);
    public static native void _xorBool(long dstHandle, long srcHandle);
    public static native void _subtractBool(long aHandle, long bHandle, long bitOffset, long cHandle, long cIntOffset, long bitLength);
    public static native void _multiplyByScalarInt(long handle, int scalar, long offset, long length);
}