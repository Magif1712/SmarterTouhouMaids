package com.github.magif1712.smarter_touhou_maids.core.containers.vector;

/**
 * 向量 (Vector) 的通用接口，定义了跨类型向量的基本行为。
 * 符合“真”：仅落地实现最终功能所需的模式。
 */
public interface IVector extends AutoCloseable {
    /**
     * 返回向量的逻辑元素数量。
     */
    int size();

    /**
     * 返回底层原生资源的句柄。
     */
    long handle();

    /**
     * 检查向量是否已初始化并持有原生资源。
     */
    boolean isInitialized();

    /**
     * 为向量分配指定大小的显存空间。
     */
    void allocate(int size);

    /**
     * 将向量序列化到磁盘。
     */
    void save(String path);

    /**
     * 释放向量持有的原生资源。
     */
    @Override
    void close();
}
