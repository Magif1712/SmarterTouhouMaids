
package com.github.magif1712.smarter_touhou_maids.features.ai.urana.process;

import com.github.magif1712.smarter_touhou_maids.core.containers.domain.Span;
import com.github.magif1712.smarter_touhou_maids.core.containers.vector.BoolVector;
import com.github.magif1712.smarter_touhou_maids.features.ai.urana.nn.containers.io.value.OutputVector;
import com.github.magif1712.smarter_touhou_maids.features.ai.urana.process.common.grad.ChainStepSample;
import com.github.magif1712.smarter_touhou_maids.features.ai.urana.process.prospective.ProspectiveAnchor;
import com.github.magif1712.smarter_touhou_maids.features.ai.urana.process.introspective.context.IntrospectiveInference;

import com.github.magif1712.smarter_touhou_maids.features.ai.urana.process.prospective.context.ProspectiveGradCell;
import com.github.magif1712.smarter_touhou_maids.features.ai.urana.process.prospective.context.ProspectiveInference;
import com.github.magif1712.smarter_touhou_maids.features.ai.urana.process.retrospective.RetrospectiveAnchor;
import com.github.magif1712.smarter_touhou_maids.features.ai.urana.process.retrospective.context.RetrospectiveGradCell;
import com.github.magif1712.smarter_touhou_maids.features.ai.urana.process.introspective.IntrospectiveAnchor;
import com.github.magif1712.smarter_touhou_maids.features.ai.urana.nn.containers.NetworkData;
import com.github.magif1712.smarter_touhou_maids.features.ai.urana.process.introspective.context.TrainingContext;
import com.github.magif1712.smarter_touhou_maids.features.ai.urana.process.retrospective.context.RetrospectiveInference;
import com.github.magif1712.smarter_touhou_maids.features.ai.urana.semantics.containers.io.OutputVectorDomain;
import com.github.magif1712.smarter_touhou_maids.features.ai.urana.semantics.containers.io.subspan.BehaviorSpan;
import com.github.magif1712.smarter_touhou_maids.features.ai.urana.semantics.containers.io.subspan.FeelingSpan;
import com.github.magif1712.smarter_touhou_maids.features.ai.urana.semantics.containers.io.subspan.InheritanceInfoSpan;
import com.github.magif1712.smarter_touhou_maids.core.containers.vector.IVector;

import java.util.ArrayList;
import java.util.List;

/**
 * Urana 系统的顶层协调器。
 * 负责初始化并驱动三个认知层次（行动、分析、反思）的8个核心流程。
 * 遵循“真善美”设计原则，此类作为整个 urana AI 功能的唯一入口点，
 * 其结构清晰地反映了它在概念模型中作为“大脑”或“心脏”的顶层地位。
 */
public class UranaSystem implements AutoCloseable {

    private static final OutputVectorDomain OUTPUT_DOMAIN = new OutputVectorDomain();

    // === 尺寸常量 (需要根据实际情况定义) ---
    private static final int FEELING_SIZE = 256;
    private static final int BEHAVIOR_SIZE = 128;
    private static final int INPUT_SIZE = 1024;
    private static final int OUTPUT_SIZE = 1024;
    private static final int DT_SIZE = 8; // 假设 dt 向量的大小

    // === 共享网络（唯一实例）===
    private final NetworkData sharedNet;

    // === 第一层：行动者 (Prospective) ===
    private final ProspectiveAnchor prospectiveAnchor;         // 流程一
    private final ProspectiveInference prospectiveInference;             // 流程二
    private final ProspectiveGradCell prospectiveGradCell;     // 流程三

    // === 第二层：分析师 (Retrospective) ===
    private final RetrospectiveAnchor retrospectiveAnchor;       // 流程五
    private final RetrospectiveInference retrospectiveInference;           // 流程四
    private final RetrospectiveGradCell retrospectiveGradCell;   // 流程六

    // === 第三层：反思者 (Introspective) ===
    private final IntrospectiveAnchor introspectiveAnchor;       // 流程七 (数据容器)
    private final IntrospectiveInference introspectiveInference;           // 流程七 (推理逻辑)
    private final TrainingContext introspectiveTrainingContext; // 流程八

    // === 跨时间步传递的状态 ===
    private BoolVector prospectiveInheritance;
    private BoolVector retrospectiveInheritance;
    private BoolVector introspectiveInheritance;
    private BoolVector lastRetrospectiveFeeling;

    // === 预分配临时缓冲区，避免每 tick 重复显存分配 ===
    private final BoolVector prospectiveBehaviorBuffer;
    private final OutputVector retroOutputForAnchor;

    public UranaSystem() {
        // --- 初始化唯一共享网络 ---
        try {
            this.sharedNet = new NetworkData(INPUT_SIZE, OUTPUT_SIZE, true);
        } catch (java.io.IOException e) {
            throw new RuntimeException("Failed to initialize shared NetworkData", e);
        }

        // --- 初始化所有组件（全部注入同一个网络）---
        // 行动层
        this.prospectiveAnchor = new ProspectiveAnchor(FEELING_SIZE, BEHAVIOR_SIZE);
        this.prospectiveInference = new ProspectiveInference(this.sharedNet);
        this.prospectiveGradCell = new ProspectiveGradCell(this.sharedNet);

        // 分析层
        this.retrospectiveAnchor = new RetrospectiveAnchor(FEELING_SIZE, BEHAVIOR_SIZE);
        this.retrospectiveInference = new RetrospectiveInference(this.sharedNet);
        this.retrospectiveGradCell = new RetrospectiveGradCell(this.sharedNet);

        // 反思层
        this.introspectiveAnchor = new IntrospectiveAnchor(FEELING_SIZE, BEHAVIOR_SIZE);
        this.introspectiveInference = new IntrospectiveInference(this.sharedNet);
        this.introspectiveTrainingContext = new TrainingContext(this.sharedNet);

        // 初始化跨轮状态（避免首轮 NPE）
        int sizeC = new com.github.magif1712.smarter_touhou_maids.features.ai.urana.semantics.containers.io.InputVectorDomain()
                .getInheritanceInfoSpan().getLength();
        this.prospectiveInheritance = new BoolVector(sizeC);
        this.retrospectiveInheritance = new BoolVector(sizeC);
        this.introspectiveInheritance = new BoolVector(sizeC);
        this.lastRetrospectiveFeeling = new BoolVector(FEELING_SIZE);

        // 预分配行为提取缓冲区（尺寸由输出向量的 BehaviorSpan 决定）
        this.prospectiveBehaviorBuffer = new BoolVector(OUTPUT_DOMAIN.getBehaviorSpan().getLength());

        // 预分配用于“分析层”的 OutputVector
        this.retroOutputForAnchor = new OutputVector(OutputVectorDomain.TOTAL_LENGTH);
    }

    /**
     * 主循环，在每个时间步被调用。
     * @param currentFeeling 从环境中感知的当前感觉。
     * @param dt 时间间隔。
     */
    public void runOneTick(BoolVector currentFeeling, BoolVector dt) {

        // === 1. 行动与分析 ===

        // [流程一]
        prospectiveAnchor.tick();
        prospectiveAnchor.pushFeeling(currentFeeling);

        // [流程二] N=2 链条：阶段1(F=外部感觉, C=上轮inheritance) → 阶段2(F=阶段1输出F, C=阶段1输出C)
        BoolVector feelingForInference = prospectiveAnchor.getFeeling().getSuspension();
        BoolVector prospectiveOutput = prospectiveInference.execute(
            feelingForInference, this.prospectiveInheritance, dt
        );
        extractBehaviorTo(prospectiveOutput, this.prospectiveBehaviorBuffer);
        extractInheritance(prospectiveOutput, this.prospectiveInheritance);
        prospectiveAnchor.pushBehaviorFrom(this.prospectiveBehaviorBuffer);

        // [流程四] N=1：F=上轮输出F，C=上轮输出C
        BoolVector retrospectiveOutput = retrospectiveInference.execute(
            this.lastRetrospectiveFeeling, this.retrospectiveInheritance, dt
        );
        retrospectiveAnchor.tick();
        this.retroOutputForAnchor.getVector().copyFromBoolVector(
            fullSpan(this.retroOutputForAnchor.getVector()), retrospectiveOutput, fullSpan(retrospectiveOutput)
        );
        retrospectiveAnchor.pushFromOutput(this.retroOutputForAnchor);
        extractFeeling(retrospectiveOutput, this.lastRetrospectiveFeeling);
        extractInheritance(retrospectiveOutput, this.retrospectiveInheritance);


        // === 2. 学习与反思 ===

        // [流程三]
        prospectiveGradCell.execute(prospectiveAnchor, dt);

        // [流程六]
        retrospectiveGradCell.execute(retrospectiveAnchor, dt);

        // [流程七] N=1：F=锚点沉淀物，C=上轮inheritance
        introspectiveAnchor.pokeFrom(retrospectiveAnchor);
        BoolVector introspectiveOutput = introspectiveInference.execute(
            introspectiveAnchor.getFeeling().getPrecipitate(),
            this.introspectiveInheritance,
            dt
        );
        introspectiveAnchor.pokeInto(introspectiveOutput, introspectiveOutput);
        extractInheritance(introspectiveOutput, this.introspectiveInheritance);

        // [流程八]
        introspectiveTrainingContext.execute(introspectiveAnchor, dt);
    }

    private void extractBehaviorTo(BoolVector outputVector, BoolVector target) {
        int size = OUTPUT_DOMAIN.getBehaviorSpan().getLength();
        target.copyFromBoolVector(
            new BehaviorSpan(0, size),
            outputVector,
            OUTPUT_DOMAIN.getBehaviorSpan()
        );
    }

    private void extractFeeling(BoolVector outputVector, BoolVector targetFeeling) {
        targetFeeling.copyFromBoolVector(
            new FeelingSpan(0, targetFeeling.size()),
            outputVector,
            OUTPUT_DOMAIN.getFeelingSpan()
        );
    }

    private void extractInheritance(BoolVector outputVector, BoolVector targetInheritance) {
        targetInheritance.copyFromBoolVector(
            new InheritanceInfoSpan(0, targetInheritance.size()),
            outputVector,
            OUTPUT_DOMAIN.getInheritanceInfoSpan()
        );
    }

    private Span fullSpan(IVector vector) {
        return new Span(0, vector.size()) {};
    }

    @Override
    public void close() throws Exception {
        // 在此释放所有 AutoCloseable 资源
        prospectiveAnchor.close();
        prospectiveInference.close();
        prospectiveGradCell.close();
        retrospectiveAnchor.close();
        retrospectiveInference.close();
        retrospectiveGradCell.close();
        introspectiveAnchor.close();
        introspectiveInference.close();
        introspectiveTrainingContext.close();

        // ✅ 只释放一次共享网络
        if (sharedNet != null) sharedNet.close();

        // 补充释放跨轮状态
        if (prospectiveInheritance != null) prospectiveInheritance.close();
        if (retrospectiveInheritance != null) retrospectiveInheritance.close();
        if (introspectiveInheritance != null) introspectiveInheritance.close();
        if (lastRetrospectiveFeeling != null) lastRetrospectiveFeeling.close();
        if (prospectiveBehaviorBuffer != null) prospectiveBehaviorBuffer.close();
        if (retroOutputForAnchor != null) retroOutputForAnchor.close();
    }
}