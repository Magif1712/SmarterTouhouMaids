package com.github.magif1712.smarter_touhou_maids.features.maid;

import com.github.magif1712.smarter_touhou_maids.core.config.SmarterMaidConfig;
import com.github.magif1712.smarter_touhou_maids.features.maid.init.InitMenus;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;


@Mod(SmarterTouhouMaids.MOD_ID)
public class SmarterTouhouMaids {
    public static final String MOD_ID = "smarter_touhou_maids";

    public SmarterTouhouMaids(FMLJavaModLoadingContext context) {
        IEventBus modEventBus = context.getModEventBus();
        InitMenus.MENUS.register(modEventBus);

        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, SmarterMaidConfig.CLIENT_SPEC);
    }
}