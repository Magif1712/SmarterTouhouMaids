package com.github.magif1712.smarter_touhou_maids.features.ai.urana.process.prospective;

import com.github.magif1712.smarter_touhou_maids.features.ai.urana.process.common.AbstractAnchor;

/**
 * 流程一（感觉-行为滑动窗口）的上下文 data 容器。
 * 代表一个向前看的、探索性的锚点。（向未来滑动）
 */
public class ProspectiveAnchor extends AbstractAnchor {

    public ProspectiveAnchor(int feelingSize, int behaviorSize) {
        super(feelingSize, behaviorSize);
    }

    // 所有 tick(), close(), getFeeling(), getBehavior() 的实现都已继承自 AbstractAnchor！
    // 这里可以根据需要添加 ProspectiveAnchor 特有的方法。
}