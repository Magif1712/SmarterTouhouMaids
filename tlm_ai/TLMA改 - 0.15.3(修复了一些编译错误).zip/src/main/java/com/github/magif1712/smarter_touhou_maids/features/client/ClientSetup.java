package com.github.magif1712.smarter_touhou_maids.features.client;

import com.github.magif1712.smarter_touhou_maids.features.maid.SmarterTouhouMaids;
import com.github.magif1712.smarter_touhou_maids.features.client.screen.AutoTaskConfigScreen;
import com.github.magif1712.smarter_touhou_maids.features.maid.init.InitMenus;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

@Mod.EventBusSubscriber(modid = SmarterTouhouMaids.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {
    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            MenuScreens.register(InitMenus.AUTO_TASK_CONFIG_MENU.get(), AutoTaskConfigScreen::new);
//            Runtime.getRuntime().addShutdownHook(new Thread(NativeLibLoader::releaseSharedNeuronBuffer, "tlm-ai-release"));
        });
    }
}