package com.github.magif1712.smarter_touhou_maids.core.containers.vector;

import com.github.magif1712.smarter_touhou_maids.core.containers.domain.Span;
import java.util.Objects;

/**
 * 整数向量 (IntVector)。
 */
public final class IntVector extends VectorBase {
    public IntVector() {
        super();
    }

    public IntVector(int size) {
        super();
        allocate(size);
    }

    private IntVector(long handle, int size) {
        super(handle, size);
    }

    @Override
    public void allocate(int size) {
        validateSize(size);
        long newHandle = VectorNative._createVectorInt();
        VectorNative._allocateInt(newHandle, size);
        setHandleAndSize(newHandle, size);
    }

    public void copyFromHost(int[] data, int count) {
        validateCount(count, data.length);
        validateCount(count, size());
        VectorNative._copyFromHostInt(requireHandle(), data, count);
    }

    public void copyToHost(int[] data) {
        copyToHost(data, data.length);
    }

    public void copyToHost(int[] data, int count) {
        validateCount(count, data.length);
        validateCount(count, size());
        VectorNative._copyToHostInt(requireHandle(), data, count);
    }

    public int[] toHostArray() {
        int[] data = new int[size()];
        copyToHost(data);
        return data;
    }

    @Override
    public void save(String path) {
        VectorNative._saveInt(requireHandle(), Objects.requireNonNull(path));
    }

    public static IntVector loadFromFile(String path) {
        Objects.requireNonNull(path);
        long h = VectorNative._createVectorInt();
        if (h == 0)
            throw new RuntimeException("Failed to create native handle for loading.");

        VectorNative._loadFromFileInt(h, path);
        int size = VectorNative._getSizeInt(h);
        return new IntVector(h, size);
    }

    public void copyFromIntVector(Span destSpan, IntVector source, Span srcSpan) {
        Objects.requireNonNull(destSpan);
        Objects.requireNonNull(source);
        Objects.requireNonNull(srcSpan);
        long destOffset = destSpan.getOffset();
        long srcOffset = srcSpan.getOffset();
        long count = srcSpan.getLength();

        if (count == 0)
            return;
        if (destOffset + count > this.size())
            throw new IllegalArgumentException("Destination out of bounds.");
        if (srcOffset + count > source.size())
            throw new IllegalArgumentException("Source out of bounds.");

        VectorNative._copyRegionFromInt(requireHandle(), destOffset, source.requireHandle(), srcOffset, count);
    }

    @Override
    public void copyRegionFrom(VectorBase source, Span srcSpan, Span destSpan) {
        if (!(source instanceof IntVector)) {
            throw new IllegalArgumentException("Source must be an IntVector.");
        }
        this.copyFromIntVector(destSpan, (IntVector) source, srcSpan);
    }

    public void setRegion(Span destSpan, IntVector source) {
        Objects.requireNonNull(destSpan);
        Objects.requireNonNull(source);
        if (source.size() == 0)
            return;

        long destOffset = destSpan.getOffset();
        long count = source.size();

        if (destSpan.getLength() != count) {
            throw new IllegalArgumentException(String.format(
                    "Destination span length (%d) must match source vector size (%d).",
                    destSpan.getLength(), count));
        }
        if (destOffset + count > this.size())
            throw new IllegalArgumentException("Destination out of bounds.");

        VectorNative._setRegionInt(requireHandle(), destOffset, source.requireHandle());
    }

    public void copyRegionFromHost(Span destSpan, int[] src_data) {
        Objects.requireNonNull(destSpan);
        Objects.requireNonNull(src_data);

        int count = destSpan.getLength();
        if (count == 0) return;

        long destOffset = destSpan.getOffset();
        if (destOffset + count > this.size()) {
            throw new IllegalArgumentException("Destination span is out of bounds for this vector.");
        }
        if (count > src_data.length) {
            throw new IllegalArgumentException("Source data array is too small for the destination span.");
        }

        // 调用底层的、保持不变的 native 接口
        VectorNative._copyRegionFromHostInt(requireHandle(), destOffset, src_data, count);
    }

    public void multiplyByScalar(int scalar) {
        if (size() > 0) {
            multiplyByScalar(scalar, new Span(0, size()) {});
        }
    }

    /**
     * 对向量的指定区间执行原地标量乘法。
     *
     * @param scalar 标量乘数。
     * @param span   要操作的区间。
     */
    public void multiplyByScalar(int scalar, Span span) {
        Objects.requireNonNull(span);
        long offset = span.getOffset();
        long length = span.getLength();

        if (length <= 0) {
            return;
        }
        if (offset < 0 || length < 0 || offset + length > size()) {
            throw new IllegalArgumentException(String.format(
                    "The specified span [offset=%d, length=%d] is out of bounds for vector of size %d.",
                    offset, length, size()));
        }
        VectorNative._multiplyByScalarInt(requireHandle(), scalar, offset, length);
    }

    @Override
    protected void releaseResource() {
        VectorNative._deleteVectorInt(handle);
    }
}