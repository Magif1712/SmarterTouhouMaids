package com.github.magif1712.smarter_touhou_maids.core.execution;

/**
 * JNI bridge for CUDA stream operations.
 * This class is package-private and should not be used directly by features.
 * All native calls related to streams are centralized here.
 */
class StreamNative {
    static {
        // Assuming your native library is loaded elsewhere, e.g., in a central loader.
        // If not, you would load it here: System.loadLibrary("your_lib_name");
    }

    /**
     * Calls the native method to create a new CUDA stream.
     *
     * @return The native handle (pointer) to the created stream.
     */
    static native long _createStream();

    /**
     * Calls the native method to destroy a CUDA stream.
     *
     * @param streamHandle The handle of the stream to destroy.
     */
    static native void _destroyStream(long streamHandle);

    /**
     * Calls the native method to synchronize a CUDA stream.
     *
     * @param streamHandle The handle of the stream to synchronize.
     */
    static native void _synchronize(long streamHandle);
}