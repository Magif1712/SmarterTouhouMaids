package com.github.magif1712.smarter_touhou_maids.core.containers.vector;

import com.github.magif1712.smarter_touhou_maids.core.containers.domain.Span;

/**
 * 向量的抽象基类，负责句柄生命周期管理。
 * 虽然通过接口组织，但基类仍用于提取共性的资源管理逻辑。
 */
public abstract class VectorBase implements IVector {
    protected long handle;
    protected int size;
    protected boolean ownsHandle;

    protected VectorBase() {
        this.handle = 0L;
        this.size = 0;
        this.ownsHandle = false;
    }

    protected VectorBase(long handle, int size) {
        if (handle == 0L) {
            throw new IllegalStateException("Native vector creation failed");
        }
        this.handle = handle;
        this.size = size;
        this.ownsHandle = true;
    }

    protected void setHandleAndSize(long handle, int size) {
        if (handle == 0L) {
            throw new IllegalStateException("Native vector creation failed");
        }
        close();
        this.handle = handle;
        this.size = size;
        this.ownsHandle = true;
    }

    @Override
    public final int size() {
        return size;
    }

    @Override
    public final long handle() {
        return handle;
    }

    @Override
    public final boolean isInitialized() {
        return ownsHandle && handle != 0L;
    }

    public final long requireHandle() {
        if (!isInitialized()) {
            throw new IllegalStateException("Vector has already been released or was not initialized");
        }
        return handle;
    }

    @Override
    public final void close() {
        if (this.ownsHandle) {
            releaseResource();
            this.ownsHandle = false;
            this.handle = 0L;
            this.size = 0;
        }
    }

    /**
     * 从另一个向量对象移动资源所有权到当前对象。
     * 实现移动语义，确保显存资源的唯一所有权。
     */
    public void moveFrom(VectorBase other) {
        if (this == other) {
            throw new IllegalArgumentException("Cannot move an object to itself.");
        }
        close();
        this.handle = other.handle;
        this.size = other.size;
        this.ownsHandle = other.ownsHandle;

        other.handle = 0L;
        other.size = 0;
        other.ownsHandle = false;
    }

    protected abstract void releaseResource();

    public abstract void copyRegionFrom(VectorBase source, Span srcSpan, Span destSpan);

    // 内部校验工具
    protected static void validateSize(int size) {
        if (size < 0) {
            throw new IllegalArgumentException("size must be non-negative");
        }
    }

    protected static void validateCount(int count, int length) {
        if (count < 0 || count > length) {
            throw new IllegalArgumentException("count is out of range");
        }
    }
}