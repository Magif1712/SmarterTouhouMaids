package com.github.magif1712.smarter_touhou_maids.features.smarter.agent.reflex_arc_system.outlet;

import com.github.magif1712.smarter_touhou_maids.core.containers.vector.BoolVector;
import com.github.magif1712.smarter_touhou_maids.core.execution.counter.MappedCounter;

/**
 * 意识产出物的出口（意识-外周边界对象）。
 * <p>
 * 持有 UranaSystem 产出的 behavior 容器（host mapped pinned memory，zero-copy）
 * 与行为产出代际计数器（{@link MappedCounter}）。它同时面向两侧：
 * <ul>
 *   <li>producer 面（供 UranaSystem 意识侧）：{@link #getBuffer()} 返回容器供写入，
 *       {@link #declareProduced(long)} 宣告产出完成。</li>
 *   <li>consumer 面（供 SmarterClientService 外周侧）：{@link #getGeneration()} 读取代际，
 *       {@link #readBehavior(int[])} 读取行为。</li>
 * </ul>
 * <p>
 * 设计原则（真善美第 2 条）：UranaSystem（意识域）只产出 behavior + 宣告完成，
 * 不关心产出物如何被外周消费（mapped / D2H / ...）。“外周如何消费产出物”这一外周模式，
 * 连同 mapped 分配决定，全部封装在本边界对象中，不渗透进 UranaSystem。
 * <p>
 * 设计原则（模式分层）：本对象位于 agent 层，与 urana（思考流程）/ effector（执行）/ sensor（感知）
 * 平级，是意识与外周的接合处，不从属于任何一方。“宣告产出完成”是上层模式（由 UranaSystem 调
 * {@link #declareProduced}），“递增 host 可见计数器”是其下层实现（由本对象内部
 * {@link MappedCounter} 承担），上层不直接触碰下层。
 * <p>
 * 生命周期：由外周（SmarterClientService）创建并注入 UranaSystem，外周负责关闭。
 * 关闭须在 UranaSystem 工作线程 join 之后（工作线程每轮写入 buffer + declareProduced）。
 */
public final class BehaviorOutlet implements AutoCloseable {

    private final BoolVector buffer;
    private final MappedCounter generation;

    /**
     * @param behaviorBits behavior 输出位长度（BEHAVIOR_SPAN_LENGTH）。
     */
    public BehaviorOutlet(int behaviorBits) {
        this.buffer = BoolVector.mapped(behaviorBits);
        this.generation = new MappedCounter();
    }

    // === producer 面：供 UranaSystem（意识侧）使用 ===

    /**
     * 返回行为产出容器，供 UranaSystem 写入（extractBehaviorTo）与内部读取（pushBehaviorFrom）。
     * <p>
     * 容器为 host mapped pinned memory：GPU 经 device 视图写 = 写 host 内存。
     * 容器性质（mapped）属外周消费方式的实现，被封装在本对象内，UranaSystem 不感知。
     */
    public BoolVector getBuffer() {
        return buffer;
    }

    /**
     * 宣告产出完成：在指定 stream 上递增 generation。
     * <p>
     * 应排在写 buffer 之后（流内有序），故 host 看到 generation 变化即意味着 buffer 已写完。
     * 这是 UranaSystem「宣告产出完成」上层模式的落地调用；
     * 底层用 {@link MappedCounter}（host mapped uint32 + atomicAdd_system）实现，由本对象承担。
     */
    public void declareProduced(long streamHandle) {
        generation.increment(streamHandle);
    }

    // === consumer 面：供 SmarterClientService（外周侧）使用 ===

    /**
     * 读取当前 generation 值（纯 host 读，零 CUDA 调用，不 flush WDDM）。
     * 值变化 = UranaSystem 已产出新 behavior 且 GPU 已写完 buffer。
     */
    public int getGeneration() {
        return generation.getHostValue();
    }

    /**
     * 从 mapped host 内存读取完整 behavior 到 int[]（纯 host memcpy，零 CUDA 调用）。
     * 调用方应先判断 {@link #getGeneration()} 变化再调用，避免读到撕裂数据。
     */
    public void readBehavior(int[] bitPackedData) {
        buffer.readMappedToJava(bitPackedData);
    }

    @Override
    public void close() {
        if (buffer != null) {
            buffer.close();
        }
        if (generation != null) {
            generation.close();
        }
    }
}
