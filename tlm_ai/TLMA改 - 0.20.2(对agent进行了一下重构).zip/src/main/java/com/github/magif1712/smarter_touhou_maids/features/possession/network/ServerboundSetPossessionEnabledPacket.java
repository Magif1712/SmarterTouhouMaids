package com.github.magif1712.smarter_touhou_maids.features.possession.network;

import com.github.magif1712.smarter_touhou_maids.features.possession.ServerPossessionManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.UUID;
import java.util.function.Supplier;

/**
 * 数据包: 客户端 -> 服务器
 * 用途: 请求修改女仆的"可附身"NBT标签
 * <p>
 * 编码铁律:
 * 1. handle 方法必须使用 enqueueWork 将逻辑提交到主线程。
 */
public class ServerboundSetPossessionEnabledPacket {
    private final UUID maidUUID;
    private final boolean enabled;

    public ServerboundSetPossessionEnabledPacket(UUID maidUUID, boolean enabled) {
        this.maidUUID = maidUUID;
        this.enabled = enabled;
    }

    public static void encode(ServerboundSetPossessionEnabledPacket msg, FriendlyByteBuf buf) {
        buf.writeUUID(msg.maidUUID);
        buf.writeBoolean(msg.enabled);
    }

    public static ServerboundSetPossessionEnabledPacket decode(FriendlyByteBuf buf) {
        return new ServerboundSetPossessionEnabledPacket(buf.readUUID(), buf.readBoolean());
    }

    public static void handle(ServerboundSetPossessionEnabledPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sender = ctx.get().getSender();
            if (sender == null) {
                return;
            }
            ServerPossessionManager.INSTANCE.setPossessionEnabled(sender, msg.maidUUID, msg.enabled);
        });
        ctx.get().setPacketHandled(true);
    }
}