package com.github.magif1712.smarter_touhou_maids.features.ui.screen;

import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.SmarterClientService;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.registry.Registry;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.registry.RegistryEntry;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.registry.RegistryIds;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.registry.RegistryManager;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.reflex_arc_system.debug.EffectorDebugHook;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.reflex_arc_system.debug.VisionDebugHook;
import com.github.magif1712.smarter_touhou_maids.features.smarter.config.SmarterConfig;
import com.github.magif1712.smarter_touhou_maids.features.maid.menu.AutoTaskConfigMenu;
import com.github.magif1712.smarter_touhou_maids.features.possession.client.ui.PossessionToggleWidget;
import com.github.magif1712.smarter_touhou_maids.features.possession.core.PossessionManager;
import com.github.magif1712.smarter_touhou_maids.features.smarter.state.MaidSmarterState;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Inventory;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import java.util.function.Function;

/**
 * "自动任务"的配置界面。
 * <p>
 * 该界面允许玩家配置与 AI 相关的参数，核心功能包括：
 * 1. "附身"模式开关：允许玩家"牺牲"自己的实体以换取女仆更强的 AI 性能。
 * 2. AI 模式选择模块：递归展开 agent→ai→process→nn（及附属扩展的任意层次），
 *    每层一个 CycleButton，改选择时 rebuildWidgets 动态重建下层按钮（动态显隐）。
 *    彻底解决"用什么模式被代码硬编码"的问题，附属模组流畅接入。
 * 3. 辅助神经元数量：配置 AI 模型中的参数。
 * 4. Urana 快/慢环最小轮间间隔：per-maid 节律参数。
 * 5. 各种调试开关。
 */
public class AutoTaskConfigScreen extends AbstractContainerScreen<AutoTaskConfigMenu> {
    private static final int BG_COLOR = 0xCC000000;
    private static final int GUI_WIDTH = 380;
    /**
     * 默认结构最多 4 层模式选择（agent→ai→process→nn）× 25px = 100px + 现有控件。
     * 附属加更多层时若溢出，MVP 不做滚动。
     */
    private static final int GUI_HEIGHT = 360;

    private EditBox neuronCountBox;
    private EditBox fastMinDtBox;
    private EditBox slowMinDtBox;
    private CycleButton<Boolean> smarterModeButton;
    /**
     * 模式选择递归展开后的结束 y（GUI 内部坐标），供 renderLabels 自适应定位后续标签。
     * init() 里由 buildModeSelectors 设置，rebuildWidgets 时自动更新。
     */
    private int modeEndYGui = 80;

    public AutoTaskConfigScreen(AutoTaskConfigMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = GUI_WIDTH;
        this.imageHeight = GUI_HEIGHT;
    }

    @Override
    protected void init() {
        super.init();
        int startX = (this.width - this.imageWidth) / 2;
        int startY = (this.height - this.imageHeight) / 2;
        EntityMaid maid = this.menu.getMaid();

        if (maid != null) {
            // ========== 上层模式：允许附身（y=25） ==========
            boolean possessionCurrent = PossessionManager.INSTANCE.isPossessionEnabled(maid);
            CycleButton<Boolean> possessionButton = CycleButton.onOffBuilder(possessionCurrent)
                    .create(startX + 10, startY + 25, 150, 20,
                            Component.literal("允许附身"),
                            (btn, value) -> {
                                PossessionManager.INSTANCE.setPossessionEnabled(maid, value);
                                if (!value && this.smarterModeButton != null) {
                                    this.smarterModeButton.setValue(false);
                                    this.smarterModeButton.active = false;
                                    PossessionManager.INSTANCE.setSmarterModeEnabled(maid, false);
                                } else if (this.smarterModeButton != null) {
                                    this.smarterModeButton.active = true;
                                }
                            });
            possessionButton.setTooltip(Tooltip.create(Component.literal("是否允许玩家附身此女仆")));
            this.addRenderableWidget(possessionButton);

            // ========== 下层模式：被附身后开启更聪明模式（y=50） ==========
            boolean smarterCurrent = PossessionManager.INSTANCE.isSmarterModeEnabled(maid);
            this.smarterModeButton = CycleButton.onOffBuilder(smarterCurrent)
                    .create(startX + 10, startY + 50, 150, 20,
                            Component.literal("被附身后开启更聪明模式"),
                            (btn, value) -> PossessionManager.INSTANCE.setSmarterModeEnabled(maid, value));
            this.smarterModeButton.setTooltip(Tooltip.create(
                    Component.literal("附身时是否启用AI增强决策")));
            this.smarterModeButton.active = possessionCurrent;
            this.addRenderableWidget(this.smarterModeButton);
        }

        // ========== AI 模式选择递归展开（y=75 起，动态显隐） ==========
        // 从顶层 AgentRegistry 开始，选中 entry 后据其 subRegistryId 递归展开下层。
        // 改某层选择时 callback 调 rebuildWidgets()，下层按钮按新选中 entry 的 subRegistryId 重新展开。
        // 兼容无限层次：附属加新 entry 时声明自己的 subRegistryId，GUI 自动递归展开，代码零改动。
        int modeEndY = startY + 75;
        if (maid != null) {
            modeEndY = buildModeSelectors(maid, startX + 10, startY + 75, RegistryIds.AGENT);
        }
        this.modeEndYGui = modeEndY - startY;

        // ========== 辅助神经元数量（modeEndY + 20） ==========
        int nextY = modeEndY + 20;
        this.neuronCountBox = new EditBox(this.font, startX + 10, nextY, 150, 20, Component.literal(""));
        this.neuronCountBox.setValue(String.valueOf(SmarterConfig.neuronCount.get()));
        this.neuronCountBox.setResponder(text -> {
            String trimmed = text.trim();
            if (trimmed.isEmpty()) {
                return;
            }
            try {
                int value = Mth.clamp(Integer.parseInt(trimmed), 1, 1024);
                SmarterConfig.neuronCount.set(value);
            } catch (NumberFormatException ignored) {
            }
        });
        this.addRenderableWidget(this.neuronCountBox);

        // ========== AI视觉调试（modeEndY + 45） ==========
        nextY += 25;
        boolean visionDebugCurrent = VisionDebugHook.INSTANCE.isEnabled();
        CycleButton<Boolean> visionDebugButton = CycleButton.onOffBuilder(visionDebugCurrent)
                .create(startX + 10, nextY, 150, 20,
                        Component.literal("AI视觉调试"),
                        (btn, value) -> VisionDebugHook.INSTANCE.setEnabled(value));
        visionDebugButton.setTooltip(Tooltip.create(
                Component.literal("开启后定期dump AI视觉到 debug/smarter_touhou_maids/vision_debug（有性能开销）")));
        this.addRenderableWidget(visionDebugButton);

        // ========== dt轮间间隔调试（modeEndY + 70） ==========
        nextY += 25;
        boolean dtDebugCurrent = SmarterClientService.INSTANCE.isDtDebugEnabled();
        CycleButton<Boolean> dtDebugButton = CycleButton.onOffBuilder(dtDebugCurrent)
                .create(startX + 10, nextY, 150, 20,
                        Component.literal("dt轮间间隔调试"),
                        (btn, value) -> SmarterClientService.INSTANCE.setDtDebugEnabled(value));
        dtDebugButton.setTooltip(Tooltip.create(
                Component.literal("开启后每轮输出 urana 轮间时间间隔 dt（毫秒）到日志")));
        this.addRenderableWidget(dtDebugButton);

        // ========== per-maid：快/慢环最小轮间间隔（modeEndY + 95 / +120） ==========
        nextY += 25;
        if (maid != null) {
            this.fastMinDtBox = new EditBox(this.font, startX + 10, nextY, 150, 20, Component.literal(""));
            this.fastMinDtBox.setValue(String.valueOf(PossessionManager.INSTANCE.getFastMinDtMillis(maid)));
            this.fastMinDtBox.setTooltip(Tooltip.create(
                    Component.literal("觉前行快环两轮间最小时间间隔（毫秒），0=不限速")));
            this.addRenderableWidget(this.fastMinDtBox);

            nextY += 25;
            this.slowMinDtBox = new EditBox(this.font, startX + 10, nextY, 150, 20, Component.literal(""));
            this.slowMinDtBox.setValue(String.valueOf(PossessionManager.INSTANCE.getSlowMinDtMillis(maid)));
            this.slowMinDtBox.setTooltip(Tooltip.create(
                    Component.literal("觉前行慢环两轮间最小时间间隔（毫秒），0=不限速")));
            this.addRenderableWidget(this.slowMinDtBox);
        }

        // ========== 效应器调试（modeEndY + 145） ==========
        nextY += 25;
        boolean effectorDebugCurrent = EffectorDebugHook.INSTANCE.isEnabled();
        CycleButton<Boolean> effectorDebugButton = CycleButton.onOffBuilder(effectorDebugCurrent)
                .create(startX + 10, nextY, 150, 20,
                        Component.literal("效应器调试"),
                        (btn, value) -> EffectorDebugHook.INSTANCE.setEnabled(value));
        effectorDebugButton.setTooltip(Tooltip.create(
                Component.literal("开启后每 tick 输出效应器指令到终端（前进/平移/视角/跳跃/攻击等）")));
        this.addRenderableWidget(effectorDebugButton);
    }

    /**
     * 递归展开模式选择按钮（动态显隐，兼容无限层次）。
     * <p>
     * 从指定 registryId 开始，创建一个 CycleButton 列出该层所有 entry。
     * 选中 entry 后据其 subRegistryId 递归展开下层。subRegistryId 为 null 时停止（叶子）。
     * 改选择时 callback 调 {@link #rebuildWidgets()}，触发 init() 重跑，下层按钮按新选择重建。
     *
     * @return 下一个可用 y 坐标（屏幕坐标）
     */
    private int buildModeSelectors(EntityMaid maid, int x, int y, ResourceLocation registryId) {
        Registry<?> registry = RegistryManager.INSTANCE.get(registryId);
        if (registry == null) {
            return y; // 附属未注册此层，跳过
        }

        // 读 maid 当前该层选择（pending → NBT → default）
        ResourceLocation currentId = PossessionManager.INSTANCE.getMode(maid, registryId);
        if (currentId == null) {
            currentId = registry.getDefaultId();
        }

        // 列出该层所有 entry 的 id，valueToText 翻译为 displayName
        List<ResourceLocation> optionIds = registry.getAllIds();
        Function<ResourceLocation, Component> valueToText = id -> {
            RegistryEntry<?> entry = registry.get(id);
            return Component.translatable(entry.getDisplayNameKey());
        };

        // 创建 CycleButton：title = registry path（agent/ai/process/nn），value = 当前选中 entry
        CycleButton<ResourceLocation> btn = CycleButton.<ResourceLocation>builder(valueToText)
                .withValues(optionIds)
                .withInitialValue(currentId)
                .create(x, y, 200, 20,
                        Component.literal(registryId.getPath()),
                        (b, selectedId) -> {
                            PossessionManager.INSTANCE.setMode(maid, registryId, selectedId);
                            // 动态显隐核心：rebuildWidgets 触发 init() 重跑，
                            // 下层按钮按新选中 entry 的 subRegistryId 重新展开
                            this.rebuildWidgets();
                        });
        this.addRenderableWidget(btn);

        y += 25;

        // 递归：查选中 entry 的 subRegistryId
        RegistryEntry<?> currentEntry = registry.get(currentId);
        if (currentEntry != null && currentEntry.getSubRegistryId() != null) {
            y = buildModeSelectors(maid, x, y, currentEntry.getSubRegistryId());
        }
        // subRegistryId == null → 叶子，停止递归

        return y;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (this.neuronCountBox != null && this.neuronCountBox.isFocused() && (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER)) {
            this.commitNeuronCount();
            this.setFocused(null);
            return true;
        }
        if (this.fastMinDtBox != null && this.fastMinDtBox.isFocused() && (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER)) {
            this.commitFastMinDtMillis();
            this.setFocused(null);
            return true;
        }
        if (this.slowMinDtBox != null && this.slowMinDtBox.isFocused() && (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER)) {
            this.commitSlowMinDtMillis();
            this.setFocused(null);
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void removed() {
        this.commitNeuronCount();
        this.commitFastMinDtMillis();
        this.commitSlowMinDtMillis();
        super.removed();
    }

    @Override
    protected void renderBg(GuiGraphics guiGraphics, float partialTick, int mouseX, int mouseY) {
        int startX = (this.width - this.imageWidth) / 2;
        int startY = (this.height - this.imageHeight) / 2;
        guiGraphics.fill(startX, startY, startX + this.imageWidth, startY + this.imageHeight, BG_COLOR);
    }

    @Override
    protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
        guiGraphics.drawString(this.font, this.title, this.titleLabelX, this.titleLabelY, 0x39c5bb, true);
        // 后续标签自适应定位：基于 modeEndYGui（模式选择递归展开后的结束 y）
        guiGraphics.drawString(this.font, "每层辅助神经元数量", 10, this.modeEndYGui + 5, 0x39c5bb, false);
        guiGraphics.drawString(this.font, "觉前行快环两轮间最小间隔(ms)", 10, this.modeEndYGui + 80, 0x39c5bb, false);
        guiGraphics.drawString(this.font, "觉前行慢环两轮间最小间隔(ms)", 10, this.modeEndYGui + 105, 0x39c5bb, false);
    }

    private void commitNeuronCount() {
        if (this.neuronCountBox == null) {
            return;
        }
        String trimmed = this.neuronCountBox.getValue().trim();
        if (trimmed.isEmpty()) {
            return;
        }
        try {
            int value = Mth.clamp(Integer.parseInt(trimmed), 1, 1024);
            String normalized = String.valueOf(value);
            if (!normalized.equals(this.neuronCountBox.getValue())) {
                this.neuronCountBox.setValue(normalized);
            }
            SmarterConfig.neuronCount.set(value);
        } catch (RuntimeException exception) {
            Minecraft minecraft = Minecraft.getInstance();
            if (minecraft.player != null) {
                minecraft.player.sendSystemMessage(Component.literal("GPU 自动任务缓冲区初始化失败：" + exception.getMessage()));
            }
        }
    }

    private void commitFastMinDtMillis() {
        if (this.fastMinDtBox == null) return;
        EntityMaid maid = this.menu.getMaid();
        if (maid == null) return;

        String trimmed = this.fastMinDtBox.getValue().trim();
        if (trimmed.isEmpty()) return;

        try {
            long parsed = Long.parseLong(trimmed);
            long value = Math.max(0, Math.min(5000, parsed));
            String normalized = String.valueOf(value);
            if (!normalized.equals(this.fastMinDtBox.getValue())) {
                this.fastMinDtBox.setValue(normalized);
            }
            PossessionManager.INSTANCE.setFastMinDtMillis(maid, value);
        } catch (NumberFormatException ignored) {
        }
    }

    private void commitSlowMinDtMillis() {
        if (this.slowMinDtBox == null) return;
        EntityMaid maid = this.menu.getMaid();
        if (maid == null) return;

        String trimmed = this.slowMinDtBox.getValue().trim();
        if (trimmed.isEmpty()) return;

        try {
            long parsed = Long.parseLong(trimmed);
            long value = Math.max(0, Math.min(5000, parsed));
            String normalized = String.valueOf(value);
            if (!normalized.equals(this.slowMinDtBox.getValue())) {
                this.slowMinDtBox.setValue(normalized);
            }
            PossessionManager.INSTANCE.setSlowMinDtMillis(maid, value);
        } catch (NumberFormatException ignored) {
        }
    }
}
