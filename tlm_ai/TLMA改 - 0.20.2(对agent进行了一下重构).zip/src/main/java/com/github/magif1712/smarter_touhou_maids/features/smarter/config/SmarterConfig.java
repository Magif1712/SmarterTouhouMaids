package com.github.magif1712.smarter_touhou_maids.features.smarter.config;

import net.minecraftforge.common.ForgeConfigSpec;

public class SmarterConfig {
    public static ForgeConfigSpec.IntValue neuronCount;

    public static void register(ForgeConfigSpec.Builder builder) {
        builder.push("urana");
        neuronCount = builder
                .comment("Number of auxiliary neurons per layer.")
                .defineInRange("neuronCount", 128, 1, 1024);
        builder.pop();
    }
}