package com.github.magif1712.smarter_touhou_maids.features.smarter.agent.reflex_arc_system.ai.process_ai.process.urana_process;

import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.reflex_arc_system.ai.process_ai.process.IProcessSystem;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.reflex_arc_system.ai.process_ai.process.ProcessFactory;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.reflex_arc_system.ai.process_ai.process.urana_process.nn.INeuralNetwork;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.reflex_arc_system.ai.process_ai.process.urana_process.nn.NnFactory;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.reflex_arc_system.ai.process_ai.process.urana_process.semantics.containers.io.InputVectorDomain;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.reflex_arc_system.ai.process_ai.process.urana_process.semantics.containers.io.OutputVectorDomain;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.registry.Registry;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.registry.RegistryEntry;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.registry.RegistryIds;
import com.github.magif1712.smarter_touhou_maids.features.smarter.agent.registry.RegistryManager;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;

/**
 * Urana 流程系统的 {@link ProcessFactory} 实现。
 * <p>
 * <b>工厂自驱组装</b>（真善美第1条"真"）：本工厂直接使用 nn（UranaSystem 构造注入 INeuralNetwork），
 * 故自行查 {@code NnRegistry} 取下层 nn factory 创建 nn，再 new UranaSystem(nn, ...)。
 * <p>
 * <b>nn 尺寸归属 process 层</b>：inputSize/outputSize 是 urana 的 Domain 知识
 * （{@link InputVectorDomain#TOTAL_LENGTH} / {@link OutputVectorDomain#TOTAL_LENGTH}），
 * 由本工厂算出传给 nn factory。nn factory 不反向依赖 urana Domain。
 * <p>
 * <b>节律参数</b>：fastMinDt/slowMinDt 是 urana 双环特定的，从 config 读
 * （key = "FastMinDtMillis"/"SlowMinDtMillis"，与 MaidSmarterState 持久化 key 一致）。
 * 别的 process 实现的 factory 读自己需要的 key，忽略这两个。
 * <p>
 * 本类逻辑搬家自原 {@code ProcessAiSystem.buildDefaultProcess}（删除便利构造函数后，
 * 组装职责上移到本工厂，由配置驱动而非硬编码）。
 */
public class UranaProcessFactory implements ProcessFactory {

    private static final String KEY_FAST_MIN_DT = "FastMinDtMillis";
    private static final String KEY_SLOW_MIN_DT = "SlowMinDtMillis";

    @Override
    public IProcessSystem create(CompoundTag config) {
        // === 查 NnRegistry 取下层 nn factory（自驱组装）===
        INeuralNetwork nn = createNn(config);

        // === 读 urana 双环节律参数（urana 特定，别的 process factory 不读这两个 key）===
        long fastMinDt = config.getLong(KEY_FAST_MIN_DT);
        long slowMinDt = config.getLong(KEY_SLOW_MIN_DT);

        // === 尺寸是 urana Domain 知识，由本工厂算出 ===
        return new UranaSystem(nn,
                InputVectorDomain.FEELING_SPAN_LENGTH,
                OutputVectorDomain.BEHAVIOR_SPAN_LENGTH,
                fastMinDt, slowMinDt);
    }

    /**
     * 从 config 读 nnId → 查 NnRegistry → 用 urana Domain 算尺寸 → 创建 nn。
     * nnId 缺失/非法时回退 NnRegistry 默认 entry（{@link Registry#resolve} 内置 fallback）。
     */
    private INeuralNetwork createNn(CompoundTag config) {
        Registry<?> nnRegistry = RegistryManager.INSTANCE.get(RegistryIds.NN);
        RegistryEntry<?> nnEntry = nnRegistry.resolve(config.getString(RegistryIds.NN.toString()));
        NnFactory nnFactory = (NnFactory) nnEntry.getFactory();

        // nn 尺寸由 process 层 Domain 算出（不是 nn 知识，不是外周知识）
        int inputSize = InputVectorDomain.TOTAL_LENGTH;
        int outputSize = OutputVectorDomain.TOTAL_LENGTH;
        return nnFactory.create(inputSize, outputSize);
    }
}
