# 效应器集成 SmarterClientService：D2H + MotorOps + 发包

## Context（为什么这么做）

效应器仿生设计（PolarLayout/MuscleGroup/MotorOps/ActionIntent/SmarterControlGoal/ServerboundActionIntentPacket）
已全部落地，只剩最后一步：在客户端把 Urana 产出的 256-bit behavior 向量读出到 host、经 MotorOps 解码为
ActionIntent、发网络包给服务端执行。

**核心工程矛盾**：`prospectiveBehaviorBuffer` 由 **uranaStream** 写入。若按先前伪代码在 `onClientTick`
（主渲染线程）做 `BoolVector.copyToHost`（现有实现是 `cudaMemcpy` NULL 流），会触发**设备级同步**
（drain GL 渲染流）→ 卡顿。这直接违反项目硬约束「避免设备级同步、重计算走 uranaStream + Event」
（见 project_memory 的 Lessons Learned：NULL 流导致脉冲式 GPU 满载/卡顿）。

**目标产出**：非阻塞、无 GL drain、线程安全的 behavior→host 发布通道；MotorOps 以 20Hz 在客户端 tick
解码（Urana 5Hz 更新，频率差构成时间容错主体）；服务端 SmarterControlGoal 按 20Hz 消费执行。

## 方案：工作线程流式同步 D2H + 双缓冲 + fresh 标志

### 关键判断（CUDA/WDDM 语义）
- 现有 `copyToHost` = `cudaMemcpy`（NULL 流）→ 设备级同步，drain GL。**不可在主线程用**。
- 需新增「在**指定 stream** 上做 D2H」的原语：`cudaMemcpyAsync(D2H, uranaStream)` + `cudaStreamSynchronize(uranaStream)`。
  - `cudaStreamSynchronize` 是**单流同步**（只等 uranaStream 的先前工作），**不 drain GL**（GL 在另一流/线程）。
  - 跑在 **Urana 工作线程**（非主线程），阻塞的是专用线程，不影响渲染。
  - 显式 sync 保证 D2H 完成后再 ReleaseIntArrayElements，规避 WDDM「非 pinned 的 async D2H 可能同步也可能异步」
    的 JNI 释放模式歧义——稳健起见一律同步到底。
- 无需 `cudaEventQuery`：D2H 同步返回时数据即就绪，用 Java `volatile`/锁内的 `fresh` 标志即可表达
  「是否有新行为」，比新增 Event 原语更简单、且符合「把不实在状态用实在原语固化」。

### 数据流
```
Urana worker (uranaStream)              Client tick (main, 20Hz)
  runOneTick                                  
   ├ extractBehaviorTo(prospectiveBehaviorBuf) 
   ├ copyToHost(writeBuf, uranaStream)  ──阻塞单流, writeBuf 就绪
   └ lock{ swap(writeBuf,readBuf); fresh=true }     lock{ if(fresh){ arraycopy(readBuf,out); fresh=false } }
                                                  └ MotorOps.tick(out) → ActionIntent
                                                  └ sendToServer(ServerboundActionIntentPacket)
```

### 线程安全（双缓冲 + 锁，零阻塞主线程）
- `writeBuf`（worker D2H 目标）/ `readBuf`（client 读）—— 各 8 个 int（256 bit）。
- worker 的 **D2H 在锁外**（阻塞不持锁）；**swap 在锁内**（瞬时）。
- client 的 **arraycopy 在锁内**（瞬时）。主线程持锁仅纳秒级，绝不被 worker 的 GPU 等待拖住。
- worker 始终写 `writeBuf`，client 始终读 `readBuf`；swap 后 `writeBuf`=旧 readBuf（client 上一帧已读完）。
  锁保证「client 读 readBuf」与「worker swap」互斥 → 无 2-tick-ahead 回收竞争。

### 20Hz / 5Hz 频率差
- worker 每个 Urana 轮 swap 一次、置 `fresh=true`（5Hz）。
- client 每 tick 轮询：`fresh` 时拷贝并置 false，否则用上次 `out`（scratch 不变）继续 tick MotorOps。
  → MotorOps 以 20Hz 对 5Hz 数据做低通滤波（TensionIntegrator τ=50ms），正是设计意图的「肌肉保持张力」。

## 实现步骤

### A. 原生新增（1 个 JNI 函数，5 处改动，对齐现有 copyFromHost 模式）

1. **`native/stm_ai/src/core/containers/vector/Vector.h`**（镜像 287-298 行 `copyFromHost`）：
   新增重载 `void copyToHost(uint32_t *h_data, size_t wordCount, cudaStream_t stream = 0) const`，
   内部 `cudaMemcpyAsync(h_data, d_data, wordCount*sizeof(uint32_t), cudaMemcpyDeviceToHost, stream)` + `cudaStreamSynchronize(stream)` + checkCudaError。
2. **`native/stm_ai/src/core/containers/vector/interop/vector_bridge.h/.cu`**：新增 `void VectorCopyToHostBoolSync(Vector<bool>*, uint32_t*, size_t, cudaStream_t)`（对齐 75-89 行 `VectorCopyToHostBool` 的 try-catch 重抛风格）。
3. **`native/stm_ai/src/core/containers/vector/interop/vector_jni.cpp`**（对齐 68-81 行）：新增
   `_1copyToHostBoolSync(handle, data, count, stream)`：`GetIntArrayElements` → bridge → `ReleaseIntArrayElements(data, j_data, 0)`（D2H 写入，mode 0 提交；sync 已保证写完）。
4. **`VectorNative.java`**：新增 `static native void _copyToHostBoolSync(long handle, int[] data, int wordCount, long streamHandle);`
   （保留现有 `_copyToHostBool` 不动，注释说明新方法是「指定流上的同步 D2H，单流不 drain GL」）。
5. **`BoolVector.java`**：新增 `public void copyToHost(int[] data, int wordCount, long streamHandle)`（重载），
   调 `_copyToHostBoolSync`。保留现有无 stream 重载。

### B. UranaSystem：发布 host 行为快照（生产者）

文件：`features/smarter/agent/ai/urana/UranaSystem.java`

- 新增字段：`final int[] behaviorWriteBuf, behaviorReadBuf`（各 `BEHAVIOR_SIZE/32=8`）、
  `final Object behaviorLock`、`boolean behaviorFresh`。
- `runOneTick` 在 `extractBehaviorTo(prospectiveOutput, this.prospectiveBehaviorBuffer, stream)` 之后（约 272 行后）追加：
  ```java
  this.prospectiveBehaviorBuffer.copyToHost(this.behaviorWriteBuf, behaviorWriteBuf.length, stream); // 阻塞单流
  synchronized (behaviorLock) {
      int[] t = behaviorWriteBuf; behaviorWriteBuf = behaviorReadBuf; behaviorReadBuf = t;
      behaviorFresh = true;
  }
  ```
- 新增 `public boolean pollLatestBehaviorHost(int[] out)`：锁内 `if(behaviorFresh){ arraycopy(readBuf,0,out,0,len); behaviorFresh=false; return true; } return false;`。
  （对标现有 `getProspectiveBehaviorBuffer()` 的 host-facing 访问器定位。）
- 无新增 GPU 资源（纯 Java 数组），`close()` 无需改动（数组随对象 GC）。

### C. SmarterClientService：消费 + 解码 + 发包（消费者）

文件：`features/smarter/agent/SmarterClientService.java`

- 新增字段：`private MotorOps motorOps;`、`private final int[] behaviorScratch = new int[BEHAVIOR_SIZE/32];`。
- `init()`：`this.motorOps = new MotorOps();`（用 `PolarLayout.defaultHumanLike()`）。
- `onClientTick()` 替换现有 TODO 注释块（100-112 行）：
  ```java
  if (!isPossessing || urana == null || motorOps == null) return;
  EntityMaid maid = PossessionManager.INSTANCE.getPossessedMaid();
  if (maid == null) return;
  if (!PossessionManager.INSTANCE.isSmarterModeEnabled(maid)) return; // 避免 smarter 关闭时空发 20 包/秒
  urana.pollLatestBehaviorHost(behaviorScratch); // fresh=false 时 scratch 保持上次值
  ActionIntent intent = motorOps.tick(behaviorScratch); // 复用实例
  NetworkHandler.INSTANCE.sendToServer(new ServerboundActionIntentPacket(maid.getId(), intent));
  ```
  （`isSmarterModeEnabled` 已存在于 `PossessionManager` 第 100 行，读 `pendingSmarterSync` 客户端乐观态。）
- `shutdown()`：`if (motorOps != null) motorOps.reset();`，并 `MaidActionState.remove(maidUUID)` 清服务端瞬时缓冲
  （ maidUUID 取 possessedMaid；shutdown 时机在 `urana.shutdown()` join 工作线程之后，无并发访问）。

### D. 服务端清理（已存在，仅补 remove 调用）
- `MaidActionState.remove` 已存在；只需在 smarter mode 关闭（`ServerboundSetSmarterModePacket.handle` 置 false 分支）
  追加 `MaidActionState.remove(maid.getUUID())`，避免残留旧 intent 继续驱动 SmarterControlGoal。
  文件：`features/smarter/network/ServerboundSetSmarterModePacket.java`（handle 内 enabled=false 时）。

## 不做的事（边界）
- 不改 `FEELING_SPAN_LENGTH`（硬约束）。
- 不引入 `cudaEventQuery` / pinned memory（D2H 同步方案已足够；若未来 unthrottled Urana 吞吐不足再升级为 pinned+async）。
- 不改 MotorOps/PolarLayout 等已落地组件的语义。
- HOTBAR 仍为 one-hot（MotorOps 内 TODO 保留，后续单独迭代）。

## 性能说明（向用户透明）
- worker 每轮新增 1 次「单流同步」（`cudaStreamSynchronize(uranaStream)`），WDDM 约 5-20ms/次。
  - 节流模式（minDtMillis≥50ms，典型 5Hz）：开销在节流预算内，可忽略。
  - 不节流（minDtMillis=0）：worker 被 GPU 速度自然限速，sync 开销吃进节流预算；**不阻塞渲染线程、不 drain GL**。
  - 与之前 NULL 流卡顿本质不同：那是主线程设备级同步，这是专用线程单流同步。

## 验证
1. **编译**：`gradlew build`（Java）+ native CMake 重新生成 `stm_ai.dll`（确认 Vector.h 重载 + bridge + JNI 编译通过，符号链接正常）。
2. **单元/静态**：`MotorOps` 已有；用全零 scratch 调 `tick` 应产出全零 ActionIntent（无动作）。
3. **端到端**（运行时）：
   - 附身女仆 → 开 smarter mode → 观察 `[UranaTick]` 日志（dt debug）确认 worker 运转。
   - 服务端 `SmarterControlGoal.tick` 每帧读 `MaidActionState` → `MaidActionSink.execute` 驱动 maid 移动/视角。
   - 关 smarter mode → maid 停止（`MaidActionState.remove` 生效，Goal canUse 返回 false）。
   - 全程帧率不应出现脉冲式卡顿（对比之前 NULL 流方案）。
4. **GPU 同步验证**：开 dt debug + 视觉 debug，确认 Urana 轮转与渲染并发、无互相阻塞。
