# AI 模式选择注册表（递归层次框架）

## Context（为什么改）

当前 `ProcessAiSystem` 的便利构造函数 `ProcessAiSystem(long, long)` 内部 `new BnnNeuralNetwork + new UranaSystem`，把"用哪个 nn/process"硬编码进了上层。但 `ProcessAiSystem` 只直接使用 `IProcessSystem`（注释明说"本类不直接用 nn，故不持 nn"）——便利构造函数让它持有了 nn 组装逻辑，违反真善美第1条"真"。

用户设计原则：**上层只需做到"下层换模式也不改代码就能正确运行"即可（注入构造函数已做到），不需要在进入上层之前把下层"便利"起来**。"便利"组装是配置层/GUI 的职责。

本方案彻底解决模式被代码硬编码的问题：建立三层（可递归扩展为无限层）注册表 + 工厂自驱组装 + GUI 动态递归展开，让附属模组能流畅注册自己的 ai/process/nn 实现，玩家在"自动任务"GUI 选择，per-maid 持久化。删除便利构造函数。

**已确认的关键决策**：
- `NnFactory.create(int inputSize, int outputSize)` —— 仅 nn 本征尺寸，附属 nn 自行读 config 配置超参数
- GUI 动态递归显隐，**兼容无限的模式和层次**（非固定三层按钮）
- 模式更改下次附身生效（与 fast/slowMinDt 一致）

## 核心设计：递归层次框架

### 为什么是"递归层次"而非"固定三层"

用户要求"兼容无限的模式和层次"。固定三层按钮（ai/process/nn）无法适应附属模组的新层次（如某 process 不用 nn 而用别的计算机制，或某 ai 不需要 process）。因此采用**递归展开**：每个 RegistryEntry 声明自己的下层 registry（`subRegistryId`），GUI 从顶层 "ai" 开始递归展开，层次数量不限。

### 三个核心抽象（通用框架，放在 `ai/registry/` 包）

**`Registry<T>`**（泛型，一个 registry = 一层可选模式集合）：
- `registryId: ResourceLocation`（如 `smarter_touhou_maids:ai` / `:process` / `:nn`）
- `entries: Map<ResourceLocation, RegistryEntry<T>>`
- `defaultId: ResourceLocation`（旧存档/未设置时的回退值）
- 方法：`register(entry)` / `get(id)` 返回 nullable / `getAllIds()` / `getDefaultId()`
- 线程安全：`ConcurrentHashMap`，注册期（mod loading）写，运行期只读

**`RegistryEntry<T>`**：
- `id: ResourceLocation`
- `displayNameKey: String`（i18n key，如 `mode.smarter_touhou_maids.ai.process_ai`）
- `factory: T`（工厂，类型取决于层：AiFactory / ProcessFactory / NnFactory）
- `subRegistryId: @Nullable ResourceLocation`（**关键**：选了这个 entry 后，需要进一步选哪个下层 registry。null = 叶子，无下层）

**`RegistryManager`**（单例，持所有 registry）：
- `registries: Map<ResourceLocation, Registry<?>>`
- `register(registry)` / `get(registryId)` 返回 `Registry<?>`
- GUI 用通配符 `Registry<?>` 访问（只取 id/displayNameKey/subRegistryId，不调 factory）

### 三个 Factory 接口（放各自抽象同包，依赖方向清晰）

| 接口 | 包 | 签名 | 职责 |
|---|---|---|---|
| `AiFactory` | `ai/` | `IAiSystem create(CompoundTag config)` | 读 config["process"] → ProcessRegistry 查 → processFactory.create(config) → new ProcessAiSystem(process) |
| `ProcessFactory` | `process_ai/process/` | `IProcessSystem create(CompoundTag config)` | 读 config["nn"] → NnRegistry 查 → 用 Domain 算 inputSize/outputSize → nnFactory.create(int,int) → 读 config fastMinDt/slowMinDt → new UranaSystem(...) |
| `NnFactory` | `process_ai/process/urana_process/nn/` | `INeuralNetwork create(int inputSize, int outputSize)` | 叶子：new BnnNeuralNetwork(int, int) |

**工厂自驱组装**（真善美：每层工厂自己查下层 registry，外周不感知下层）：
- `AiFactory.create` 知道自己需要 process → 查 ProcessRegistry
- `ProcessFactory.create` 知道自己需要 nn → 查 NnRegistry
- `NnFactory.create` 是叶子，不查下层
- 外周 `SmarterClientService.init()` 只调 `AiRegistry.get(aiId).factory.create(config)`，下层组装自驱

### config 载体（CompoundTag，各层各取所需）

`config` 是一个 CompoundTag，包含 factory 链所有层需要的数据：
- 每层 mode id（key = registryId.toString()，如 "smarter_touhou_maids:ai" / ":process" / ":nn"）—— 由外周从 maid 的 AiModes NBT 复制进来
- `FastMinDtMillis` / `SlowMinDtMillis`（urana 特定参数，UranaProcessFactory 读）

各 factory 只读自己需要的 key，忽略其余。CompoundTag 可扩展（附属加新 key 不破坏旧 factory），签名稳定。

### GUI 递归展开（AutoTaskConfigScreen）

从顶层 registry `smarter_touhou_maids:ai` 开始：
1. 读 maid 当前该层选择 id → 创建 CycleButton（列出该 registry 所有 entry 的 displayName）
2. 查选中 entry 的 `subRegistryId`：
   - null → 叶子，停止递归（如纯规则 ai，只显示一层）
   - 非 null → 递归到下层 registry，继续展开（如 ProcessAiSystem → process → UranaSystem → nn → BnnNeuralNetwork 叶子）
3. 玩家改某层选择时，callback 调 `rebuildWidgets()`（重建 init()），下层按钮按新选中 entry 的 subRegistryId 重新展开

**兼容无限层次**：附属加新 ai（纯规则，subRegistryId=null）→ GUI 只一层；附属加新 process 用新计算层 → 注册新 registry，entry.subRegistryId 指向它 → GUI 自动递归展开。GUI 代码零改动。

### per-maid 持久化与网络同步

**MaidSmarterState**：新增 `KEY_AI_MODES = "AiModes"`（CompoundTag），里面每个 registryId 一个 String 条目。
- `getModeId(maid, registryId)` → nullable ResourceLocation（找不到返回 null，调用方 fallback 到 registry.getDefaultId()）
- `setModeId(maid, registryId, id)`
- `getAiModes(maid)` → CompoundTag（供 SmarterClientService 组装 config）

**网络包**（参照 ServerboundSetMinDtMillisPacket 模式）：
- `ServerboundSetAiModePacket(UUID maidUUID, ResourceLocation registryId, ResourceLocation selectedId)` —— 改一个选择发一个包（层次无限也能处理，非三 id 一包）
- `ClientboundAiModeSyncPacket` —— 服务端校验 owner 后写 NBT 并回发

## 新建文件（12 个）

### 通用注册表框架（`features/smarter/agent/ai/registry/`，3 个）
1. `Registry.java` — 泛型 `Registry<T>`，持 registryId + entries + defaultId，ConcurrentHashMap
2. `RegistryEntry.java` — `RegistryEntry<T>`(id, displayNameKey, factory, subRegistryId nullable)
3. `RegistryManager.java` — 单例，持 `Map<ResourceLocation, Registry<?>>`，register/get

### Factory 接口（放各自抽象同包，3 个）
4. `features/smarter/agent/ai/AiFactory.java` — `create(CompoundTag config) → IAiSystem`
5. `features/smarter/agent/ai/process_ai/process/ProcessFactory.java` — `create(CompoundTag config) → IProcessSystem`
6. `features/smarter/agent/ai/process_ai/process/urana_process/nn/NnFactory.java` — `create(int, int) → INeuralNetwork`

### Factory 实现（与各自实现类同包，3 个）
7. `features/smarter/agent/ai/process_ai/ProcessAiFactory.java` — implements AiFactory。读 config processId → ProcessRegistry.get → create(config) → new ProcessAiSystem(process)
8. `features/smarter/agent/ai/process_ai/process/urana_process/UranaProcessFactory.java` — implements ProcessFactory。读 config nnId → NnRegistry.get → 用 `InputVectorDomain.TOTAL_LENGTH`/`OutputVectorDomain.TOTAL_LENGTH` 算尺寸 → nnFactory.create(int,int) → 读 config fastMinDt/slowMinDt → new UranaSystem(nn, FEELING_SPAN_LENGTH, BEHAVIOR_SPAN_LENGTH, fast, slow)。**逻辑搬家自现 `ProcessAiSystem.buildDefaultProcess`**
9. `features/smarter/agent/ai/process_ai/process/urana_process/nn/bnn/BnnNnFactory.java` — implements NnFactory。`new BnnNeuralNetwork(inputSize, outputSize)`

### 默认注册（1 个）
10. `features/smarter/agent/ai/registry/AiModeDefaults.java` — `registerDefaults()` 在 FMLCommonSetupEvent 调用：
    - 注册三个 Registry 到 RegistryManager（id: `smarter_touhou_maids:ai`/`:process`/`:nn`）
    - NnRegistry 注册 `smarter_touhou_maids:bnn` → BnnNnFactory（subRegistryId=null 叶子）
    - ProcessRegistry 注册 `smarter_touhou_maids:urana` → UranaProcessFactory（subRegistryId=`:nn`）
    - AiRegistry 注册 `smarter_touhou_maids:process_ai` → ProcessAiFactory（subRegistryId=`:process`）
    - 每个 registry 的 defaultId 设为上述唯一 entry 的 id

### 网络包（2 个，features/smarter/network/）
11. `ServerboundSetAiModePacket.java` — 镜像 ServerboundSetMinDtMillisPacket，payload = UUID + registryId + selectedId。服务端校验 owner 后 MaidSmarterState.setModeId + 回发 ClientboundAiModeSyncPacket
12. `ClientboundAiModeSyncPacket.java` — 镜像 ClientboundMinDtMillisSyncPacket，调 PossessionManager.onAiModeSync

## 修改文件（8 个）

### 1. `process_ai/ProcessAiSystem.java`
- **删除**便利构造函数 `ProcessAiSystem(long, long)` 和 `buildDefaultProcess`
- **删除**对 BnnNeuralNetwork/UranaSystem/InputVectorDomain/OutputVectorDomain/INeuralNetwork 的 import
- 保留注入构造函数 `ProcessAiSystem(IProcessSystem)`
- 更新 javadoc：组装由 ProcessAiFactory 在外周驱动

### 2. `agent/SmarterClientService.java` — `init()` 改写
- 删除 `new ProcessAiSystem(fastMinDtMillis, slowMinDtMillis)` 和相关 import
- 改为：
  1. 读 maid 的 AiModes CompoundTag（`MaidSmarterState.getAiModes(maid)`），null 时用空 tag
  2. 组装 config：复制 AiModes + putLong FastMinDtMillis/SlowMinDtMillis
  3. 读 aiId = config.getString("smarter_touhou_maids:ai")（或 getModeId），AiRegistry.get(aiId) null 时 fallback defaultId
  4. `this.ai = aiFactory.create(config)`
- maid null 边界：用默认 id + minDt=0 组装（与现有 null 检查一致）

### 3. `state/MaidSmarterState.java`
- 新增 `KEY_AI_MODES = "AiModes"`
- 新增 `getModeId(maid, ResourceLocation registryId)` → nullable ResourceLocation（tryParse，失败返回 null）
- 新增 `setModeId(maid, registryId, id)`
- 新增 `getAiModes(maid)` → CompoundTag（供 SmarterClientService 组装 config）

### 4. `possession/core/PossessionManager.java`
- 新增字段 `HashMap<UUID, Map<ResourceLocation, ResourceLocation>> pendingModeSync`
- 新增 `setMode(maid, registryId, selectedId)` — 发 ServerboundSetAiModePacket + 写 pending
- 新增 `getMode(maid, registryId)` → nullable（先查 pending，再查 MaidSmarterState）
- 新增 `onAiModeSync(uuid, registryId, selectedId)` — 写 pending + 同步 maid NBT
- `forceReset()` 清空 pendingModeSync

### 5. `network/NetworkHandler.java`
- import 两个新包类
- `init()` 末尾追加两条 registerMessage（index 继续递增，不重排已有）

### 6. `ui/screen/AutoTaskConfigScreen.java`
- `GUI_HEIGHT` 适当增大（容纳最多 3 层模式选择 + 现有控件；当前结构最多 ai→process→nn 三层）
- `init()` 新增递归展开方法 `buildModeSelectors(maid, startX, startY)`：
  - 从 RegistryManager.get(`smarter_touhou_maids:ai`) 开始
  - 循环：创建 CycleButton（builder + withValues + withInitialValue + displayName via Component.translatable），callback 里 PossessionManager.setMode + `this.rebuildWidgets()`
  - 查选中 entry.subRegistryId，非 null 则 y+=25 递归下层，null 则停止
- 放置位置：possession/smarterMode 之下，neuronCountBox 之上（现有控件整体下移）
- `renderLabels` 加各层标签
- rebuildWidgets 时 EditBox 状态从 maid config 恢复（值已持久化，不丢失）

### 7. `SmarterTouhouMaids.java`
- 构造器 modEventBus 加 `addListener(FMLCommonSetupEvent.class, e -> AiModeDefaults.registerDefaults())`

### 8. lang 文件（zh_cn.json / en_us.json）
- `mode.smarter_touhou_maids.ai.process_ai` = "流程型 AI" / "Process AI"
- `mode.smarter_touhou_maids.process.urana` = "Urana 流程系统" / "Urana Process"
- `mode.smarter_touhou_maids.nn.bnn` = "二值神经网络" / "BNN"

## 实现顺序（四阶段，每阶段可独立编译）

### 阶段 A — 注册表与工厂骨架（不动现有代码）
1. Registry + RegistryEntry + RegistryManager
2. AiFactory + ProcessFactory + NnFactory 接口
3. BnnNnFactory + UranaProcessFactory + ProcessAiFactory 实现
4. AiModeDefaults + SmarterTouhouMaids 注册
- 验证：`AiRegistry.get(default).create(config)` 能造出完整 ai（可写临时测试或留待阶段 C 验证）

### 阶段 B — 状态与网络（不动外周）
5. MaidSmarterState 加 AiModes 存储
6. ServerboundSetAiModePacket + ClientboundAiModeSyncPacket
7. NetworkHandler 注册两包
8. PossessionManager 加 mode sync 方法
- 验证：编译通过

### 阶段 C — 外周接线 + 删除便利构造函数（必须同提交）
9. SmarterClientService.init() 改用 AiRegistry
10. ProcessAiSystem 删除便利构造函数 + buildDefaultProcess
- **9 与 10 必须同提交**：删便利构造函数而不改 init 会编译失败
- 验证：`gradlew compileJava` BUILD SUCCESSFUL

### 阶段 D — GUI
11. AutoTaskConfigScreen 递归展开 + GUI_HEIGHT 调整
12. lang 文件加翻译
- 验证：编译 + 进游戏打开 GUI 看到三层选择按钮，改 ai 选择时下层按钮动态重建

## 验证方法

1. **编译验证**：每阶段 `gradlew compileJava` BUILD SUCCESSFUL
2. **功能验证**（阶段 D 完成后进游戏）：
   - 打开"自动任务"GUI，看到 AI 模式 / Process 模式 / NN 模式 三个选择按钮（递归展开三层）
   - 切换 NN 模式（只有 BNN 一个选项，但按钮在）→ 关闭 GUI → 重新附身 → ai 正常运行（验证组装链路通）
   - 切换 AI 模式 → 下层按钮 rebuildWidgets 重建
   - 退出附身再进入 → 读 per-maid 配置正确恢复选择
3. **旧存档兼容**：旧 maid NBT 无 AiModes 键 → getModeId 返回 null → fallback registry.getDefaultId() → 默认 process_ai/urana/bnn 组装，行为与现版一致
4. **附属模组接入验证**（思维实验）：附属注册新 NnFactory（如 CNN）到 NnRegistry → GUI 的 NN 模式按钮自动多出一个选项 → 选 CNN → 重新附身 → 用 CNN 运行（UranaSystem 零改动，因持 INeuralNetwork 接口）

## 潜在风险与缓解

- **Registry 线程安全**：ConcurrentHashMap + javadoc 注明仅 mod loading 期可写
- **旧存档兼容**：getModeId 返回 nullable，调用方 fallback 到 registry.getDefaultId()
- **id namespace**：统一用 `smarter_touhou_maids:` 全 mod id（与 NetworkHandler 现有约定一致），ResourceLocation 序列化要求 namespace 非空小写
- **rebuildWidgets 副作用**：EditBox 值已持久化到 maid NBT，重建时从 config 恢复，不丢失
- **GUI 高度**：当前结构最多 3 层（ai→process→nn），GUI_HEIGHT 增大约 75px 够用；附属加更多层时若溢出，后续可加滚动（MVP 不做）
- **NnFactory.create(int,int) 契约冻结**：发布后签名固定。附属 nn 若需超参数，自行读 Forge config 或自己的配置文件，不经 factory 签名传（符合真善美第1条，nn 本征只需尺寸）
