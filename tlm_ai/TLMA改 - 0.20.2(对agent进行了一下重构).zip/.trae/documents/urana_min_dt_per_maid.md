# Urana 最小轮间间隔（minDtMillis）per-maid 配置

## Context
Urana 工作线程全速运转（约 0.2s/轮）导致 GPU 占用过高，与 Minecraft 渲染争抢 GPU 算力，游戏帧率仅 3fps。需要一个"最小轮间间隔"参数，让 Urana 在两轮之间 `Thread.sleep` 补足，降低 GPU 占用。该参数需 **per-maid**（每个女仆独立配置，像"附身后是否自动运行ai"那样），GUI 可调 + 持久化。

## 设计
照搬现有 `smarterMode` 的 per-maid 配置模式（boolean→long 变体）。完整链路：GUI EditBox → `PossessionManager.set` → 网络包 → 服务端写 NBT → 回包 → 客户端缓存/NBT。Urana 启动时（`awaken`）读取当前附身女仆的 minDtMillis，`runLoop` 里 sleep 节流。

### minDtMillis 语义
- `0` = 不限速（全速运转，当前行为，**默认值**，不改变现状）
- `>0` = 最小轮间间隔（毫秒），`runOneTick` 完成后若耗时不足则 sleep 补足

### 取舍：启动时读一次
minDtMillis 在 `awaken` 时读取一次，运行中固定（符合用户原话"由外界启动 urana 循环时输入"）。GUI 改了 per-maid 值后，下次附身该女仆时生效。若未来要运行时立刻生效，再加 `UranaSystem.setMinDtMillis` + `SmarterClientService` 拉取逻辑（本次不做，YAGNI）。

## 改动清单（8 文件）

### 1. MaidSmarterState.java（存储层）
- 加 `KEY_MIN_DT_MILLIS = "MinDtMillis"`
- 加 `getMinDtMillis(EntityMaid)` → long（`getLong`，默认 0）
- 加 `setMinDtMillis(EntityMaid, long)` → `putLong`
- 路径：`features/smarter/state/MaidSmarterState.java`
- 参照：现有 `isEnabled`/`setEnabled`

### 2. 新建 ServerboundSetMinDtMillisPacket.java（客户端→服务端）
- 字段：`UUID maidUUID`, `long minDtMillis`
- encode/decode：`writeUUID`+`writeLong` / `readUUID`+`readLong`
- handle：校验 sender 是 maid owner → `MaidSmarterState.setMinDtMillis(maid, value)` → 回 `ClientboundMinDtMillisSyncPacket`
- 路径：`features/smarter/network/ServerboundSetMinDtMillisPacket.java`
- 参照：`ServerboundSetSmarterModePacket.java`

### 3. 新建 ClientboundMinDtMillisSyncPacket.java（服务端→客户端）
- 字段：`UUID maidUUID`, `long minDtMillis`
- encode/decode：同上
- handle：`DistExecutor` → `PossessionManager.INSTANCE.onMinDtMillisSync(uuid, value)`
- 路径：`features/smarter/network/ClientboundMinDtMillisSyncPacket.java`
- 参照：`ClientboundSmarterModeSyncPacket.java`

### 4. NetworkHandler.java（注册）
- 续号注册两个新包（index 7、8；当前最大 6 = `ServerboundBehaviorSyncPacket`）
- 路径：`network/NetworkHandler.java`

### 5. PossessionManager.java（客户端读写 + 缓存）
- 加字段 `HashMap<UUID, Long> pendingMinDtSync`
- 加 `setMinDtMillis(EntityMaid, long)`：`pendingMinDtSync.put` + `send(ServerboundSetMinDtMillisPacket)`
- 加 `getMinDtMillis(EntityMaid)` → long：先查 `pendingMinDtSync`，否则 `MaidSmarterState.getMinDtMillis`（默认 0）
- 加 `onMinDtMillisSync(UUID, long)`：更新缓存 + 在 level 找 maid 更新 NBT
- 路径：`features/possession/core/PossessionManager.java`
- 参照：`setSmarterModeEnabled`/`isSmarterModeEnabled`/`onSmarterModeSync`

### 6. AutoTaskConfigScreen.java（GUI）
- 加 `EditBox minDtBox`（y=170，承接现有 y=145 的 dtDebug 之后）
- `init` 时读 `PossessionManager.INSTANCE.getMinDtMillis(maid)` 填入
- responder/commit：`Mth.clamp(value, 0, 5000)` → `PossessionManager.INSTANCE.setMinDtMillis(maid, value)`
- `removed()` 时提交（同 neuronCountBox 的 commit 模式）
- 路径：`features/ui/screen/AutoTaskConfigScreen.java`
- 参照：`neuronCountBox`（EditBox 数值输入模式）

### 7. SmarterClientService.java（启动传参）
- `init` 里读 `PossessionManager.INSTANCE.getPossessedMaid()` 的 minDtMillis
- 传给 `urana.awaken(feelingBuffer, minDtMillis)`
- 路径：`features/smarter/agent/SmarterClientService.java`

### 8. UranaSystem.java（节流实现）
- `awaken` 签名改：`awaken(BoolVector feelingBuffer, long minDtMillis)`，存 `this.minDtMillis`
- 加字段 `private long minDtMillis = 0`
- `runLoop` 里 `runOneTick` 后：若 `minDtMillis > 0` 且 `(now - lastRunStartNanos) < minDtMillis*1_000_000`，`Thread.sleep` 补足；`catch InterruptedException` → `interrupt()` + `break`
- 路径：`features/smarter/agent/ai/urana/UranaSystem.java`

## 验证
1. `gradlew compileJava` 编译通过
2. `gradlew runClient` 启动游戏
3. 附身女仆，开 AutoTaskConfigScreen，设 minDtMillis=500
4. 观察 GPU 占用下降（每 500ms 跑一轮 0.2s kernel，占 ~40%）
5. 开 dtDebug 开关，观察日志 dt 稳定在 500ms
6. 设 minDtMillis=0，恢复全速
7. 退出附身再进入，值持久化保留（per-maid NBT）
